-- =============================================================================
--  GIA SƯ LÝ 9 - DATABASE (SQL Server) - FILE DUY NHẤT
--  Cài đặt mới: chạy TOÀN BỘ file này (tự tạo DB + bảng + dữ liệu)
--  Cập nhật: chạy lại file này được, các đoạn đều kiểm tra tồn tại trước
--  Chạy: sqlcmd -S localhost -E -i GiaSuLy9.sql -f 65001
--  Hoặc dùng helper: .\run-sql.ps1 -File GiaSuLy9.sql
-- =============================================================================

-- =============================================================================
--  PHẦN 1: SCHEMA (bảng + tài khoản admin + chủ đề mặc định)
--  (nguồn: 01_schema.sql)
-- =============================================================================
-- ============================================================
--  GIA SƯ LÝ 9 - Script tạo cơ sở dữ liệu SQL Server
--  Chạy file này trong SQL Server Management Studio
-- ============================================================

IF DB_ID('GiaSuLy9') IS NULL
BEGIN
    CREATE DATABASE GiaSuLy9;
END
GO

USE GiaSuLy9;
GO

-- ============================================================
--  1. TÀI KHOẢN
-- ============================================================
IF OBJECT_ID('dbo.Users', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users (
        UserID       INT IDENTITY(1,1) PRIMARY KEY,
        Username     NVARCHAR(50)   NOT NULL UNIQUE,
        PasswordHash NVARCHAR(256)  NOT NULL,
        Salt         NVARCHAR(64)   NULL,
        FullName     NVARCHAR(150)  NOT NULL,
        Email        NVARCHAR(150)  NULL,
        Phone        NVARCHAR(30)   NULL,
        Role         NVARCHAR(20)   NOT NULL,  -- ADMIN | TEACHER | STUDENT
        ClassName    NVARCHAR(50)   NULL,
        AvatarUrl    NVARCHAR(500)  NULL,
        IsActive     BIT            NOT NULL DEFAULT 1,
        CreatedAt    DATETIME       NOT NULL DEFAULT GETDATE()
    );
    PRINT 'Đã tạo bảng Users';
END
GO

-- ============================================================
--  2. MÔN HỌC
-- ============================================================
IF OBJECT_ID('dbo.Subjects', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Subjects (
        SubjectID   INT IDENTITY(1,1) PRIMARY KEY,
        Name        NVARCHAR(150) NOT NULL,
        Code        NVARCHAR(30)  NULL,
        Description NVARCHAR(MAX)  NULL,
        ImageUrl    NVARCHAR(500) NULL,
        TeacherID   INT            NULL,
        IsActive    BIT            NOT NULL DEFAULT 1,
        CreatedAt   DATETIME       NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_Subjects_Teacher FOREIGN KEY (TeacherID) REFERENCES dbo.Users(UserID)
    );
    PRINT 'Đã tạo bảng Subjects';
END
GO

-- ============================================================
--  3. CHỦ ĐỀ
-- ============================================================
IF OBJECT_ID('dbo.Topics', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Topics (
        TopicID     INT IDENTITY(1,1) PRIMARY KEY,
        SubjectID   INT            NOT NULL,
        Name        NVARCHAR(200) NOT NULL,
        Description NVARCHAR(MAX)  NULL,
        ImageUrl    NVARCHAR(500) NULL,
        OrderIndex  INT            NOT NULL DEFAULT 0,
        IsActive    BIT            NOT NULL DEFAULT 1,
        CreatedAt   DATETIME       NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_Topics_Subject FOREIGN KEY (SubjectID) REFERENCES dbo.Subjects(SubjectID)
    );
    PRINT 'Đã tạo bảng Topics';
END
GO

-- ============================================================
--  4. BÀI GIẢNG (video youtube / file / text / website)
-- ============================================================
IF OBJECT_ID('dbo.Lessons', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Lessons (
        LessonID        INT IDENTITY(1,1) PRIMARY KEY,
        SubjectID       INT           NOT NULL,
        TopicID         INT           NOT NULL,
        Title           NVARCHAR(300) NOT NULL,
        Description     NVARCHAR(MAX) NULL,
        LessonType      NVARCHAR(20)  NOT NULL DEFAULT 'TEXT',
            -- VIDEO_YOUTUBE | VIDEO_FILE | TEXT | WEBSITE
        VideoUrl        NVARCHAR(500) NULL,
        DocumentUrl     NVARCHAR(500) NULL,
        Content         NVARCHAR(MAX) NULL,
        DurationMinutes INT           NOT NULL DEFAULT 0,
        CreatedBy       INT           NULL,
        IsActive        BIT           NOT NULL DEFAULT 1,
        CreatedAt       DATETIME      NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_Lessons_Subject FOREIGN KEY (SubjectID) REFERENCES dbo.Subjects(SubjectID),
        CONSTRAINT FK_Lessons_Topic   FOREIGN KEY (TopicID)   REFERENCES dbo.Topics(TopicID),
        CONSTRAINT FK_Lessons_Creator FOREIGN KEY (CreatedBy) REFERENCES dbo.Users(UserID)
    );
    PRINT 'Đã tạo bảng Lessons';
END
GO

-- ============================================================
--  5. NGÂN HÀNG CÂU HỎI
-- ============================================================
IF OBJECT_ID('dbo.Questions', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Questions (
        QuestionID   INT IDENTITY(1,1) PRIMARY KEY,
        SubjectID    INT           NOT NULL,
        TopicID      INT           NOT NULL,
        Content      NVARCHAR(MAX) NOT NULL,
        QuestionType NVARCHAR(20)  NOT NULL DEFAULT 'MCQ',
            -- MCQ | ESSAY
        CorrectAnswer NVARCHAR(10) NULL,
        OptionA      NVARCHAR(1000) NULL,
        OptionB      NVARCHAR(1000) NULL,
        OptionC      NVARCHAR(1000) NULL,
        OptionD      NVARCHAR(1000) NULL,
        Explanation  NVARCHAR(MAX) NULL,
        Difficulty   NVARCHAR(20)  NOT NULL DEFAULT 'MEDIUM',
            -- EASY | MEDIUM | HARD
        CreatedBy    INT           NULL,
        Source       NVARCHAR(20)  NOT NULL DEFAULT 'TEACHER',
            -- TEACHER | AI
        IsActive     BIT           NOT NULL DEFAULT 1,
        CreatedAt    DATETIME      NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_Questions_Subject FOREIGN KEY (SubjectID) REFERENCES dbo.Subjects(SubjectID),
        CONSTRAINT FK_Questions_Topic   FOREIGN KEY (TopicID)   REFERENCES dbo.Topics(TopicID),
        CONSTRAINT FK_Questions_Creator FOREIGN KEY (CreatedBy) REFERENCES dbo.Users(UserID)
    );
    PRINT 'Đã tạo bảng Questions';
END
GO

-- ============================================================
--  6. PHIÊN LUYỆN TẬP
-- ============================================================
IF OBJECT_ID('dbo.PracticeSessions', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.PracticeSessions (
        SessionID      INT IDENTITY(1,1) PRIMARY KEY,
        StudentID      INT            NOT NULL,
        SubjectID      INT            NOT NULL,
        TopicID        INT            NOT NULL,
        PracticeType   NVARCHAR(20)   NOT NULL DEFAULT 'MCQ',
        TotalQuestions INT            NOT NULL DEFAULT 0,
        CorrectCount   INT            NOT NULL DEFAULT 0,
        WrongCount     INT            NOT NULL DEFAULT 0,
        Score          DECIMAL(5,2)   NOT NULL DEFAULT 0,
        Status         NVARCHAR(20)   NOT NULL DEFAULT 'IN_PROGRESS',
        StartedAt      DATETIME       NOT NULL DEFAULT GETDATE(),
        FinishedAt     DATETIME       NULL,
        CONSTRAINT FK_Practice_Student FOREIGN KEY (StudentID) REFERENCES dbo.Users(UserID),
        CONSTRAINT FK_Practice_Subject FOREIGN KEY (SubjectID) REFERENCES dbo.Subjects(SubjectID),
        CONSTRAINT FK_Practice_Topic   FOREIGN KEY (TopicID)   REFERENCES dbo.Topics(TopicID)
    );
    PRINT 'Đã tạo bảng PracticeSessions';
END
GO

-- ============================================================
--  7. CÂU TRẢ LỜI
-- ============================================================
IF OBJECT_ID('dbo.PracticeAnswers', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.PracticeAnswers (
        AnswerID      INT IDENTITY(1,1) PRIMARY KEY,
        SessionID     INT            NOT NULL,
        QuestionID    INT            NOT NULL,
        SelectedAnswer NVARCHAR(10)  NULL,
        CorrectAnswer NVARCHAR(10)  NULL,
        IsCorrect     BIT            NOT NULL DEFAULT 0,
        AiFeedback    NVARCHAR(MAX)  NULL,
        UserAnswer    NVARCHAR(MAX)  NULL,
        ImagePath     NVARCHAR(500)  NULL,
        AnsweredAt    DATETIME       NOT NULL DEFAULT GETDATE(),
        OrderIndex    INT            NOT NULL DEFAULT 0,
        Score         DECIMAL(5,2)   NOT NULL DEFAULT 0,  -- điểm tự chấm của câu (thang 0-10)
        CONSTRAINT FK_Answers_Session  FOREIGN KEY (SessionID)  REFERENCES dbo.PracticeSessions(SessionID),
        CONSTRAINT FK_Answers_Question FOREIGN KEY (QuestionID) REFERENCES dbo.Questions(QuestionID)
    );
    PRINT 'Đã tạo bảng PracticeAnswers';
END
GO

-- Thêm cột Score cho các bảng đã tồn tại từ trước (migration an toàn)
IF OBJECT_ID('dbo.PracticeAnswers', 'U') IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM sys.columns WHERE name = 'Score' AND object_id = OBJECT_ID('dbo.PracticeAnswers'))
BEGIN
    ALTER TABLE dbo.PracticeAnswers ADD Score DECIMAL(5,2) NOT NULL DEFAULT 0;
    PRINT 'Đã thêm cột PracticeAnswers.Score';
END
GO

-- ============================================================
--  7b. HỒ SƠ GIÁO VIÊN
-- ============================================================
IF OBJECT_ID('dbo.TeacherProfiles', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.TeacherProfiles (
        ProfileID   INT IDENTITY(1,1) PRIMARY KEY,
        UserID      INT           NOT NULL UNIQUE,
        FullName    NVARCHAR(150) NOT NULL,
        Degree      NVARCHAR(100) NULL,   -- Thạc sĩ / Thạc sĩ kỹ thuật / Cử nhân
        Title       NVARCHAR(200) NULL,   -- Chức danh hiển thị
        School      NVARCHAR(200) NULL,   -- Trường / đơn vị
        Specialty   NVARCHAR(300) NULL,   -- Chuyên môn
        Bio         NVARCHAR(MAX) NULL,   -- Giới thiệu ngắn
        AvatarUrl   NVARCHAR(500) NULL,
        Color       NVARCHAR(20)  NULL DEFAULT '#1d4ed8',
        YearsExp    INT           NOT NULL DEFAULT 0,
        StudentCount INT          NOT NULL DEFAULT 0,
        VideoCount  INT           NOT NULL DEFAULT 0,
        IsActive    BIT           NOT NULL DEFAULT 1,
        CreatedAt   DATETIME      NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_TeacherProfiles_User FOREIGN KEY (UserID) REFERENCES dbo.Users(UserID)
    );
    PRINT 'Đã tạo bảng TeacherProfiles';
END
GO

-- ============================================================
--  8. CÁC BƯỚC AI GIẢI TỪNG BƯỚC
-- ============================================================
IF OBJECT_ID('dbo.TutorSteps', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.TutorSteps (
        StepID      INT IDENTITY(1,1) PRIMARY KEY,
        SessionID   INT           NOT NULL DEFAULT 0,
        QuestionID  INT           NOT NULL,
        StepOrder   INT           NOT NULL DEFAULT 0,
        Speaker     NVARCHAR(20)  NOT NULL DEFAULT 'AI',
            -- USER | AI
        Message     NVARCHAR(MAX) NOT NULL,
        StepType    NVARCHAR(30)  NOT NULL DEFAULT 'EXPLANATION',
            -- CORRECT | HINT | NEED_DATA | EXPLANATION | FINAL | ANSWER
        AwaitingUser BIT          NOT NULL DEFAULT 0,
        CreatedAt   DATETIME      NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_TutorSteps_Question FOREIGN KEY (QuestionID) REFERENCES dbo.Questions(QuestionID)
    );
    PRINT 'Đã tạo bảng TutorSteps';
END
GO

-- ============================================================
--  9. CẤU HÌNH AI
-- ============================================================
IF OBJECT_ID('dbo.AI_SETTINGS', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.AI_SETTINGS (
        SettingID     INT IDENTITY(1,1) PRIMARY KEY,
        Provider      NVARCHAR(50)  NOT NULL DEFAULT 'OPENAI',
        ApiKey        NVARCHAR(500) NULL,
        BaseUrl       NVARCHAR(300) NOT NULL DEFAULT 'https://api.openai.com/v1',
        Model         NVARCHAR(100) NOT NULL DEFAULT 'gpt-4o-mini',
        Temperature   DECIMAL(3,2)  NOT NULL DEFAULT 0.70,
        MaxTokens     INT           NOT NULL DEFAULT 2048,
        SystemPrompt  NVARCHAR(MAX) NULL,
        TutorPrompt   NVARCHAR(MAX) NULL,
        QuestionPrompt NVARCHAR(MAX) NULL,
        IsActive      BIT           NOT NULL DEFAULT 1,
        CreatedBy     INT           NULL,
        CreatedAt     DATETIME      NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_AISettings_Creator FOREIGN KEY (CreatedBy) REFERENCES dbo.Users(UserID)
    );
    PRINT 'Đã tạo bảng AI_SETTINGS';
END
GO

-- ============================================================
--  10. NHẬT KÝ AI
-- ============================================================
IF OBJECT_ID('dbo.AiLogs', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.AiLogs (
        LogID        INT IDENTITY(1,1) PRIMARY KEY,
        UserID       INT           NULL,
        Feature      NVARCHAR(50)  NOT NULL,
        PromptText   NVARCHAR(MAX) NULL,
        ResponseText NVARCHAR(MAX) NULL,
        TokensUsed   INT           NOT NULL DEFAULT 0,
        Success      BIT           NOT NULL DEFAULT 0,
        ErrorMessage NVARCHAR(1000) NULL,
        CreatedAt    DATETIME      NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_AiLogs_User FOREIGN KEY (UserID) REFERENCES dbo.Users(UserID)
    );
    PRINT 'Đã tạo bảng AiLogs';
END
GO

-- ============================================================
--  TIẾN ĐỘ XEM BÀI GIẢNG CỦA HỌC SINH
-- ============================================================
IF OBJECT_ID('dbo.LessonProgress', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.LessonProgress (
        UserID       INT      NOT NULL,
        LessonID     INT      NOT NULL,
        PercentValue INT      NOT NULL DEFAULT 0,
        Completed    BIT      NOT NULL DEFAULT 0,
        UpdatedAt    DATETIME NOT NULL DEFAULT GETDATE(),
        PRIMARY KEY (UserID, LessonID),
        CONSTRAINT FK_LessonProgress_User   FOREIGN KEY (UserID)   REFERENCES dbo.Users(UserID),
        CONSTRAINT FK_LessonProgress_Lesson FOREIGN KEY (LessonID) REFERENCES dbo.Lessons(LessonID)
    );
    PRINT 'Đã tạo bảng LessonProgress';
END
GO

-- ============================================================
--  DỮ LIỆU MẪU
-- ============================================================

-- Môn học Vật lý 9
IF NOT EXISTS (SELECT 1 FROM dbo.Subjects WHERE Name = N'Vật lý 9')
BEGIN
    INSERT INTO dbo.Subjects (Name, Code, Description, ImageUrl)
    VALUES (N'Vật lý 9', N'LY9',
            N'Gia sư Vật lý lớp 9 - học từng bước cùng AI, luyện trắc nghiệm và tự luận.',
            N'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?q=80&w=800&auto=format&fit=crop');
END
GO

-- Tài khoản admin (mật khẩu: admin123)
-- Salt = 'GSL9ADMIN'; hash = SHA256('GSL9ADMIN' + 'admin123')
IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE Username = N'admin')
BEGIN
    DECLARE @saltAdmin NVARCHAR(64) = N'GSL9ADMIN';
    DECLARE @hashAdmin NVARCHAR(256) =
        N'4d7a1c1e3f2b8a6d5c9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2';
    -- Ghi đè bằng hash tính đúng bằng Java: chạy lần đầu sẽ dùng mật khẩu plaintext
    INSERT INTO dbo.Users (Username, PasswordHash, Salt, FullName, Email, Role, IsActive)
    VALUES (N'admin', @hashAdmin, @saltAdmin, N'Quản trị viên', N'admin@giasuly9.vn', N'ADMIN', 1);

    PRINT N'Đã tạo tài khoản admin (mật khẩu: admin123)';
END
GO

-- Ghi chú: hash ở trên được tính cho salt='GSL9ADMIN'.
-- Nếu đăng nhập không được, dùng lệnh sau để reset mật khẩu (chạy trong SQL):
--   UPDATE dbo.Users
--   SET PasswordHash = N'<hash SHA256(salt + password)>', Salt = N'<salt>'
--   WHERE Username = N'admin';
--
-- Hoặc đơn giản hơn: đặt PasswordHash = N'admin123' và Salt = NULL
-- (hệ thống hỗ trợ đăng nhập dạng plaintext khi Salt IS NULL, dùng cho lúc cài đặt).
IF EXISTS (SELECT 1 FROM dbo.Users WHERE Username = N'admin' AND Salt = N'GSL9ADMIN')
BEGIN
    UPDATE dbo.Users SET PasswordHash = N'admin123', Salt = NULL WHERE Username = N'admin';
END
GO

-- Chủ đề mẫu cho Vật lý 9
IF NOT EXISTS (SELECT 1 FROM dbo.Topics)
BEGIN
    DECLARE @ly9 INT = (SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9');

    INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex) VALUES
        (@ly9, N'Cơ năng và năng lượng',
         N'Trạng thái vật rơi tự do, cơ năng, công thức W = P.h, định luật bảo toàn cơ năng.', 1),
        (@ly9, N'Điện và mạch điện',
         N'Dòng điện, cường độ dòng điện I = Q/t, hiệu điện thế, điện trở, mạch nối tiếp - song song.', 2),
        (@ly9, N'Điện năng, công suất và điện áp xoay chiều',
         N'Công suất P = U.I, định luật Ohm, máy phát điện, máy biến thế.', 3),
        (@ly9, N'Khúc xạ ánh sáng',
         N'Hiện tượng khúc xạ, thấu kính, công thức 1/f = 1/f1 + 1/f2, kính lúp, kính hiển vi.', 4),
        (@ly9, N'Tia và hiện tượng phát sáng',
         N'Phát xạ ánh sáng, tia laze, hiện tượng nhập nhằng, truyền ánh sáng trong nước.', 5);
END
GO

PRINT N'=========================================';
PRINT N'  HOÀN TẤT TẠO CƠ SỞ DỮ LIỆU GiaSuLy9';
PRINT N'  Tài khoản admin: admin / admin123';
PRINT N'=========================================';
GO


-- =============================================================================
--  PHẦN 2: DỮ LIỆU CÂU HỎI (20 MCQ + 20 tự luận cho mỗi chủ đề)
--  (nguồn: 02_seed_data.sql)
-- =============================================================================
-- GIA SU LY 9 - 20 MCQ + 20 ESSAY / chu de, TIENG VIET CO DAU
-- Chay SAU 01_schema.sql. Chay voi: sqlcmd ... -f 65001 -i 02_seed_data.sql
USE GiaSuLy9;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE Username = N'giaovien')
BEGIN
    INSERT INTO dbo.Users (Username, PasswordHash, Salt, FullName, Email, Phone, Role, ClassName, IsActive)
    VALUES (N'giaovien', N'teacher123', NULL, N'Nguyễn Văn Thầy', N'giaovien@giasuly9.vn', N'0901234567', N'TEACHER', N'Vật lý 9', 1);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE Username = N'hocsinh')
BEGIN
    INSERT INTO dbo.Users (Username, PasswordHash, Salt, FullName, Email, Phone, Role, ClassName, IsActive)
    VALUES (N'hocsinh', N'student123', NULL, N'Lê Minh Học', N'hocsinh@giasuly9.vn', N'0912345678', N'STUDENT', N'9A1', 1);
END
GO

UPDATE dbo.Subjects SET TeacherID = (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien') WHERE Name = N'Vật lý 9';
GO

-- Xoa seed cu khong dau (neu co) de nap lai co dau
DELETE FROM dbo.TutorSteps WHERE QuestionID IN (SELECT QuestionID FROM dbo.Questions WHERE Source = 'SEED40');
GO
DELETE FROM dbo.PracticeAnswers WHERE QuestionID IN (SELECT QuestionID FROM dbo.Questions WHERE Source = 'SEED40');
GO
DELETE FROM dbo.Questions WHERE Source = 'SEED40';
GO

IF (SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9') IS NOT NULL
BEGIN
DECLARE @ly9x INT = (SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9');
IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9x AND Name = N'Cơ năng và năng lượng')
    INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex) VALUES (@ly9x, N'Cơ năng và năng lượng', N'Trạng thái vật rơi tự do, cơ năng, công thức W = P.h, định luật bảo toàn cơ năng.', 1);
IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9x AND Name = N'Điện và mạch điện')
    INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex) VALUES (@ly9x, N'Điện và mạch điện', N'Dòng điện, cường độ I = Q/t, hiệu điện thế, điện trở, mạch nối tiếp - song song.', 2);
IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9x AND Name = N'Điện năng, công suất và điện áp xoay chiều')
    INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex) VALUES (@ly9x, N'Điện năng, công suất và điện áp xoay chiều', N'Công suất P = U.I, định luật Ohm, máy phát điện, máy biến thế.', 3);
IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9x AND Name = N'Khúc xạ ánh sáng')
    INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex) VALUES (@ly9x, N'Khúc xạ ánh sáng', N'Hiện tượng khúc xạ, thấu kính, kính lúp, kính hiển vi.', 4);
IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9x AND Name = N'Tia và hiện tượng phát sáng')
    INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex) VALUES (@ly9x, N'Tia và hiện tượng phát sáng', N'Phát xạ ánh sáng, tia laze, hiệu suất, năng lượng tái tạo.', 5);
IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9x AND Name = N'Năng lượng cơ học')
    INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex) VALUES (@ly9x, N'Năng lượng cơ học', N'Cơ năng, động năng, thế năng; công và công suất. (KHTN 9 - Chủ đề 1)', 6);
IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9x AND Name = N'Ánh sáng')
    INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex) VALUES (@ly9x, N'Ánh sáng', N'Khúc xạ, tán sắc, phản xạ toàn phần, thấu kính và kính lúp. (KHTN 9 - Chủ đề 2)', 7);
IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9x AND Name = N'Điện')
    INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex) VALUES (@ly9x, N'Điện', N'Điện trở, định luật Ohm, đoạn mạch nối tiếp - song song, năng lượng và công suất điện. (KHTN 9 - Chủ đề 3)', 8);
IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9x AND Name = N'Điện từ')
    INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex) VALUES (@ly9x, N'Điện từ', N'Cảm ứng điện từ, dòng điện xoay chiều, máy phát điện và máy biến thế. (KHTN 9 - Chủ đề 4)', 9);
IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9x AND Name = N'Năng lượng với cuộc sống')
    INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex) VALUES (@ly9x, N'Năng lượng với cuộc sống', N'Năng lượng Trái Đất, hóa thạch và tái tạo. (KHTN 9 - Chủ đề 5)', 10);
END
GO

-- N'Cơ năng và năng lượng' : 20 MCQ
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng') AND QuestionType='MCQ' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, OptionA, OptionB, OptionC, OptionD, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Một máy thực hiện công 55 J trong 5 s. Công suất của máy là:',
     N'MCQ', N'B',
     N'16 W',
     N'11 W',
     N'22 W',
     N'6 W',
     N'P = A/t = 55/5 = 11 W.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 3 kg ở độ cao 6 m so với mặt đất (g = 10 N/kg). Thế năng trọng trường của vật là:',
     N'MCQ', N'C',
     N'230 J',
     N'360 J',
     N'180 J',
     N'18 J',
     N'Wt = m.g.h = 3.10.6 = 180 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật rơi tự do từ độ cao 80 m (g = 10 m/s², bỏ qua ma sát). Tốc độ khi chạm đất là:',
     N'MCQ', N'D',
     N'20 m/s',
     N'80 m/s',
     N'45 m/s',
     N'40 m/s',
     N'Bảo toàn cơ năng: m.g.h = m.v²/2 nên v = √(2.g.h) = √1600 = 40 m/s.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 6 kg chuyển động với tốc độ 4 m/s. Động năng của vật là:',
     N'MCQ', N'A',
     N'48 J',
     N'24 J',
     N'96 J',
     N'68 J',
     N'Wđ = m.v²/2 = 6.16/2 = 48 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật nặng 7 kg được đưa lên cao 8 m (lấy g = 10 N/kg). Công của lực nâng là:',
     N'MCQ', N'B',
     N'56 J',
     N'560 J',
     N'5600 J',
     N'610 J',
     N'Công W = P.h = m.g.h = 7.10.8 = 560 J. Trọng lực ngược chiều chuyển động nên công của trọng lực là -560 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Một máy thực hiện công 160 J trong 10 s. Công suất của máy là:',
     N'MCQ', N'C',
     N'21 W',
     N'32 W',
     N'16 W',
     N'11 W',
     N'P = A/t = 160/10 = 16 W.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 8 kg ở độ cao 6 m so với mặt đất (g = 10 N/kg). Thế năng trọng trường của vật là:',
     N'MCQ', N'D',
     N'530 J',
     N'960 J',
     N'48 J',
     N'480 J',
     N'Wt = m.g.h = 8.10.6 = 480 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật rơi tự do từ độ cao 5 m (g = 10 m/s², bỏ qua ma sát). Tốc độ khi chạm đất là:',
     N'MCQ', N'A',
     N'10 m/s',
     N'5 m/s',
     N'20 m/s',
     N'15 m/s',
     N'Bảo toàn cơ năng: m.g.h = m.v²/2 nên v = √(2.g.h) = √100 = 10 m/s.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 6 kg chuyển động với tốc độ 6 m/s. Động năng của vật là:',
     N'MCQ', N'B',
     N'36 J',
     N'108 J',
     N'216 J',
     N'128 J',
     N'Wđ = m.v²/2 = 6.36/2 = 108 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật nặng 4 kg được đưa lên cao 5 m (lấy g = 10 N/kg). Công của lực nâng là:',
     N'MCQ', N'C',
     N'20 J',
     N'2000 J',
     N'200 J',
     N'250 J',
     N'Công W = P.h = m.g.h = 4.10.5 = 200 J. Trọng lực ngược chiều chuyển động nên công của trọng lực là -200 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Một máy thực hiện công 315 J trong 15 s. Công suất của máy là:',
     N'MCQ', N'D',
     N'26 W',
     N'42 W',
     N'16 W',
     N'21 W',
     N'P = A/t = 315/15 = 21 W.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 4 kg ở độ cao 6 m so với mặt đất (g = 10 N/kg). Thế năng trọng trường của vật là:',
     N'MCQ', N'A',
     N'240 J',
     N'290 J',
     N'480 J',
     N'24 J',
     N'Wt = m.g.h = 4.10.6 = 240 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật rơi tự do từ độ cao 20 m (g = 10 m/s², bỏ qua ma sát). Tốc độ khi chạm đất là:',
     N'MCQ', N'B',
     N'10 m/s',
     N'20 m/s',
     N'40 m/s',
     N'25 m/s',
     N'Bảo toàn cơ năng: m.g.h = m.v²/2 nên v = √(2.g.h) = √400 = 20 m/s.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 6 kg chuyển động với tốc độ 8 m/s. Động năng của vật là:',
     N'MCQ', N'C',
     N'48 J',
     N'384 J',
     N'192 J',
     N'212 J',
     N'Wđ = m.v²/2 = 6.64/2 = 192 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật nặng 9 kg được đưa lên cao 2 m (lấy g = 10 N/kg). Công của lực nâng là:',
     N'MCQ', N'D',
     N'18 J',
     N'1800 J',
     N'230 J',
     N'180 J',
     N'Công W = P.h = m.g.h = 9.10.2 = 180 J. Trọng lực ngược chiều chuyển động nên công của trọng lực là -180 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Một máy thực hiện công 208 J trong 8 s. Công suất của máy là:',
     N'MCQ', N'A',
     N'26 W',
     N'31 W',
     N'52 W',
     N'21 W',
     N'P = A/t = 208/8 = 26 W.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 9 kg ở độ cao 6 m so với mặt đất (g = 10 N/kg). Thế năng trọng trường của vật là:',
     N'MCQ', N'B',
     N'590 J',
     N'540 J',
     N'1080 J',
     N'54 J',
     N'Wt = m.g.h = 9.10.6 = 540 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật rơi tự do từ độ cao 45 m (g = 10 m/s², bỏ qua ma sát). Tốc độ khi chạm đất là:',
     N'MCQ', N'C',
     N'15 m/s',
     N'60 m/s',
     N'30 m/s',
     N'35 m/s',
     N'Bảo toàn cơ năng: m.g.h = m.v²/2 nên v = √(2.g.h) = √900 = 30 m/s.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 6 kg chuyển động với tốc độ 10 m/s. Động năng của vật là:',
     N'MCQ', N'D',
     N'60 J',
     N'600 J',
     N'320 J',
     N'300 J',
     N'Wđ = m.v²/2 = 6.100/2 = 300 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật nặng 6 kg được đưa lên cao 8 m (lấy g = 10 N/kg). Công của lực nâng là:',
     N'MCQ', N'A',
     N'480 J',
     N'48 J',
     N'4800 J',
     N'530 J',
     N'Công W = P.h = m.g.h = 6.10.8 = 480 J. Trọng lực ngược chiều chuyển động nên công của trọng lực là -480 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Cơ năng và năng lượng' : 20 ESSAY
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng') AND QuestionType='ESSAY' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Lực 120 N kéo vật đi 6 m trong 6 s. Tính công và công suất.',
     N'ESSAY', NULL,
     N'A = F.s = 120.6 = 720 J. P = A/t = 720/6 = 120 W.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Xe chuyển động biến đổi đều với vận tốc đầu 7 m/s, gia tốc 2 m/s². Tính quãng đường sau 5 s.',
     N'ESSAY', NULL,
     N's = v₀.t + a.t²/2 = 7.5 + 2.25/2 = 60 m.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 5 kg rơi tự do từ độ cao 20 m (g = 10 m/s², bỏ qua ma sát). Tính cơ năng ban đầu và tốc độ khi chạm đất.',
     N'ESSAY', NULL,
     N'Cơ năng ban đầu = thế năng: W = m.g.h = 5.10.20 = 1000 J. Khi chạm đất Wđ = W nên v = √(2.g.h) = √400 = 20 m/s.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 7 kg được kéo đều lên cao 2 m. Tính công của lực kéo (g = 10 N/kg) và cho biết dấu của công trọng lực.',
     N'ESSAY', NULL,
     N'W_kéo = F.s = P.h = m.g.h = 7.10.2 = 140 J. Trọng lực ngược chiều chuyển động nên A_trọng_lực = -140 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Lực 200 N kéo vật đi 10 m trong 10 s. Tính công và công suất.',
     N'ESSAY', NULL,
     N'A = F.s = 200.10 = 2000 J. P = A/t = 2000/10 = 200 W.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Xe chuyển động biến đổi đều với vận tốc đầu 11 m/s, gia tốc 2 m/s². Tính quãng đường sau 4 s.',
     N'ESSAY', NULL,
     N's = v₀.t + a.t²/2 = 11.4 + 2.16/2 = 60 m.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 4 kg rơi tự do từ độ cao 20 m (g = 10 m/s², bỏ qua ma sát). Tính cơ năng ban đầu và tốc độ khi chạm đất.',
     N'ESSAY', NULL,
     N'Cơ năng ban đầu = thế năng: W = m.g.h = 4.10.20 = 800 J. Khi chạm đất Wđ = W nên v = √(2.g.h) = √400 = 20 m/s.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 4 kg được kéo đều lên cao 2 m. Tính công của lực kéo (g = 10 N/kg) và cho biết dấu của công trọng lực.',
     N'ESSAY', NULL,
     N'W_kéo = F.s = P.h = m.g.h = 4.10.2 = 80 J. Trọng lực ngược chiều chuyển động nên A_trọng_lực = -80 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Lực 280 N kéo vật đi 14 m trong 8 s. Tính công và công suất.',
     N'ESSAY', NULL,
     N'A = F.s = 280.14 = 3920 J. P = A/t = 3920/8 = 490 W.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Xe chuyển động biến đổi đều với vận tốc đầu 5 m/s, gia tốc 2 m/s². Tính quãng đường sau 3 s.',
     N'ESSAY', NULL,
     N's = v₀.t + a.t²/2 = 5.3 + 2.9/2 = 24 m.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 3 kg rơi tự do từ độ cao 20 m (g = 10 m/s², bỏ qua ma sát). Tính cơ năng ban đầu và tốc độ khi chạm đất.',
     N'ESSAY', NULL,
     N'Cơ năng ban đầu = thế năng: W = m.g.h = 3.10.20 = 600 J. Khi chạm đất Wđ = W nên v = √(2.g.h) = √400 = 20 m/s.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 8 kg được kéo đều lên cao 2 m. Tính công của lực kéo (g = 10 N/kg) và cho biết dấu của công trọng lực.',
     N'ESSAY', NULL,
     N'W_kéo = F.s = P.h = m.g.h = 8.10.2 = 160 J. Trọng lực ngược chiều chuyển động nên A_trọng_lực = -160 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Lực 360 N kéo vật đi 8 m trong 6 s. Tính công và công suất.',
     N'ESSAY', NULL,
     N'A = F.s = 360.8 = 2880 J. P = A/t = 2880/6 = 480 W.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Xe chuyển động biến đổi đều với vận tốc đầu 9 m/s, gia tốc 2 m/s². Tính quãng đường sau 7 s.',
     N'ESSAY', NULL,
     N's = v₀.t + a.t²/2 = 9.7 + 2.49/2 = 112 m.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 2 kg rơi tự do từ độ cao 20 m (g = 10 m/s², bỏ qua ma sát). Tính cơ năng ban đầu và tốc độ khi chạm đất.',
     N'ESSAY', NULL,
     N'Cơ năng ban đầu = thế năng: W = m.g.h = 2.10.20 = 400 J. Khi chạm đất Wđ = W nên v = √(2.g.h) = √400 = 20 m/s.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 5 kg được kéo đều lên cao 2 m. Tính công của lực kéo (g = 10 N/kg) và cho biết dấu của công trọng lực.',
     N'ESSAY', NULL,
     N'W_kéo = F.s = P.h = m.g.h = 5.10.2 = 100 J. Trọng lực ngược chiều chuyển động nên A_trọng_lực = -100 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Lực 440 N kéo vật đi 12 m trong 10 s. Tính công và công suất.',
     N'ESSAY', NULL,
     N'A = F.s = 440.12 = 5280 J. P = A/t = 5280/10 = 528 W.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Xe chuyển động biến đổi đều với vận tốc đầu 13 m/s, gia tốc 2 m/s². Tính quãng đường sau 6 s.',
     N'ESSAY', NULL,
     N's = v₀.t + a.t²/2 = 13.6 + 2.36/2 = 114 m.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 6 kg rơi tự do từ độ cao 20 m (g = 10 m/s², bỏ qua ma sát). Tính cơ năng ban đầu và tốc độ khi chạm đất.',
     N'ESSAY', NULL,
     N'Cơ năng ban đầu = thế năng: W = m.g.h = 6.10.20 = 1200 J. Khi chạm đất Wđ = W nên v = √(2.g.h) = √400 = 20 m/s.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Cơ năng và năng lượng'),
     N'Vật 9 kg được kéo đều lên cao 2 m. Tính công của lực kéo (g = 10 N/kg) và cho biết dấu của công trọng lực.',
     N'ESSAY', NULL,
     N'W_kéo = F.s = P.h = m.g.h = 9.10.2 = 180 J. Trọng lực ngược chiều chuyển động nên A_trọng_lực = -180 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Điện và mạch điện' : 20 MCQ
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện') AND QuestionType='MCQ' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, OptionA, OptionB, OptionC, OptionD, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Đặt hiệu điện thế 20 V vào dây dẫn thì dòng điện qua dây là 4 A. Điện trở của dây là:',
     N'MCQ', N'B',
     N'7 Ω',
     N'5 Ω',
     N'3 Ω',
     N'24 Ω',
     N'R = U/I = 20/4 = 5 Ω.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 5 Ω và 8 Ω mắc nối tiếp. Điện trở tương đương là:',
     N'MCQ', N'C',
     N'3 Ω',
     N'40 Ω',
     N'13 Ω',
     N'10 Ω',
     N'Nối tiếp: R_tđ = R₁ + R₂ = 5 + 8 = 13 Ω.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 6 Ω và 12 Ω mắc song song. Điện trở tương đương là:',
     N'MCQ', N'D',
     N'18 Ω',
     N'6 Ω',
     N'72 Ω',
     N'4 Ω',
     N'Song song: R_tđ = R₁.R₂/(R₁+R₂) = 6.12/18 = 4 Ω.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 1 A chạy qua dây dẫn trong 7 s. Điện lượng qua tiết diện dây là:',
     N'MCQ', N'A',
     N'7 C',
     N'8 C',
     N'6 C',
     N'8 C',
     N'Q = I.t = 1.7 = 7 C.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 2 A chạy qua điện trở 18 Ω. Hiệu điện thế hai đầu điện trở là:',
     N'MCQ', N'B',
     N'54 V',
     N'36 V',
     N'18 V',
     N'20 V',
     N'U = I.R = 2.18 = 36 V.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Đặt hiệu điện thế 40 V vào dây dẫn thì dòng điện qua dây là 4 A. Điện trở của dây là:',
     N'MCQ', N'C',
     N'12 Ω',
     N'8 Ω',
     N'10 Ω',
     N'44 Ω',
     N'R = U/I = 40/4 = 10 Ω.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 10 Ω và 8 Ω mắc nối tiếp. Điện trở tương đương là:',
     N'MCQ', N'D',
     N'2 Ω',
     N'80 Ω',
     N'15 Ω',
     N'18 Ω',
     N'Nối tiếp: R_tđ = R₁ + R₂ = 10 + 8 = 18 Ω.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 9 Ω và 18 Ω mắc song song. Điện trở tương đương là:',
     N'MCQ', N'A',
     N'6 Ω',
     N'27 Ω',
     N'8 Ω',
     N'162 Ω',
     N'Song song: R_tđ = R₁.R₂/(R₁+R₂) = 9.18/27 = 6 Ω.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 1 A chạy qua dây dẫn trong 4 s. Điện lượng qua tiết diện dây là:',
     N'MCQ', N'B',
     N'5 C',
     N'4 C',
     N'3 C',
     N'5 C',
     N'Q = I.t = 1.4 = 4 C.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 2 A chạy qua điện trở 13 Ω. Hiệu điện thế hai đầu điện trở là:',
     N'MCQ', N'C',
     N'39 V',
     N'13 V',
     N'26 V',
     N'15 V',
     N'U = I.R = 2.13 = 26 V.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Đặt hiệu điện thế 28 V vào dây dẫn thì dòng điện qua dây là 4 A. Điện trở của dây là:',
     N'MCQ', N'D',
     N'9 Ω',
     N'5 Ω',
     N'32 Ω',
     N'7 Ω',
     N'R = U/I = 28/4 = 7 Ω.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 5 Ω và 8 Ω mắc nối tiếp. Điện trở tương đương là:',
     N'MCQ', N'A',
     N'13 Ω',
     N'3 Ω',
     N'40 Ω',
     N'10 Ω',
     N'Nối tiếp: R_tđ = R₁ + R₂ = 5 + 8 = 13 Ω.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 6 Ω và 12 Ω mắc song song. Điện trở tương đương là:',
     N'MCQ', N'B',
     N'18 Ω',
     N'4 Ω',
     N'6 Ω',
     N'72 Ω',
     N'Song song: R_tđ = R₁.R₂/(R₁+R₂) = 6.12/18 = 4 Ω.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 1 A chạy qua dây dẫn trong 9 s. Điện lượng qua tiết diện dây là:',
     N'MCQ', N'C',
     N'10 C',
     N'8 C',
     N'9 C',
     N'10 C',
     N'Q = I.t = 1.9 = 9 C.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 2 A chạy qua điện trở 8 Ω. Hiệu điện thế hai đầu điện trở là:',
     N'MCQ', N'D',
     N'24 V',
     N'8 V',
     N'10 V',
     N'16 V',
     N'U = I.R = 2.8 = 16 V.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Đặt hiệu điện thế 16 V vào dây dẫn thì dòng điện qua dây là 4 A. Điện trở của dây là:',
     N'MCQ', N'A',
     N'4 Ω',
     N'6 Ω',
     N'2 Ω',
     N'20 Ω',
     N'R = U/I = 16/4 = 4 Ω.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 10 Ω và 8 Ω mắc nối tiếp. Điện trở tương đương là:',
     N'MCQ', N'B',
     N'2 Ω',
     N'18 Ω',
     N'80 Ω',
     N'15 Ω',
     N'Nối tiếp: R_tđ = R₁ + R₂ = 10 + 8 = 18 Ω.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 9 Ω và 18 Ω mắc song song. Điện trở tương đương là:',
     N'MCQ', N'C',
     N'27 Ω',
     N'8 Ω',
     N'6 Ω',
     N'162 Ω',
     N'Song song: R_tđ = R₁.R₂/(R₁+R₂) = 9.18/27 = 6 Ω.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 1 A chạy qua dây dẫn trong 6 s. Điện lượng qua tiết diện dây là:',
     N'MCQ', N'D',
     N'7 C',
     N'5 C',
     N'7 C',
     N'6 C',
     N'Q = I.t = 1.6 = 6 C.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 2 A chạy qua điện trở 3 Ω. Hiệu điện thế hai đầu điện trở là:',
     N'MCQ', N'A',
     N'6 V',
     N'9 V',
     N'3 V',
     N'5 V',
     N'U = I.R = 2.3 = 6 V.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Điện và mạch điện' : 20 ESSAY
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện') AND QuestionType='ESSAY' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 2 A chạy qua bóng đèn trong 6 s. Tính điện lượng dịch chuyển và số electron (e = 1,6.10⁻¹⁹ C).',
     N'ESSAY', NULL,
     N'Q = I.t = 2.6 = 12 C. Số electron n = Q/e = 12/(1,6.10⁻¹⁹) ≈ 7.50.10¹⁹ hạt.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Đặt hiệu điện thế 18 V vào hai đầu điện trở 5 Ω. Tính dòng điện và nêu cách mắc ampe kế, vôn kế để kiểm tra.',
     N'ESSAY', NULL,
     N'I = U/R = 18/5 ≈ 3.60 A. Mắc ampe kế nối tiếp, vôn kế song song với điện trở.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 5 Ω và 9 Ω mắc nối tiếp vào nguồn 12 V. Tính R_tđ và cường độ dòng điện.',
     N'ESSAY', NULL,
     N'R_tđ = 5 + 9 = 14 Ω. I = U/R_tđ = 12/14 = 0.86 A.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 6 Ω và 12 Ω mắc song song vào nguồn 12 V. Tính R_tđ và dòng qua mỗi nhánh.',
     N'ESSAY', NULL,
     N'R_tđ = 6.12/18 = 4.00 Ω. I₁ = 12/6 = 2.00 A, I₂ = 12/12 = 1.00 A.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 2 A chạy qua bóng đèn trong 10 s. Tính điện lượng dịch chuyển và số electron (e = 1,6.10⁻¹⁹ C).',
     N'ESSAY', NULL,
     N'Q = I.t = 2.10 = 20 C. Số electron n = Q/e = 20/(1,6.10⁻¹⁹) ≈ 12.50.10¹⁹ hạt.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Đặt hiệu điện thế 18 V vào hai đầu điện trở 9 Ω. Tính dòng điện và nêu cách mắc ampe kế, vôn kế để kiểm tra.',
     N'ESSAY', NULL,
     N'I = U/R = 18/9 ≈ 2.00 A. Mắc ampe kế nối tiếp, vôn kế song song với điện trở.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 9 Ω và 9 Ω mắc nối tiếp vào nguồn 12 V. Tính R_tđ và cường độ dòng điện.',
     N'ESSAY', NULL,
     N'R_tđ = 9 + 9 = 18 Ω. I = U/R_tđ = 12/18 = 0.67 A.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 5 Ω và 20 Ω mắc song song vào nguồn 12 V. Tính R_tđ và dòng qua mỗi nhánh.',
     N'ESSAY', NULL,
     N'R_tđ = 5.20/25 = 4.00 Ω. I₁ = 12/5 = 2.40 A, I₂ = 12/20 = 0.60 A.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 2 A chạy qua bóng đèn trong 14 s. Tính điện lượng dịch chuyển và số electron (e = 1,6.10⁻¹⁹ C).',
     N'ESSAY', NULL,
     N'Q = I.t = 2.14 = 28 C. Số electron n = Q/e = 28/(1,6.10⁻¹⁹) ≈ 17.50.10¹⁹ hạt.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Đặt hiệu điện thế 18 V vào hai đầu điện trở 4 Ω. Tính dòng điện và nêu cách mắc ampe kế, vôn kế để kiểm tra.',
     N'ESSAY', NULL,
     N'I = U/R = 18/4 ≈ 4.50 A. Mắc ampe kế nối tiếp, vôn kế song song với điện trở.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 5 Ω và 9 Ω mắc nối tiếp vào nguồn 12 V. Tính R_tđ và cường độ dòng điện.',
     N'ESSAY', NULL,
     N'R_tđ = 5 + 9 = 14 Ω. I = U/R_tđ = 12/14 = 0.86 A.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 6 Ω và 3 Ω mắc song song vào nguồn 12 V. Tính R_tđ và dòng qua mỗi nhánh.',
     N'ESSAY', NULL,
     N'R_tđ = 6.3/9 = 2.00 Ω. I₁ = 12/6 = 2.00 A, I₂ = 12/3 = 4.00 A.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 2 A chạy qua bóng đèn trong 8 s. Tính điện lượng dịch chuyển và số electron (e = 1,6.10⁻¹⁹ C).',
     N'ESSAY', NULL,
     N'Q = I.t = 2.8 = 16 C. Số electron n = Q/e = 16/(1,6.10⁻¹⁹) ≈ 10.00.10¹⁹ hạt.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Đặt hiệu điện thế 18 V vào hai đầu điện trở 8 Ω. Tính dòng điện và nêu cách mắc ampe kế, vôn kế để kiểm tra.',
     N'ESSAY', NULL,
     N'I = U/R = 18/8 ≈ 2.25 A. Mắc ampe kế nối tiếp, vôn kế song song với điện trở.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 9 Ω và 9 Ω mắc nối tiếp vào nguồn 12 V. Tính R_tđ và cường độ dòng điện.',
     N'ESSAY', NULL,
     N'R_tđ = 9 + 9 = 18 Ω. I = U/R_tđ = 12/18 = 0.67 A.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 8 Ω và 8 Ω mắc song song vào nguồn 12 V. Tính R_tđ và dòng qua mỗi nhánh.',
     N'ESSAY', NULL,
     N'R_tđ = 8.8/16 = 4.00 Ω. I₁ = 12/8 = 1.50 A, I₂ = 12/8 = 1.50 A.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Dòng điện 2 A chạy qua bóng đèn trong 12 s. Tính điện lượng dịch chuyển và số electron (e = 1,6.10⁻¹⁹ C).',
     N'ESSAY', NULL,
     N'Q = I.t = 2.12 = 24 C. Số electron n = Q/e = 24/(1,6.10⁻¹⁹) ≈ 15.00.10¹⁹ hạt.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Đặt hiệu điện thế 18 V vào hai đầu điện trở 3 Ω. Tính dòng điện và nêu cách mắc ampe kế, vôn kế để kiểm tra.',
     N'ESSAY', NULL,
     N'I = U/R = 18/3 ≈ 6.00 A. Mắc ampe kế nối tiếp, vôn kế song song với điện trở.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 5 Ω và 9 Ω mắc nối tiếp vào nguồn 12 V. Tính R_tđ và cường độ dòng điện.',
     N'ESSAY', NULL,
     N'R_tđ = 5 + 9 = 14 Ω. I = U/R_tđ = 12/14 = 0.86 A.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện và mạch điện'),
     N'Hai điện trở 2 Ω và 2 Ω mắc song song vào nguồn 12 V. Tính R_tđ và dòng qua mỗi nhánh.',
     N'ESSAY', NULL,
     N'R_tđ = 2.2/4 = 1.00 Ω. I₁ = 12/2 = 6.00 A, I₂ = 12/2 = 6.00 A.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Điện năng, công suất và điện áp xoay chiều' : 20 MCQ
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều') AND QuestionType='MCQ' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, OptionA, OptionB, OptionC, OptionD, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Dòng 4 A qua điện trở 5 Ω trong 60 s. Nhiệt lượng tỏa ra là:',
     N'MCQ', N'B',
     N'1200 J',
     N'4800 J',
     N'9600 J',
     N'4700 J',
     N'Q = I².R.t = 16.5.60 = 4800 J (định luật Jun – Len-xơ).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Dòng điện xoay chiều có tần số 50 Hz. Chu kì của dòng điện là:',
     N'MCQ', N'C',
     N'10 ms',
     N'25 ms',
     N'20 ms',
     N'50 Hz',
     N'T = 1/f = 1/50 ≈ 0.0200 s = 20 ms.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Thiết bị dùng ở mạng 220 V với dòng điện 7 A. Công suất tiêu thụ là:',
     N'MCQ', N'D',
     N'1760 W',
     N'1320 W',
     N'227 W',
     N'1.5 kW',
     N'P = U.I = 220.7 = 1540 W.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Thiết bị 3 kW hoạt động 2 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'A',
     N'6 kWh',
     N'9 kWh',
     N'3 kWh',
     N'5 kWh',
     N'A = P.t = 3.2 = 6 kWh = 6.3,6.10⁶ J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Máy biến thế có 500 vòng sơ cấp, 100 vòng thứ cấp, đặt 220 V vào sơ cấp. Điện áp thứ cấp là:',
     N'MCQ', N'B',
     N'88 V',
     N'44 V',
     N'22 V',
     N'220 V',
     N'U₂ = U₁.N₂/N₁ = 220.100/500 = 44 V.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Dòng 1 A qua điện trở 10 Ω trong 180 s. Nhiệt lượng tỏa ra là:',
     N'MCQ', N'C',
     N'1800 J',
     N'3600 J',
     N'1800 J',
     N'1700 J',
     N'Q = I².R.t = 1.10.180 = 1800 J (định luật Jun – Len-xơ).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Dòng điện xoay chiều có tần số 100 Hz. Chu kì của dòng điện là:',
     N'MCQ', N'D',
     N'5 ms',
     N'11 ms',
     N'100 Hz',
     N'10 ms',
     N'T = 1/f = 1/100 ≈ 0.0100 s = 10 ms.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Thiết bị dùng ở mạng 110 V với dòng điện 6 A. Công suất tiêu thụ là:',
     N'MCQ', N'A',
     N'660 W',
     N'770 W',
     N'550 W',
     N'116 W',
     N'P = U.I = 110.6 = 660 W.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Thiết bị 4 kW hoạt động 7 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'B',
     N'32 kWh',
     N'28 kWh',
     N'24 kWh',
     N'11 kWh',
     N'A = P.t = 4.7 = 28 kWh = 28.3,6.10⁶ J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Máy biến thế có 500 vòng sơ cấp, 100 vòng thứ cấp, đặt 220 V vào sơ cấp. Điện áp thứ cấp là:',
     N'MCQ', N'C',
     N'88 V',
     N'22 V',
     N'44 V',
     N'220 V',
     N'U₂ = U₁.N₂/N₁ = 220.100/500 = 44 V.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Dòng 2 A qua điện trở 5 Ω trong 120 s. Nhiệt lượng tỏa ra là:',
     N'MCQ', N'D',
     N'1200 J',
     N'4800 J',
     N'2300 J',
     N'2400 J',
     N'Q = I².R.t = 4.5.120 = 2400 J (định luật Jun – Len-xơ).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Dòng điện xoay chiều có tần số 25 Hz. Chu kì của dòng điện là:',
     N'MCQ', N'A',
     N'40 ms',
     N'20 ms',
     N'67 ms',
     N'25 Hz',
     N'T = 1/f = 1/25 ≈ 0.0400 s = 40 ms.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Thiết bị dùng ở mạng 220 V với dòng điện 5 A. Công suất tiêu thụ là:',
     N'MCQ', N'B',
     N'1320 W',
     N'1.1 kW',
     N'880 W',
     N'225 W',
     N'P = U.I = 220.5 = 1100 W.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Thiết bị 1 kW hoạt động 6 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'C',
     N'7 kWh',
     N'5 kWh',
     N'6 kWh',
     N'7 kWh',
     N'A = P.t = 1.6 = 6 kWh = 6.3,6.10⁶ J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Máy biến thế có 500 vòng sơ cấp, 100 vòng thứ cấp, đặt 220 V vào sơ cấp. Điện áp thứ cấp là:',
     N'MCQ', N'D',
     N'88 V',
     N'22 V',
     N'220 V',
     N'44 V',
     N'U₂ = U₁.N₂/N₁ = 220.100/500 = 44 V.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Dòng 3 A qua điện trở 10 Ω trong 60 s. Nhiệt lượng tỏa ra là:',
     N'MCQ', N'A',
     N'5400 J',
     N'1800 J',
     N'10800 J',
     N'5300 J',
     N'Q = I².R.t = 9.10.60 = 5400 J (định luật Jun – Len-xơ).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Dòng điện xoay chiều có tần số 60 Hz. Chu kì của dòng điện là:',
     N'MCQ', N'B',
     N'8 ms',
     N'16.7 ms',
     N'20 ms',
     N'60 Hz',
     N'T = 1/f = 1/60 ≈ 0.0167 s = 16.7 ms.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Thiết bị dùng ở mạng 110 V với dòng điện 4 A. Công suất tiêu thụ là:',
     N'MCQ', N'C',
     N'550 W',
     N'330 W',
     N'440 W',
     N'114 W',
     N'P = U.I = 110.4 = 440 W.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Thiết bị 2 kW hoạt động 5 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'D',
     N'12 kWh',
     N'8 kWh',
     N'7 kWh',
     N'10 kWh',
     N'A = P.t = 2.5 = 10 kWh = 10.3,6.10⁶ J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Máy biến thế có 500 vòng sơ cấp, 100 vòng thứ cấp, đặt 220 V vào sơ cấp. Điện áp thứ cấp là:',
     N'MCQ', N'A',
     N'44 V',
     N'88 V',
     N'22 V',
     N'220 V',
     N'U₂ = U₁.N₂/N₁ = 220.100/500 = 44 V.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Điện năng, công suất và điện áp xoay chiều' : 20 ESSAY
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều') AND QuestionType='ESSAY' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Giải thích nguyên tắc hoạt động của máy biến thế và tính U₂ khi U₁ = 220 V, N₁ = 500, N₂ = 250.',
     N'ESSAY', NULL,
     N'Máy biến thế dựa trên cảm ứng điện từ: dòng biến thiên ở sơ cấp tạo từ trường biến thiên, sinh dòng ở thứ cấp. U₂ = 220.250/500 = 110 V (hạ áp).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Ấm điện 220 V – 880 W dùng 5 giờ mỗi ngày. Tính điện năng tiêu thụ trong 30 ngày (kWh).',
     N'ESSAY', NULL,
     N'P = 880 W = 0.9 kW. A/ngày = 0.9.5 = 4.4 kWh. 30 ngày: 132.0 kWh.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Máy biến thế 100/1000 vòng, cuộn sơ cấp đặt 220 V. Tính điện áp thứ cấp và cho biết tăng hay hạ áp.',
     N'ESSAY', NULL,
     N'U₂ = U₁.N₂/N₁ = 220.1000/100 = 2200 V. Tăng áp.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Bếp điện có dòng 2 A qua điện trở 9 Ω trong 2 phút. Tính nhiệt lượng tỏa ra.',
     N'ESSAY', NULL,
     N'Đổi t = 120 s. Q = I².R.t = 4.9.120 = 4320 J = 4 kJ.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Giải thích nguyên tắc hoạt động của máy biến thế và tính U₂ khi U₁ = 220 V, N₁ = 500, N₂ = 250.',
     N'ESSAY', NULL,
     N'Máy biến thế dựa trên cảm ứng điện từ: dòng biến thiên ở sơ cấp tạo từ trường biến thiên, sinh dòng ở thứ cấp. U₂ = 220.250/500 = 110 V (hạ áp).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Ấm điện 220 V – 660 W dùng 4 giờ mỗi ngày. Tính điện năng tiêu thụ trong 30 ngày (kWh).',
     N'ESSAY', NULL,
     N'P = 660 W = 0.7 kW. A/ngày = 0.7.4 = 2.6 kWh. 30 ngày: 79.2 kWh.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Máy biến thế 500/100 vòng, cuộn sơ cấp đặt 220 V. Tính điện áp thứ cấp và cho biết tăng hay hạ áp.',
     N'ESSAY', NULL,
     N'U₂ = U₁.N₂/N₁ = 220.100/500 = 44 V. Hạ áp.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Bếp điện có dòng 2 A qua điện trở 13 Ω trong 3 phút. Tính nhiệt lượng tỏa ra.',
     N'ESSAY', NULL,
     N'Đổi t = 180 s. Q = I².R.t = 4.13.180 = 9360 J = 9 kJ.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Giải thích nguyên tắc hoạt động của máy biến thế và tính U₂ khi U₁ = 220 V, N₁ = 500, N₂ = 250.',
     N'ESSAY', NULL,
     N'Máy biến thế dựa trên cảm ứng điện từ: dòng biến thiên ở sơ cấp tạo từ trường biến thiên, sinh dòng ở thứ cấp. U₂ = 220.250/500 = 110 V (hạ áp).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Ấm điện 220 V – 440 W dùng 3 giờ mỗi ngày. Tính điện năng tiêu thụ trong 30 ngày (kWh).',
     N'ESSAY', NULL,
     N'P = 440 W = 0.4 kW. A/ngày = 0.4.3 = 1.3 kWh. 30 ngày: 39.6 kWh.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Máy biến thế 200/400 vòng, cuộn sơ cấp đặt 220 V. Tính điện áp thứ cấp và cho biết tăng hay hạ áp.',
     N'ESSAY', NULL,
     N'U₂ = U₁.N₂/N₁ = 220.400/200 = 440 V. Tăng áp.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Bếp điện có dòng 2 A qua điện trở 7 Ω trong 1 phút. Tính nhiệt lượng tỏa ra.',
     N'ESSAY', NULL,
     N'Đổi t = 60 s. Q = I².R.t = 4.7.60 = 1680 J = 1 kJ.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Giải thích nguyên tắc hoạt động của máy biến thế và tính U₂ khi U₁ = 220 V, N₁ = 500, N₂ = 250.',
     N'ESSAY', NULL,
     N'Máy biến thế dựa trên cảm ứng điện từ: dòng biến thiên ở sơ cấp tạo từ trường biến thiên, sinh dòng ở thứ cấp. U₂ = 220.250/500 = 110 V (hạ áp).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Ấm điện 220 V – 1320 W dùng 7 giờ mỗi ngày. Tính điện năng tiêu thụ trong 30 ngày (kWh).',
     N'ESSAY', NULL,
     N'P = 1320 W = 1.3 kW. A/ngày = 1.3.7 = 9.2 kWh. 30 ngày: 277.2 kWh.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Máy biến thế 400/200 vòng, cuộn sơ cấp đặt 220 V. Tính điện áp thứ cấp và cho biết tăng hay hạ áp.',
     N'ESSAY', NULL,
     N'U₂ = U₁.N₂/N₁ = 220.200/400 = 110 V. Hạ áp.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Bếp điện có dòng 2 A qua điện trở 11 Ω trong 2 phút. Tính nhiệt lượng tỏa ra.',
     N'ESSAY', NULL,
     N'Đổi t = 120 s. Q = I².R.t = 4.11.120 = 5280 J = 5 kJ.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Giải thích nguyên tắc hoạt động của máy biến thế và tính U₂ khi U₁ = 220 V, N₁ = 500, N₂ = 250.',
     N'ESSAY', NULL,
     N'Máy biến thế dựa trên cảm ứng điện từ: dòng biến thiên ở sơ cấp tạo từ trường biến thiên, sinh dòng ở thứ cấp. U₂ = 220.250/500 = 110 V (hạ áp).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Ấm điện 220 V – 1100 W dùng 6 giờ mỗi ngày. Tính điện năng tiêu thụ trong 30 ngày (kWh).',
     N'ESSAY', NULL,
     N'P = 1100 W = 1.1 kW. A/ngày = 1.1.6 = 6.6 kWh. 30 ngày: 198.0 kWh.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Máy biến thế 300/150 vòng, cuộn sơ cấp đặt 220 V. Tính điện áp thứ cấp và cho biết tăng hay hạ áp.',
     N'ESSAY', NULL,
     N'U₂ = U₁.N₂/N₁ = 220.150/300 = 110 V. Hạ áp.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện năng, công suất và điện áp xoay chiều'),
     N'Bếp điện có dòng 2 A qua điện trở 5 Ω trong 3 phút. Tính nhiệt lượng tỏa ra.',
     N'ESSAY', NULL,
     N'Đổi t = 180 s. Q = I².R.t = 4.5.180 = 3600 J = 3 kJ.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Khúc xạ ánh sáng' : 20 MCQ
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng') AND QuestionType='MCQ' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, OptionA, OptionB, OptionC, OptionD, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ có tiêu cự:',
     N'MCQ', N'B',
     N'âm',
     N'dương',
     N'bằng 0',
     N'vô cực',
     N'Thấu kính hội tụ f > 0 (dương), thấu kính phân kì f < 0 (âm).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 30 cm, vật thật cách kính 60 cm. Ảnh cách kính:',
     N'MCQ', N'C',
     N'70 cm',
     N'50 cm',
     N'60 cm',
     N'30 cm',
     N'1/d'' = 1/f − 1/d = 1/30 − 1/60 = 1/60 nên d'' = 60 cm (ảnh thật).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Với f = 20 cm, d = 30 cm, d'' = 60 cm. Độ phóng đại của ảnh là:',
     N'MCQ', N'D',
     N'3 lần',
     N'1 lần',
     N'bằng vật',
     N'2 lần',
     N'|k| = d''/d = 60/30 = 2 lần (ảnh thật, ngược chiều).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật thật ngoài tiêu điểm (d = 40 cm > f = 20 cm). Tính chất ảnh là:',
     N'MCQ', N'A',
     N'ảnh thật, ngược chiều, bằng vật',
     N'ảnh ảo, cùng chiều, lớn hơn vật',
     N'ảnh thật, cùng chiều, bằng vật',
     N'không cho ảnh',
     N'd > f cho ảnh thật, ngược chiều; d'' = 40 cm so với d = 40 cm.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ có tiêu cự:',
     N'MCQ', N'B',
     N'âm',
     N'dương',
     N'bằng 0',
     N'vô cực',
     N'Thấu kính hội tụ f > 0 (dương), thấu kính phân kì f < 0 (âm).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Ánh sáng truyền từ không khí vào nước bị lệch về phía pháp tuyến. Hiện tượng đó là:',
     N'MCQ', N'C',
     N'tán sắc',
     N'phản xạ',
     N'khúc xạ',
     N'nhiễu xạ',
     N'Khúc xạ là sự đổi phương truyền khi đi qua mặt phân cách hai môi trường trong suốt.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 10 cm, vật thật cách kính 20 cm. Ảnh cách kính:',
     N'MCQ', N'D',
     N'30 cm',
     N'10 cm',
     N'10 cm',
     N'20 cm',
     N'1/d'' = 1/f − 1/d = 1/10 − 1/20 = 1/20 nên d'' = 20 cm (ảnh thật).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Với f = 30 cm, d = 60 cm, d'' = 60 cm. Độ phóng đại của ảnh là:',
     N'MCQ', N'A',
     N'1 lần',
     N'2 lần',
     N'1 lần',
     N'bằng vật',
     N'|k| = d''/d = 60/60 = 1 lần (ảnh thật, ngược chiều).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật thật ngoài tiêu điểm (d = 30 cm > f = 20 cm). Tính chất ảnh là:',
     N'MCQ', N'B',
     N'ảnh ảo, cùng chiều, lớn hơn vật',
     N'ảnh thật, ngược chiều, lớn hơn vật',
     N'ảnh thật, cùng chiều, bằng vật',
     N'không cho ảnh',
     N'd > f cho ảnh thật, ngược chiều; d'' = 60 cm so với d = 30 cm.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Ánh sáng truyền từ không khí vào nước bị lệch về phía pháp tuyến. Hiện tượng đó là:',
     N'MCQ', N'C',
     N'tán sắc',
     N'phản xạ',
     N'khúc xạ',
     N'nhiễu xạ',
     N'Khúc xạ là sự đổi phương truyền khi đi qua mặt phân cách hai môi trường trong suốt.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Điều kiện xảy ra phản xạ toàn phần là:',
     N'MCQ', N'D',
     N'đi từ môi trường kém sang hơn',
     N'góc tới bằng 0',
     N'ánh sáng đơn sắc',
     N'đi từ môi trường hơn sang kém và góc tới lớn hơn góc giới hạn',
     N'Cần hai điều kiện: truyền từ hơn sang kém và góc tới ≥ góc giới hạn.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 10 cm, vật thật cách kính 30 cm. Ảnh cách kính:',
     N'MCQ', N'A',
     N'15 cm',
     N'25 cm',
     N'5 cm',
     N'10 cm',
     N'1/d'' = 1/f − 1/d = 1/10 − 1/30 = 1/15 nên d'' = 15 cm (ảnh thật).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Với f = 10 cm, d = 20 cm, d'' = 20 cm. Độ phóng đại của ảnh là:',
     N'MCQ', N'B',
     N'2 lần',
     N'1 lần',
     N'1 lần',
     N'bằng vật',
     N'|k| = d''/d = 20/20 = 1 lần (ảnh thật, ngược chiều).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật thật ngoài tiêu điểm (d = 60 cm > f = 30 cm). Tính chất ảnh là:',
     N'MCQ', N'C',
     N'ảnh ảo, cùng chiều, lớn hơn vật',
     N'ảnh thật, cùng chiều, bằng vật',
     N'ảnh thật, ngược chiều, bằng vật',
     N'không cho ảnh',
     N'd > f cho ảnh thật, ngược chiều; d'' = 60 cm so với d = 60 cm.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Điều kiện xảy ra phản xạ toàn phần là:',
     N'MCQ', N'D',
     N'đi từ môi trường kém sang hơn',
     N'góc tới bằng 0',
     N'ánh sáng đơn sắc',
     N'đi từ môi trường hơn sang kém và góc tới lớn hơn góc giới hạn',
     N'Cần hai điều kiện: truyền từ hơn sang kém và góc tới ≥ góc giới hạn.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Kính lúp dùng để:',
     N'MCQ', N'A',
     N'nhìn vật rất nhỏ ở gần',
     N'nhìn vật ở xa',
     N'chụp ảnh',
     N'đo khoảng cách',
     N'Kính lúp là thấu kính hội tụ tiêu cự ngắn, cho ảnh ảo lớn hơn vật.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 20 cm, vật thật cách kính 60 cm. Ảnh cách kính:',
     N'MCQ', N'B',
     N'40 cm',
     N'30 cm',
     N'20 cm',
     N'20 cm',
     N'1/d'' = 1/f − 1/d = 1/20 − 1/60 = 1/30 nên d'' = 30 cm (ảnh thật).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Với f = 10 cm, d = 30 cm, d'' = 15 cm. Độ phóng đại của ảnh là:',
     N'MCQ', N'C',
     N'1 lần',
     N'1 lần',
     N'0.5 lần',
     N'bằng vật',
     N'|k| = d''/d = 15/30 = 0.5 lần (ảnh thật, ngược chiều).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật thật ngoài tiêu điểm (d = 20 cm > f = 10 cm). Tính chất ảnh là:',
     N'MCQ', N'D',
     N'ảnh ảo, cùng chiều, lớn hơn vật',
     N'ảnh thật, cùng chiều, bằng vật',
     N'không cho ảnh',
     N'ảnh thật, ngược chiều, bằng vật',
     N'd > f cho ảnh thật, ngược chiều; d'' = 20 cm so với d = 20 cm.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Kính lúp dùng để:',
     N'MCQ', N'A',
     N'nhìn vật rất nhỏ ở gần',
     N'nhìn vật ở xa',
     N'chụp ảnh',
     N'đo khoảng cách',
     N'Kính lúp là thấu kính hội tụ tiêu cự ngắn, cho ảnh ảo lớn hơn vật.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Khúc xạ ánh sáng' : 20 ESSAY
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng') AND QuestionType='ESSAY' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 20 cm, vật thật cách kính 40 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/20 − 1/40 = 1/40 ⇒ d'' = 40 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 60 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.60/40 = 30 cm. |k| = d''/d = 30/60 = 0.5 nên h'' = 1.0 cm (ảnh thật, ngược chiều).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 10 cm, vật thật cách kính 30 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/10 − 1/30 = 1/15 ⇒ d'' = 15 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 10 cm) 20 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 10.20/10 = 20 cm. |k| = d''/d = 20/20 = 1.0 nên h'' = 2.0 cm (ảnh thật, ngược chiều).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 30 cm, vật thật cách kính 60 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/30 − 1/60 = 1/60 ⇒ d'' = 60 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 30 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.30/10 = 60 cm. |k| = d''/d = 60/30 = 2.0 nên h'' = 4.0 cm (ảnh thật, ngược chiều).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 20 cm, vật thật cách kính 40 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/20 − 1/40 = 1/40 ⇒ d'' = 40 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 60 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.60/40 = 30 cm. |k| = d''/d = 30/60 = 0.5 nên h'' = 1.0 cm (ảnh thật, ngược chiều).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 10 cm, vật thật cách kính 30 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/10 − 1/30 = 1/15 ⇒ d'' = 15 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 10 cm) 20 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 10.20/10 = 20 cm. |k| = d''/d = 20/20 = 1.0 nên h'' = 2.0 cm (ảnh thật, ngược chiều).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 30 cm, vật thật cách kính 60 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/30 − 1/60 = 1/60 ⇒ d'' = 60 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 30 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.30/10 = 60 cm. |k| = d''/d = 60/30 = 2.0 nên h'' = 4.0 cm (ảnh thật, ngược chiều).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 20 cm, vật thật cách kính 40 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/20 − 1/40 = 1/40 ⇒ d'' = 40 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 60 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.60/40 = 30 cm. |k| = d''/d = 30/60 = 0.5 nên h'' = 1.0 cm (ảnh thật, ngược chiều).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 10 cm, vật thật cách kính 30 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/10 − 1/30 = 1/15 ⇒ d'' = 15 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 10 cm) 20 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 10.20/10 = 20 cm. |k| = d''/d = 20/20 = 1.0 nên h'' = 2.0 cm (ảnh thật, ngược chiều).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 30 cm, vật thật cách kính 60 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/30 − 1/60 = 1/60 ⇒ d'' = 60 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 30 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.30/10 = 60 cm. |k| = d''/d = 60/30 = 2.0 nên h'' = 4.0 cm (ảnh thật, ngược chiều).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Thấu kính hội tụ f = 20 cm, vật thật cách kính 40 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/20 − 1/40 = 1/40 ⇒ d'' = 40 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Khúc xạ ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 60 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.60/40 = 30 cm. |k| = d''/d = 30/60 = 0.5 nên h'' = 1.0 cm (ảnh thật, ngược chiều).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Tia và hiện tượng phát sáng' : 20 MCQ
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng') AND QuestionType='MCQ' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, OptionA, OptionB, OptionC, OptionD, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy thực hiện công toàn phần 3000 J với hiệu suất 75%. Công có ích là:',
     N'MCQ', N'B',
     N'3000 J',
     N'2250 J',
     N'750 J',
     N'2350 J',
     N'A_ích = H.A_tp = 75%.3000 = 2250 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy thực hiện công toàn phần 1000 J với hiệu suất 85%. Công có ích là:',
     N'MCQ', N'C',
     N'1000 J',
     N'150 J',
     N'850 J',
     N'950 J',
     N'A_ích = H.A_tp = 85%.1000 = 850 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Hộ gia đình dùng thiết bị 1000 W trong 5 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'D',
     N'6.0 kWh',
     N'4 kWh',
     N'5000 Wh',
     N'5 kWh',
     N'A = P.t = 1000.5 = 5000 Wh = 5 kWh.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Hiệu suất của máy cơ luôn:',
     N'MCQ', N'A',
     N'nhỏ hơn 100%',
     N'100%',
     N'lớn hơn 100%',
     N'bằng 0',
     N'Luôn có ma sát nên A_ích < A_toàn phần, H < 100%.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Vệt sáng trên màn hình khi dùng remote hồng ngoại là do:',
     N'MCQ', N'B',
     N'khúc xạ',
     N'phản xạ',
     N'tán sắc',
     N'truyền thẳng',
     N'Tia hồng ngoại phản xạ trên màn hình tạo điểm sáng.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy thực hiện công toàn phần 2000 J với hiệu suất 85%. Công có ích là:',
     N'MCQ', N'C',
     N'2000 J',
     N'300 J',
     N'1700 J',
     N'1800 J',
     N'A_ích = H.A_tp = 85%.2000 = 1700 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy thực hiện công toàn phần 3000 J với hiệu suất 90%. Công có ích là:',
     N'MCQ', N'D',
     N'3000 J',
     N'300 J',
     N'2800 J',
     N'2700 J',
     N'A_ích = H.A_tp = 90%.3000 = 2700 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Hộ gia đình dùng thiết bị 1000 W trong 2 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'A',
     N'2 kWh',
     N'3.0 kWh',
     N'1 kWh',
     N'2000 Wh',
     N'A = P.t = 1000.2 = 2000 Wh = 2 kWh.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Hiệu suất của máy cơ luôn:',
     N'MCQ', N'B',
     N'100%',
     N'nhỏ hơn 100%',
     N'lớn hơn 100%',
     N'bằng 0',
     N'Luôn có ma sát nên A_ích < A_toàn phần, H < 100%.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Vệt sáng trên màn hình khi dùng remote hồng ngoại là do:',
     N'MCQ', N'C',
     N'khúc xạ',
     N'tán sắc',
     N'phản xạ',
     N'truyền thẳng',
     N'Tia hồng ngoại phản xạ trên màn hình tạo điểm sáng.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy thực hiện công toàn phần 1000 J với hiệu suất 90%. Công có ích là:',
     N'MCQ', N'D',
     N'1000 J',
     N'100 J',
     N'1000 J',
     N'900 J',
     N'A_ích = H.A_tp = 90%.1000 = 900 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy thực hiện công toàn phần 2000 J với hiệu suất 80%. Công có ích là:',
     N'MCQ', N'A',
     N'1600 J',
     N'2000 J',
     N'400 J',
     N'1700 J',
     N'A_ích = H.A_tp = 80%.2000 = 1600 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Hộ gia đình dùng thiết bị 1000 W trong 3 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'B',
     N'4.0 kWh',
     N'3 kWh',
     N'2 kWh',
     N'3000 Wh',
     N'A = P.t = 1000.3 = 3000 Wh = 3 kWh.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Hiệu suất của máy cơ luôn:',
     N'MCQ', N'C',
     N'100%',
     N'lớn hơn 100%',
     N'nhỏ hơn 100%',
     N'bằng 0',
     N'Luôn có ma sát nên A_ích < A_toàn phần, H < 100%.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Vệt sáng trên màn hình khi dùng remote hồng ngoại là do:',
     N'MCQ', N'D',
     N'khúc xạ',
     N'tán sắc',
     N'truyền thẳng',
     N'phản xạ',
     N'Tia hồng ngoại phản xạ trên màn hình tạo điểm sáng.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy thực hiện công toàn phần 3000 J với hiệu suất 80%. Công có ích là:',
     N'MCQ', N'A',
     N'2400 J',
     N'3000 J',
     N'600 J',
     N'2500 J',
     N'A_ích = H.A_tp = 80%.3000 = 2400 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy thực hiện công toàn phần 1000 J với hiệu suất 75%. Công có ích là:',
     N'MCQ', N'B',
     N'1000 J',
     N'750 J',
     N'250 J',
     N'850 J',
     N'A_ích = H.A_tp = 75%.1000 = 750 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Hộ gia đình dùng thiết bị 1000 W trong 4 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'C',
     N'5.0 kWh',
     N'3 kWh',
     N'4 kWh',
     N'4000 Wh',
     N'A = P.t = 1000.4 = 4000 Wh = 4 kWh.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Hiệu suất của máy cơ luôn:',
     N'MCQ', N'D',
     N'100%',
     N'lớn hơn 100%',
     N'bằng 0',
     N'nhỏ hơn 100%',
     N'Luôn có ma sát nên A_ích < A_toàn phần, H < 100%.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Vệt sáng trên màn hình khi dùng remote hồng ngoại là do:',
     N'MCQ', N'A',
     N'phản xạ',
     N'khúc xạ',
     N'tán sắc',
     N'truyền thẳng',
     N'Tia hồng ngoại phản xạ trên màn hình tạo điểm sáng.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Tia và hiện tượng phát sáng' : 20 ESSAY
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng') AND QuestionType='ESSAY' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Tính tiền điện tháng cho thiết bị 1500 W dùng 3 giờ/ngày, giá 2000 đồng/kWh (30 ngày).',
     N'ESSAY', NULL,
     N'A/ngày = 1500.3 = 4500 Wh = 4.5 kWh. 30 ngày = 135.0 kWh ⇒ 270000 đồng.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'So sánh năng lượng hóa thạch và năng lượng tái tạo (ví dụ, ưu/nhược điểm).',
     N'ESSAY', NULL,
     N'Hóa thạch (than, dầu, khí): mật độ năng lượng cao nhưng gây ô nhiễm, cạn kiệt. Tái tạo (mặt trời, gió, nước): sạch, vô tận nhưng phụ thuộc thời tiết, vốn đầu tư cao.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Giải thích tại sao tia laze được dùng trong đầu đọc mã vạch và phẫu thuật mắt.',
     N'ESSAY', NULL,
     N'Laze đơn sắc, song song, định hướng cao, năng lượng tập trung nên đọc mã chính xác và cắt mổ siêu nhỏ, ít tổn thương mô xung quanh.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy nâng thực hiện công toàn phần 2000 J với hiệu suất 75%. Tính công có ích và phân tích năng lượng hao phí.',
     N'ESSAY', NULL,
     N'A_ích = 75%.2000 = 1500 J. Phần hao phí 500 J do ma sát, tiếng ồn, tỏa nhiệt.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Tính tiền điện tháng cho thiết bị 1500 W dùng 4 giờ/ngày, giá 2000 đồng/kWh (30 ngày).',
     N'ESSAY', NULL,
     N'A/ngày = 1500.4 = 6000 Wh = 6.0 kWh. 30 ngày = 180.0 kWh ⇒ 360000 đồng.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'So sánh năng lượng hóa thạch và năng lượng tái tạo (ví dụ, ưu/nhược điểm).',
     N'ESSAY', NULL,
     N'Hóa thạch (than, dầu, khí): mật độ năng lượng cao nhưng gây ô nhiễm, cạn kiệt. Tái tạo (mặt trời, gió, nước): sạch, vô tận nhưng phụ thuộc thời tiết, vốn đầu tư cao.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Giải thích tại sao tia laze được dùng trong đầu đọc mã vạch và phẫu thuật mắt.',
     N'ESSAY', NULL,
     N'Laze đơn sắc, song song, định hướng cao, năng lượng tập trung nên đọc mã chính xác và cắt mổ siêu nhỏ, ít tổn thương mô xung quanh.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy nâng thực hiện công toàn phần 2000 J với hiệu suất 75%. Tính công có ích và phân tích năng lượng hao phí.',
     N'ESSAY', NULL,
     N'A_ích = 75%.2000 = 1500 J. Phần hao phí 500 J do ma sát, tiếng ồn, tỏa nhiệt.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Tính tiền điện tháng cho thiết bị 1500 W dùng 2 giờ/ngày, giá 2000 đồng/kWh (30 ngày).',
     N'ESSAY', NULL,
     N'A/ngày = 1500.2 = 3000 Wh = 3.0 kWh. 30 ngày = 90.0 kWh ⇒ 180000 đồng.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'So sánh năng lượng hóa thạch và năng lượng tái tạo (ví dụ, ưu/nhược điểm).',
     N'ESSAY', NULL,
     N'Hóa thạch (than, dầu, khí): mật độ năng lượng cao nhưng gây ô nhiễm, cạn kiệt. Tái tạo (mặt trời, gió, nước): sạch, vô tận nhưng phụ thuộc thời tiết, vốn đầu tư cao.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Giải thích tại sao tia laze được dùng trong đầu đọc mã vạch và phẫu thuật mắt.',
     N'ESSAY', NULL,
     N'Laze đơn sắc, song song, định hướng cao, năng lượng tập trung nên đọc mã chính xác và cắt mổ siêu nhỏ, ít tổn thương mô xung quanh.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy nâng thực hiện công toàn phần 2000 J với hiệu suất 75%. Tính công có ích và phân tích năng lượng hao phí.',
     N'ESSAY', NULL,
     N'A_ích = 75%.2000 = 1500 J. Phần hao phí 500 J do ma sát, tiếng ồn, tỏa nhiệt.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Tính tiền điện tháng cho thiết bị 1500 W dùng 3 giờ/ngày, giá 2000 đồng/kWh (30 ngày).',
     N'ESSAY', NULL,
     N'A/ngày = 1500.3 = 4500 Wh = 4.5 kWh. 30 ngày = 135.0 kWh ⇒ 270000 đồng.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'So sánh năng lượng hóa thạch và năng lượng tái tạo (ví dụ, ưu/nhược điểm).',
     N'ESSAY', NULL,
     N'Hóa thạch (than, dầu, khí): mật độ năng lượng cao nhưng gây ô nhiễm, cạn kiệt. Tái tạo (mặt trời, gió, nước): sạch, vô tận nhưng phụ thuộc thời tiết, vốn đầu tư cao.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Giải thích tại sao tia laze được dùng trong đầu đọc mã vạch và phẫu thuật mắt.',
     N'ESSAY', NULL,
     N'Laze đơn sắc, song song, định hướng cao, năng lượng tập trung nên đọc mã chính xác và cắt mổ siêu nhỏ, ít tổn thương mô xung quanh.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy nâng thực hiện công toàn phần 2000 J với hiệu suất 75%. Tính công có ích và phân tích năng lượng hao phí.',
     N'ESSAY', NULL,
     N'A_ích = 75%.2000 = 1500 J. Phần hao phí 500 J do ma sát, tiếng ồn, tỏa nhiệt.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Tính tiền điện tháng cho thiết bị 1500 W dùng 4 giờ/ngày, giá 2000 đồng/kWh (30 ngày).',
     N'ESSAY', NULL,
     N'A/ngày = 1500.4 = 6000 Wh = 6.0 kWh. 30 ngày = 180.0 kWh ⇒ 360000 đồng.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'So sánh năng lượng hóa thạch và năng lượng tái tạo (ví dụ, ưu/nhược điểm).',
     N'ESSAY', NULL,
     N'Hóa thạch (than, dầu, khí): mật độ năng lượng cao nhưng gây ô nhiễm, cạn kiệt. Tái tạo (mặt trời, gió, nước): sạch, vô tận nhưng phụ thuộc thời tiết, vốn đầu tư cao.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Giải thích tại sao tia laze được dùng trong đầu đọc mã vạch và phẫu thuật mắt.',
     N'ESSAY', NULL,
     N'Laze đơn sắc, song song, định hướng cao, năng lượng tập trung nên đọc mã chính xác và cắt mổ siêu nhỏ, ít tổn thương mô xung quanh.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Tia và hiện tượng phát sáng'),
     N'Máy nâng thực hiện công toàn phần 2000 J với hiệu suất 75%. Tính công có ích và phân tích năng lượng hao phí.',
     N'ESSAY', NULL,
     N'A_ích = 75%.2000 = 1500 J. Phần hao phí 500 J do ma sát, tiếng ồn, tỏa nhiệt.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Năng lượng cơ học' : 20 MCQ
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học') AND QuestionType='MCQ' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, OptionA, OptionB, OptionC, OptionD, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật rơi tự do từ độ cao 5 m (g = 10 m/s², bỏ qua ma sát). Tốc độ khi chạm đất là:',
     N'MCQ', N'B',
     N'5 m/s',
     N'10 m/s',
     N'20 m/s',
     N'15 m/s',
     N'Bảo toàn cơ năng: m.g.h = m.v²/2 nên v = √(2.g.h) = √100 = 10 m/s.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 6 kg chuyển động với tốc độ 6 m/s. Động năng của vật là:',
     N'MCQ', N'C',
     N'36 J',
     N'216 J',
     N'108 J',
     N'128 J',
     N'Wđ = m.v²/2 = 6.36/2 = 108 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật nặng 4 kg được đưa lên cao 9 m (lấy g = 10 N/kg). Công của lực nâng là:',
     N'MCQ', N'D',
     N'36 J',
     N'3600 J',
     N'410 J',
     N'360 J',
     N'Công W = P.h = m.g.h = 4.10.9 = 360 J. Trọng lực ngược chiều chuyển động nên công của trọng lực là -360 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Một máy thực hiện công 315 J trong 15 s. Công suất của máy là:',
     N'MCQ', N'A',
     N'21 W',
     N'26 W',
     N'42 W',
     N'16 W',
     N'P = A/t = 315/15 = 21 W.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 4 kg ở độ cao 9 m so với mặt đất (g = 10 N/kg). Thế năng trọng trường của vật là:',
     N'MCQ', N'B',
     N'410 J',
     N'360 J',
     N'720 J',
     N'36 J',
     N'Wt = m.g.h = 4.10.9 = 360 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật rơi tự do từ độ cao 20 m (g = 10 m/s², bỏ qua ma sát). Tốc độ khi chạm đất là:',
     N'MCQ', N'C',
     N'10 m/s',
     N'40 m/s',
     N'20 m/s',
     N'25 m/s',
     N'Bảo toàn cơ năng: m.g.h = m.v²/2 nên v = √(2.g.h) = √400 = 20 m/s.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 6 kg chuyển động với tốc độ 8 m/s. Động năng của vật là:',
     N'MCQ', N'D',
     N'48 J',
     N'384 J',
     N'212 J',
     N'192 J',
     N'Wđ = m.v²/2 = 6.64/2 = 192 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật nặng 9 kg được đưa lên cao 6 m (lấy g = 10 N/kg). Công của lực nâng là:',
     N'MCQ', N'A',
     N'540 J',
     N'54 J',
     N'5400 J',
     N'590 J',
     N'Công W = P.h = m.g.h = 9.10.6 = 540 J. Trọng lực ngược chiều chuyển động nên công của trọng lực là -540 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Một máy thực hiện công 208 J trong 8 s. Công suất của máy là:',
     N'MCQ', N'B',
     N'31 W',
     N'26 W',
     N'52 W',
     N'21 W',
     N'P = A/t = 208/8 = 26 W.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 9 kg ở độ cao 9 m so với mặt đất (g = 10 N/kg). Thế năng trọng trường của vật là:',
     N'MCQ', N'C',
     N'860 J',
     N'1620 J',
     N'810 J',
     N'81 J',
     N'Wt = m.g.h = 9.10.9 = 810 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật rơi tự do từ độ cao 45 m (g = 10 m/s², bỏ qua ma sát). Tốc độ khi chạm đất là:',
     N'MCQ', N'D',
     N'15 m/s',
     N'60 m/s',
     N'35 m/s',
     N'30 m/s',
     N'Bảo toàn cơ năng: m.g.h = m.v²/2 nên v = √(2.g.h) = √900 = 30 m/s.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 6 kg chuyển động với tốc độ 10 m/s. Động năng của vật là:',
     N'MCQ', N'A',
     N'300 J',
     N'60 J',
     N'600 J',
     N'320 J',
     N'Wđ = m.v²/2 = 6.100/2 = 300 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật nặng 6 kg được đưa lên cao 3 m (lấy g = 10 N/kg). Công của lực nâng là:',
     N'MCQ', N'B',
     N'18 J',
     N'180 J',
     N'1800 J',
     N'230 J',
     N'Công W = P.h = m.g.h = 6.10.3 = 180 J. Trọng lực ngược chiều chuyển động nên công của trọng lực là -180 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Một máy thực hiện công 143 J trong 13 s. Công suất của máy là:',
     N'MCQ', N'C',
     N'16 W',
     N'22 W',
     N'11 W',
     N'6 W',
     N'P = A/t = 143/13 = 11 W.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 5 kg ở độ cao 9 m so với mặt đất (g = 10 N/kg). Thế năng trọng trường của vật là:',
     N'MCQ', N'D',
     N'500 J',
     N'900 J',
     N'45 J',
     N'450 J',
     N'Wt = m.g.h = 5.10.9 = 450 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật rơi tự do từ độ cao 80 m (g = 10 m/s², bỏ qua ma sát). Tốc độ khi chạm đất là:',
     N'MCQ', N'A',
     N'40 m/s',
     N'20 m/s',
     N'80 m/s',
     N'45 m/s',
     N'Bảo toàn cơ năng: m.g.h = m.v²/2 nên v = √(2.g.h) = √1600 = 40 m/s.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 6 kg chuyển động với tốc độ 4 m/s. Động năng của vật là:',
     N'MCQ', N'B',
     N'24 J',
     N'48 J',
     N'96 J',
     N'68 J',
     N'Wđ = m.v²/2 = 6.16/2 = 48 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật nặng 3 kg được đưa lên cao 9 m (lấy g = 10 N/kg). Công của lực nâng là:',
     N'MCQ', N'C',
     N'27 J',
     N'2700 J',
     N'270 J',
     N'320 J',
     N'Công W = P.h = m.g.h = 3.10.9 = 270 J. Trọng lực ngược chiều chuyển động nên công của trọng lực là -270 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Một máy thực hiện công 96 J trong 6 s. Công suất của máy là:',
     N'MCQ', N'D',
     N'21 W',
     N'32 W',
     N'11 W',
     N'16 W',
     N'P = A/t = 96/6 = 16 W.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 1 kg ở độ cao 9 m so với mặt đất (g = 10 N/kg). Thế năng trọng trường của vật là:',
     N'MCQ', N'A',
     N'90 J',
     N'140 J',
     N'180 J',
     N'9 J',
     N'Wt = m.g.h = 1.10.9 = 90 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Năng lượng cơ học' : 20 ESSAY
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học') AND QuestionType='ESSAY' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 4 kg được kéo đều lên cao 4 m. Tính công của lực kéo (g = 10 N/kg) và cho biết dấu của công trọng lực.',
     N'ESSAY', NULL,
     N'W_kéo = F.s = P.h = m.g.h = 4.10.4 = 160 J. Trọng lực ngược chiều chuyển động nên A_trọng_lực = -160 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Lực 140 N kéo vật đi 7 m trong 7 s. Tính công và công suất.',
     N'ESSAY', NULL,
     N'A = F.s = 140.7 = 980 J. P = A/t = 980/7 = 140 W.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Xe chuyển động biến đổi đều với vận tốc đầu 8 m/s, gia tốc 2 m/s². Tính quãng đường sau 6 s.',
     N'ESSAY', NULL,
     N's = v₀.t + a.t²/2 = 8.6 + 2.36/2 = 84 m.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 6 kg rơi tự do từ độ cao 5 m (g = 10 m/s², bỏ qua ma sát). Tính cơ năng ban đầu và tốc độ khi chạm đất.',
     N'ESSAY', NULL,
     N'Cơ năng ban đầu = thế năng: W = m.g.h = 6.10.5 = 300 J. Khi chạm đất Wđ = W nên v = √(2.g.h) = √100 = 10 m/s.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 8 kg được kéo đều lên cao 4 m. Tính công của lực kéo (g = 10 N/kg) và cho biết dấu của công trọng lực.',
     N'ESSAY', NULL,
     N'W_kéo = F.s = P.h = m.g.h = 8.10.4 = 320 J. Trọng lực ngược chiều chuyển động nên A_trọng_lực = -320 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Lực 220 N kéo vật đi 11 m trong 5 s. Tính công và công suất.',
     N'ESSAY', NULL,
     N'A = F.s = 220.11 = 2420 J. P = A/t = 2420/5 = 484 W.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Xe chuyển động biến đổi đều với vận tốc đầu 12 m/s, gia tốc 2 m/s². Tính quãng đường sau 5 s.',
     N'ESSAY', NULL,
     N's = v₀.t + a.t²/2 = 12.5 + 2.25/2 = 85 m.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 5 kg rơi tự do từ độ cao 5 m (g = 10 m/s², bỏ qua ma sát). Tính cơ năng ban đầu và tốc độ khi chạm đất.',
     N'ESSAY', NULL,
     N'Cơ năng ban đầu = thế năng: W = m.g.h = 5.10.5 = 250 J. Khi chạm đất Wđ = W nên v = √(2.g.h) = √100 = 10 m/s.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 5 kg được kéo đều lên cao 4 m. Tính công của lực kéo (g = 10 N/kg) và cho biết dấu của công trọng lực.',
     N'ESSAY', NULL,
     N'W_kéo = F.s = P.h = m.g.h = 5.10.4 = 200 J. Trọng lực ngược chiều chuyển động nên A_trọng_lực = -200 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Lực 300 N kéo vật đi 5 m trong 10 s. Tính công và công suất.',
     N'ESSAY', NULL,
     N'A = F.s = 300.5 = 1500 J. P = A/t = 1500/10 = 150 W.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Xe chuyển động biến đổi đều với vận tốc đầu 6 m/s, gia tốc 2 m/s². Tính quãng đường sau 4 s.',
     N'ESSAY', NULL,
     N's = v₀.t + a.t²/2 = 6.4 + 2.16/2 = 40 m.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 4 kg rơi tự do từ độ cao 5 m (g = 10 m/s², bỏ qua ma sát). Tính cơ năng ban đầu và tốc độ khi chạm đất.',
     N'ESSAY', NULL,
     N'Cơ năng ban đầu = thế năng: W = m.g.h = 4.10.5 = 200 J. Khi chạm đất Wđ = W nên v = √(2.g.h) = √100 = 10 m/s.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 9 kg được kéo đều lên cao 4 m. Tính công của lực kéo (g = 10 N/kg) và cho biết dấu của công trọng lực.',
     N'ESSAY', NULL,
     N'W_kéo = F.s = P.h = m.g.h = 9.10.4 = 360 J. Trọng lực ngược chiều chuyển động nên A_trọng_lực = -360 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Lực 380 N kéo vật đi 9 m trong 10 s. Tính công và công suất.',
     N'ESSAY', NULL,
     N'A = F.s = 380.9 = 3420 J. P = A/t = 3420/10 = 342 W.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Xe chuyển động biến đổi đều với vận tốc đầu 10 m/s, gia tốc 2 m/s². Tính quãng đường sau 3 s.',
     N'ESSAY', NULL,
     N's = v₀.t + a.t²/2 = 10.3 + 2.9/2 = 39 m.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 3 kg rơi tự do từ độ cao 5 m (g = 10 m/s², bỏ qua ma sát). Tính cơ năng ban đầu và tốc độ khi chạm đất.',
     N'ESSAY', NULL,
     N'Cơ năng ban đầu = thế năng: W = m.g.h = 3.10.5 = 150 J. Khi chạm đất Wđ = W nên v = √(2.g.h) = √100 = 10 m/s.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 6 kg được kéo đều lên cao 4 m. Tính công của lực kéo (g = 10 N/kg) và cho biết dấu của công trọng lực.',
     N'ESSAY', NULL,
     N'W_kéo = F.s = P.h = m.g.h = 6.10.4 = 240 J. Trọng lực ngược chiều chuyển động nên A_trọng_lực = -240 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Lực 460 N kéo vật đi 13 m trong 5 s. Tính công và công suất.',
     N'ESSAY', NULL,
     N'A = F.s = 460.13 = 5980 J. P = A/t = 5980/5 = 1196 W.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Xe chuyển động biến đổi đều với vận tốc đầu 14 m/s, gia tốc 2 m/s². Tính quãng đường sau 7 s.',
     N'ESSAY', NULL,
     N's = v₀.t + a.t²/2 = 14.7 + 2.49/2 = 147 m.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng cơ học'),
     N'Vật 2 kg rơi tự do từ độ cao 5 m (g = 10 m/s², bỏ qua ma sát). Tính cơ năng ban đầu và tốc độ khi chạm đất.',
     N'ESSAY', NULL,
     N'Cơ năng ban đầu = thế năng: W = m.g.h = 2.10.5 = 100 J. Khi chạm đất Wđ = W nên v = √(2.g.h) = √100 = 10 m/s.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Ánh sáng' : 20 MCQ
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng') AND QuestionType='MCQ' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, OptionA, OptionB, OptionC, OptionD, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Ánh sáng truyền từ không khí vào nước bị lệch về phía pháp tuyến. Hiện tượng đó là:',
     N'MCQ', N'B',
     N'tán sắc',
     N'khúc xạ',
     N'phản xạ',
     N'nhiễu xạ',
     N'Khúc xạ là sự đổi phương truyền khi đi qua mặt phân cách hai môi trường trong suốt.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 10 cm, vật thật cách kính 20 cm. Ảnh cách kính:',
     N'MCQ', N'C',
     N'30 cm',
     N'10 cm',
     N'20 cm',
     N'10 cm',
     N'1/d'' = 1/f − 1/d = 1/10 − 1/20 = 1/20 nên d'' = 20 cm (ảnh thật).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Với f = 30 cm, d = 60 cm, d'' = 60 cm. Độ phóng đại của ảnh là:',
     N'MCQ', N'D',
     N'2 lần',
     N'1 lần',
     N'bằng vật',
     N'1 lần',
     N'|k| = d''/d = 60/60 = 1 lần (ảnh thật, ngược chiều).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật thật ngoài tiêu điểm (d = 30 cm > f = 20 cm). Tính chất ảnh là:',
     N'MCQ', N'A',
     N'ảnh thật, ngược chiều, lớn hơn vật',
     N'ảnh ảo, cùng chiều, lớn hơn vật',
     N'ảnh thật, cùng chiều, bằng vật',
     N'không cho ảnh',
     N'd > f cho ảnh thật, ngược chiều; d'' = 60 cm so với d = 30 cm.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Ánh sáng truyền từ không khí vào nước bị lệch về phía pháp tuyến. Hiện tượng đó là:',
     N'MCQ', N'B',
     N'tán sắc',
     N'khúc xạ',
     N'phản xạ',
     N'nhiễu xạ',
     N'Khúc xạ là sự đổi phương truyền khi đi qua mặt phân cách hai môi trường trong suốt.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Điều kiện xảy ra phản xạ toàn phần là:',
     N'MCQ', N'C',
     N'đi từ môi trường kém sang hơn',
     N'góc tới bằng 0',
     N'đi từ môi trường hơn sang kém và góc tới lớn hơn góc giới hạn',
     N'ánh sáng đơn sắc',
     N'Cần hai điều kiện: truyền từ hơn sang kém và góc tới ≥ góc giới hạn.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 10 cm, vật thật cách kính 30 cm. Ảnh cách kính:',
     N'MCQ', N'D',
     N'25 cm',
     N'5 cm',
     N'10 cm',
     N'15 cm',
     N'1/d'' = 1/f − 1/d = 1/10 − 1/30 = 1/15 nên d'' = 15 cm (ảnh thật).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Với f = 10 cm, d = 20 cm, d'' = 20 cm. Độ phóng đại của ảnh là:',
     N'MCQ', N'A',
     N'1 lần',
     N'2 lần',
     N'1 lần',
     N'bằng vật',
     N'|k| = d''/d = 20/20 = 1 lần (ảnh thật, ngược chiều).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật thật ngoài tiêu điểm (d = 60 cm > f = 30 cm). Tính chất ảnh là:',
     N'MCQ', N'B',
     N'ảnh ảo, cùng chiều, lớn hơn vật',
     N'ảnh thật, ngược chiều, bằng vật',
     N'ảnh thật, cùng chiều, bằng vật',
     N'không cho ảnh',
     N'd > f cho ảnh thật, ngược chiều; d'' = 60 cm so với d = 60 cm.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Điều kiện xảy ra phản xạ toàn phần là:',
     N'MCQ', N'C',
     N'đi từ môi trường kém sang hơn',
     N'góc tới bằng 0',
     N'đi từ môi trường hơn sang kém và góc tới lớn hơn góc giới hạn',
     N'ánh sáng đơn sắc',
     N'Cần hai điều kiện: truyền từ hơn sang kém và góc tới ≥ góc giới hạn.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Kính lúp dùng để:',
     N'MCQ', N'D',
     N'nhìn vật ở xa',
     N'chụp ảnh',
     N'đo khoảng cách',
     N'nhìn vật rất nhỏ ở gần',
     N'Kính lúp là thấu kính hội tụ tiêu cự ngắn, cho ảnh ảo lớn hơn vật.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 20 cm, vật thật cách kính 60 cm. Ảnh cách kính:',
     N'MCQ', N'A',
     N'30 cm',
     N'40 cm',
     N'20 cm',
     N'20 cm',
     N'1/d'' = 1/f − 1/d = 1/20 − 1/60 = 1/30 nên d'' = 30 cm (ảnh thật).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Với f = 10 cm, d = 30 cm, d'' = 15 cm. Độ phóng đại của ảnh là:',
     N'MCQ', N'B',
     N'1 lần',
     N'0.5 lần',
     N'1 lần',
     N'bằng vật',
     N'|k| = d''/d = 15/30 = 0.5 lần (ảnh thật, ngược chiều).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật thật ngoài tiêu điểm (d = 20 cm > f = 10 cm). Tính chất ảnh là:',
     N'MCQ', N'C',
     N'ảnh ảo, cùng chiều, lớn hơn vật',
     N'ảnh thật, cùng chiều, bằng vật',
     N'ảnh thật, ngược chiều, bằng vật',
     N'không cho ảnh',
     N'd > f cho ảnh thật, ngược chiều; d'' = 20 cm so với d = 20 cm.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Kính lúp dùng để:',
     N'MCQ', N'D',
     N'nhìn vật ở xa',
     N'chụp ảnh',
     N'đo khoảng cách',
     N'nhìn vật rất nhỏ ở gần',
     N'Kính lúp là thấu kính hội tụ tiêu cự ngắn, cho ảnh ảo lớn hơn vật.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ có tiêu cự:',
     N'MCQ', N'A',
     N'dương',
     N'âm',
     N'bằng 0',
     N'vô cực',
     N'Thấu kính hội tụ f > 0 (dương), thấu kính phân kì f < 0 (âm).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 20 cm, vật thật cách kính 40 cm. Ảnh cách kính:',
     N'MCQ', N'B',
     N'50 cm',
     N'40 cm',
     N'30 cm',
     N'20 cm',
     N'1/d'' = 1/f − 1/d = 1/20 − 1/40 = 1/40 nên d'' = 40 cm (ảnh thật).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Với f = 20 cm, d = 60 cm, d'' = 30 cm. Độ phóng đại của ảnh là:',
     N'MCQ', N'C',
     N'1 lần',
     N'1 lần',
     N'0.5 lần',
     N'bằng vật',
     N'|k| = d''/d = 30/60 = 0.5 lần (ảnh thật, ngược chiều).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật thật ngoài tiêu điểm (d = 30 cm > f = 10 cm). Tính chất ảnh là:',
     N'MCQ', N'D',
     N'ảnh ảo, cùng chiều, lớn hơn vật',
     N'ảnh thật, cùng chiều, bằng vật',
     N'không cho ảnh',
     N'ảnh thật, ngược chiều, nhỏ hơn vật',
     N'd > f cho ảnh thật, ngược chiều; d'' = 15 cm so với d = 30 cm.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ có tiêu cự:',
     N'MCQ', N'A',
     N'dương',
     N'âm',
     N'bằng 0',
     N'vô cực',
     N'Thấu kính hội tụ f > 0 (dương), thấu kính phân kì f < 0 (âm).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Ánh sáng' : 20 ESSAY
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng') AND QuestionType='ESSAY' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 20 cm, vật thật cách kính 40 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/20 − 1/40 = 1/40 ⇒ d'' = 40 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 60 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.60/40 = 30 cm. |k| = d''/d = 30/60 = 0.5 nên h'' = 1.0 cm (ảnh thật, ngược chiều).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 10 cm, vật thật cách kính 30 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/10 − 1/30 = 1/15 ⇒ d'' = 15 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 10 cm) 20 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 10.20/10 = 20 cm. |k| = d''/d = 20/20 = 1.0 nên h'' = 2.0 cm (ảnh thật, ngược chiều).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 30 cm, vật thật cách kính 60 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/30 − 1/60 = 1/60 ⇒ d'' = 60 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 30 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.30/10 = 60 cm. |k| = d''/d = 60/30 = 2.0 nên h'' = 4.0 cm (ảnh thật, ngược chiều).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 20 cm, vật thật cách kính 40 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/20 − 1/40 = 1/40 ⇒ d'' = 40 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 60 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.60/40 = 30 cm. |k| = d''/d = 30/60 = 0.5 nên h'' = 1.0 cm (ảnh thật, ngược chiều).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 10 cm, vật thật cách kính 30 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/10 − 1/30 = 1/15 ⇒ d'' = 15 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 10 cm) 20 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 10.20/10 = 20 cm. |k| = d''/d = 20/20 = 1.0 nên h'' = 2.0 cm (ảnh thật, ngược chiều).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 30 cm, vật thật cách kính 60 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/30 − 1/60 = 1/60 ⇒ d'' = 60 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 30 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.30/10 = 60 cm. |k| = d''/d = 60/30 = 2.0 nên h'' = 4.0 cm (ảnh thật, ngược chiều).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 20 cm, vật thật cách kính 40 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/20 − 1/40 = 1/40 ⇒ d'' = 40 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 60 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.60/40 = 30 cm. |k| = d''/d = 30/60 = 0.5 nên h'' = 1.0 cm (ảnh thật, ngược chiều).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 10 cm, vật thật cách kính 30 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/10 − 1/30 = 1/15 ⇒ d'' = 15 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 10 cm) 20 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 10.20/10 = 20 cm. |k| = d''/d = 20/20 = 1.0 nên h'' = 2.0 cm (ảnh thật, ngược chiều).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 30 cm, vật thật cách kính 60 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/30 − 1/60 = 1/60 ⇒ d'' = 60 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 30 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.30/10 = 60 cm. |k| = d''/d = 60/30 = 2.0 nên h'' = 4.0 cm (ảnh thật, ngược chiều).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Thấu kính hội tụ f = 20 cm, vật thật cách kính 40 cm. Tính vị trí ảnh và nêu tính chất ảnh.',
     N'ESSAY', NULL,
     N'1/d'' = 1/20 − 1/40 = 1/40 ⇒ d'' = 40 cm. Vật thật ngoài tiêu điểm nên ảnh thật, ngược chiều với vật.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Ánh sáng'),
     N'Vật sáng AB cao 2 cm đặt vuông góc trục chính, cách thấu kính hội tụ (f = 20 cm) 60 cm. Tính vị trí, độ cao ảnh.',
     N'ESSAY', NULL,
     N'd'' = f.d/(d−f) = 20.60/40 = 30 cm. |k| = d''/d = 30/60 = 0.5 nên h'' = 1.0 cm (ảnh thật, ngược chiều).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Điện' : 20 MCQ
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện') AND QuestionType='MCQ' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, OptionA, OptionB, OptionC, OptionD, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 1 A chạy qua dây dẫn trong 4 s. Điện lượng qua tiết diện dây là:',
     N'MCQ', N'B',
     N'5 C',
     N'4 C',
     N'3 C',
     N'5 C',
     N'Q = I.t = 1.4 = 4 C.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 2 A chạy qua điện trở 17 Ω. Hiệu điện thế hai đầu điện trở là:',
     N'MCQ', N'C',
     N'51 V',
     N'17 V',
     N'34 V',
     N'19 V',
     N'U = I.R = 2.17 = 34 V.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Đặt hiệu điện thế 28 V vào dây dẫn thì dòng điện qua dây là 4 A. Điện trở của dây là:',
     N'MCQ', N'D',
     N'9 Ω',
     N'5 Ω',
     N'32 Ω',
     N'7 Ω',
     N'R = U/I = 28/4 = 7 Ω.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 5 Ω và 10 Ω mắc nối tiếp. Điện trở tương đương là:',
     N'MCQ', N'A',
     N'15 Ω',
     N'5 Ω',
     N'50 Ω',
     N'12 Ω',
     N'Nối tiếp: R_tđ = R₁ + R₂ = 5 + 10 = 15 Ω.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 6 Ω và 12 Ω mắc song song. Điện trở tương đương là:',
     N'MCQ', N'B',
     N'18 Ω',
     N'4 Ω',
     N'6 Ω',
     N'72 Ω',
     N'Song song: R_tđ = R₁.R₂/(R₁+R₂) = 6.12/18 = 4 Ω.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 1 A chạy qua dây dẫn trong 9 s. Điện lượng qua tiết diện dây là:',
     N'MCQ', N'C',
     N'10 C',
     N'8 C',
     N'9 C',
     N'10 C',
     N'Q = I.t = 1.9 = 9 C.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 2 A chạy qua điện trở 12 Ω. Hiệu điện thế hai đầu điện trở là:',
     N'MCQ', N'D',
     N'36 V',
     N'12 V',
     N'14 V',
     N'24 V',
     N'U = I.R = 2.12 = 24 V.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Đặt hiệu điện thế 16 V vào dây dẫn thì dòng điện qua dây là 4 A. Điện trở của dây là:',
     N'MCQ', N'A',
     N'4 Ω',
     N'6 Ω',
     N'2 Ω',
     N'20 Ω',
     N'R = U/I = 16/4 = 4 Ω.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 10 Ω và 10 Ω mắc nối tiếp. Điện trở tương đương là:',
     N'MCQ', N'B',
     N'0 Ω',
     N'20 Ω',
     N'100 Ω',
     N'17 Ω',
     N'Nối tiếp: R_tđ = R₁ + R₂ = 10 + 10 = 20 Ω.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 9 Ω và 18 Ω mắc song song. Điện trở tương đương là:',
     N'MCQ', N'C',
     N'27 Ω',
     N'8 Ω',
     N'6 Ω',
     N'162 Ω',
     N'Song song: R_tđ = R₁.R₂/(R₁+R₂) = 9.18/27 = 6 Ω.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 1 A chạy qua dây dẫn trong 6 s. Điện lượng qua tiết diện dây là:',
     N'MCQ', N'D',
     N'7 C',
     N'5 C',
     N'7 C',
     N'6 C',
     N'Q = I.t = 1.6 = 6 C.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 2 A chạy qua điện trở 7 Ω. Hiệu điện thế hai đầu điện trở là:',
     N'MCQ', N'A',
     N'14 V',
     N'21 V',
     N'7 V',
     N'9 V',
     N'U = I.R = 2.7 = 14 V.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Đặt hiệu điện thế 36 V vào dây dẫn thì dòng điện qua dây là 4 A. Điện trở của dây là:',
     N'MCQ', N'B',
     N'11 Ω',
     N'9 Ω',
     N'7 Ω',
     N'40 Ω',
     N'R = U/I = 36/4 = 9 Ω.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 5 Ω và 10 Ω mắc nối tiếp. Điện trở tương đương là:',
     N'MCQ', N'C',
     N'5 Ω',
     N'50 Ω',
     N'15 Ω',
     N'12 Ω',
     N'Nối tiếp: R_tđ = R₁ + R₂ = 5 + 10 = 15 Ω.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 6 Ω và 12 Ω mắc song song. Điện trở tương đương là:',
     N'MCQ', N'D',
     N'18 Ω',
     N'6 Ω',
     N'72 Ω',
     N'4 Ω',
     N'Song song: R_tđ = R₁.R₂/(R₁+R₂) = 6.12/18 = 4 Ω.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 1 A chạy qua dây dẫn trong 3 s. Điện lượng qua tiết diện dây là:',
     N'MCQ', N'A',
     N'3 C',
     N'4 C',
     N'2 C',
     N'4 C',
     N'Q = I.t = 1.3 = 3 C.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 2 A chạy qua điện trở 2 Ω. Hiệu điện thế hai đầu điện trở là:',
     N'MCQ', N'B',
     N'6 V',
     N'4 V',
     N'2 V',
     N'4 V',
     N'U = I.R = 2.2 = 4 V.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Đặt hiệu điện thế 24 V vào dây dẫn thì dòng điện qua dây là 4 A. Điện trở của dây là:',
     N'MCQ', N'C',
     N'8 Ω',
     N'4 Ω',
     N'6 Ω',
     N'28 Ω',
     N'R = U/I = 24/4 = 6 Ω.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 10 Ω và 10 Ω mắc nối tiếp. Điện trở tương đương là:',
     N'MCQ', N'D',
     N'0 Ω',
     N'100 Ω',
     N'17 Ω',
     N'20 Ω',
     N'Nối tiếp: R_tđ = R₁ + R₂ = 10 + 10 = 20 Ω.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 9 Ω và 18 Ω mắc song song. Điện trở tương đương là:',
     N'MCQ', N'A',
     N'6 Ω',
     N'27 Ω',
     N'8 Ω',
     N'162 Ω',
     N'Song song: R_tđ = R₁.R₂/(R₁+R₂) = 9.18/27 = 6 Ω.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Điện' : 20 ESSAY
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện') AND QuestionType='ESSAY' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 2 A chạy qua bóng đèn trong 6 s. Tính điện lượng dịch chuyển và số electron (e = 1,6.10⁻¹⁹ C).',
     N'ESSAY', NULL,
     N'Q = I.t = 2.6 = 12 C. Số electron n = Q/e = 12/(1,6.10⁻¹⁹) ≈ 7.50.10¹⁹ hạt.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Đặt hiệu điện thế 18 V vào hai đầu điện trở 5 Ω. Tính dòng điện và nêu cách mắc ampe kế, vôn kế để kiểm tra.',
     N'ESSAY', NULL,
     N'I = U/R = 18/5 ≈ 3.60 A. Mắc ampe kế nối tiếp, vôn kế song song với điện trở.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 5 Ω và 9 Ω mắc nối tiếp vào nguồn 12 V. Tính R_tđ và cường độ dòng điện.',
     N'ESSAY', NULL,
     N'R_tđ = 5 + 9 = 14 Ω. I = U/R_tđ = 12/14 = 0.86 A.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 6 Ω và 12 Ω mắc song song vào nguồn 12 V. Tính R_tđ và dòng qua mỗi nhánh.',
     N'ESSAY', NULL,
     N'R_tđ = 6.12/18 = 4.00 Ω. I₁ = 12/6 = 2.00 A, I₂ = 12/12 = 1.00 A.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 2 A chạy qua bóng đèn trong 10 s. Tính điện lượng dịch chuyển và số electron (e = 1,6.10⁻¹⁹ C).',
     N'ESSAY', NULL,
     N'Q = I.t = 2.10 = 20 C. Số electron n = Q/e = 20/(1,6.10⁻¹⁹) ≈ 12.50.10¹⁹ hạt.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Đặt hiệu điện thế 18 V vào hai đầu điện trở 9 Ω. Tính dòng điện và nêu cách mắc ampe kế, vôn kế để kiểm tra.',
     N'ESSAY', NULL,
     N'I = U/R = 18/9 ≈ 2.00 A. Mắc ampe kế nối tiếp, vôn kế song song với điện trở.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 9 Ω và 9 Ω mắc nối tiếp vào nguồn 12 V. Tính R_tđ và cường độ dòng điện.',
     N'ESSAY', NULL,
     N'R_tđ = 9 + 9 = 18 Ω. I = U/R_tđ = 12/18 = 0.67 A.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 5 Ω và 20 Ω mắc song song vào nguồn 12 V. Tính R_tđ và dòng qua mỗi nhánh.',
     N'ESSAY', NULL,
     N'R_tđ = 5.20/25 = 4.00 Ω. I₁ = 12/5 = 2.40 A, I₂ = 12/20 = 0.60 A.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 2 A chạy qua bóng đèn trong 14 s. Tính điện lượng dịch chuyển và số electron (e = 1,6.10⁻¹⁹ C).',
     N'ESSAY', NULL,
     N'Q = I.t = 2.14 = 28 C. Số electron n = Q/e = 28/(1,6.10⁻¹⁹) ≈ 17.50.10¹⁹ hạt.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Đặt hiệu điện thế 18 V vào hai đầu điện trở 4 Ω. Tính dòng điện và nêu cách mắc ampe kế, vôn kế để kiểm tra.',
     N'ESSAY', NULL,
     N'I = U/R = 18/4 ≈ 4.50 A. Mắc ampe kế nối tiếp, vôn kế song song với điện trở.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 5 Ω và 9 Ω mắc nối tiếp vào nguồn 12 V. Tính R_tđ và cường độ dòng điện.',
     N'ESSAY', NULL,
     N'R_tđ = 5 + 9 = 14 Ω. I = U/R_tđ = 12/14 = 0.86 A.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 6 Ω và 3 Ω mắc song song vào nguồn 12 V. Tính R_tđ và dòng qua mỗi nhánh.',
     N'ESSAY', NULL,
     N'R_tđ = 6.3/9 = 2.00 Ω. I₁ = 12/6 = 2.00 A, I₂ = 12/3 = 4.00 A.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 2 A chạy qua bóng đèn trong 8 s. Tính điện lượng dịch chuyển và số electron (e = 1,6.10⁻¹⁹ C).',
     N'ESSAY', NULL,
     N'Q = I.t = 2.8 = 16 C. Số electron n = Q/e = 16/(1,6.10⁻¹⁹) ≈ 10.00.10¹⁹ hạt.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Đặt hiệu điện thế 18 V vào hai đầu điện trở 8 Ω. Tính dòng điện và nêu cách mắc ampe kế, vôn kế để kiểm tra.',
     N'ESSAY', NULL,
     N'I = U/R = 18/8 ≈ 2.25 A. Mắc ampe kế nối tiếp, vôn kế song song với điện trở.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 9 Ω và 9 Ω mắc nối tiếp vào nguồn 12 V. Tính R_tđ và cường độ dòng điện.',
     N'ESSAY', NULL,
     N'R_tđ = 9 + 9 = 18 Ω. I = U/R_tđ = 12/18 = 0.67 A.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 8 Ω và 8 Ω mắc song song vào nguồn 12 V. Tính R_tđ và dòng qua mỗi nhánh.',
     N'ESSAY', NULL,
     N'R_tđ = 8.8/16 = 4.00 Ω. I₁ = 12/8 = 1.50 A, I₂ = 12/8 = 1.50 A.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Dòng điện 2 A chạy qua bóng đèn trong 12 s. Tính điện lượng dịch chuyển và số electron (e = 1,6.10⁻¹⁹ C).',
     N'ESSAY', NULL,
     N'Q = I.t = 2.12 = 24 C. Số electron n = Q/e = 24/(1,6.10⁻¹⁹) ≈ 15.00.10¹⁹ hạt.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Đặt hiệu điện thế 18 V vào hai đầu điện trở 3 Ω. Tính dòng điện và nêu cách mắc ampe kế, vôn kế để kiểm tra.',
     N'ESSAY', NULL,
     N'I = U/R = 18/3 ≈ 6.00 A. Mắc ampe kế nối tiếp, vôn kế song song với điện trở.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 5 Ω và 9 Ω mắc nối tiếp vào nguồn 12 V. Tính R_tđ và cường độ dòng điện.',
     N'ESSAY', NULL,
     N'R_tđ = 5 + 9 = 14 Ω. I = U/R_tđ = 12/14 = 0.86 A.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện'),
     N'Hai điện trở 2 Ω và 2 Ω mắc song song vào nguồn 12 V. Tính R_tđ và dòng qua mỗi nhánh.',
     N'ESSAY', NULL,
     N'R_tđ = 2.2/4 = 1.00 Ω. I₁ = 12/2 = 6.00 A, I₂ = 12/2 = 6.00 A.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Điện từ' : 20 MCQ
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ') AND QuestionType='MCQ' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, OptionA, OptionB, OptionC, OptionD, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Thiết bị 4 kW hoạt động 7 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'B',
     N'32 kWh',
     N'28 kWh',
     N'24 kWh',
     N'11 kWh',
     N'A = P.t = 4.7 = 28 kWh = 28.3,6.10⁶ J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Máy biến thế có 500 vòng sơ cấp, 100 vòng thứ cấp, đặt 220 V vào sơ cấp. Điện áp thứ cấp là:',
     N'MCQ', N'C',
     N'88 V',
     N'22 V',
     N'44 V',
     N'220 V',
     N'U₂ = U₁.N₂/N₁ = 220.100/500 = 44 V.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Dòng 2 A qua điện trở 5 Ω trong 120 s. Nhiệt lượng tỏa ra là:',
     N'MCQ', N'D',
     N'1200 J',
     N'4800 J',
     N'2300 J',
     N'2400 J',
     N'Q = I².R.t = 4.5.120 = 2400 J (định luật Jun – Len-xơ).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Dòng điện xoay chiều có tần số 25 Hz. Chu kì của dòng điện là:',
     N'MCQ', N'A',
     N'40 ms',
     N'20 ms',
     N'67 ms',
     N'25 Hz',
     N'T = 1/f = 1/25 ≈ 0.0400 s = 40 ms.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Thiết bị dùng ở mạng 220 V với dòng điện 5 A. Công suất tiêu thụ là:',
     N'MCQ', N'B',
     N'1320 W',
     N'1.1 kW',
     N'880 W',
     N'225 W',
     N'P = U.I = 220.5 = 1100 W.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Thiết bị 1 kW hoạt động 6 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'C',
     N'7 kWh',
     N'5 kWh',
     N'6 kWh',
     N'7 kWh',
     N'A = P.t = 1.6 = 6 kWh = 6.3,6.10⁶ J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Máy biến thế có 500 vòng sơ cấp, 100 vòng thứ cấp, đặt 220 V vào sơ cấp. Điện áp thứ cấp là:',
     N'MCQ', N'D',
     N'88 V',
     N'22 V',
     N'220 V',
     N'44 V',
     N'U₂ = U₁.N₂/N₁ = 220.100/500 = 44 V.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Dòng 3 A qua điện trở 10 Ω trong 60 s. Nhiệt lượng tỏa ra là:',
     N'MCQ', N'A',
     N'5400 J',
     N'1800 J',
     N'10800 J',
     N'5300 J',
     N'Q = I².R.t = 9.10.60 = 5400 J (định luật Jun – Len-xơ).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Dòng điện xoay chiều có tần số 60 Hz. Chu kì của dòng điện là:',
     N'MCQ', N'B',
     N'8 ms',
     N'16.7 ms',
     N'20 ms',
     N'60 Hz',
     N'T = 1/f = 1/60 ≈ 0.0167 s = 16.7 ms.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Thiết bị dùng ở mạng 110 V với dòng điện 4 A. Công suất tiêu thụ là:',
     N'MCQ', N'C',
     N'550 W',
     N'330 W',
     N'440 W',
     N'114 W',
     N'P = U.I = 110.4 = 440 W.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Thiết bị 2 kW hoạt động 5 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'D',
     N'12 kWh',
     N'8 kWh',
     N'7 kWh',
     N'10 kWh',
     N'A = P.t = 2.5 = 10 kWh = 10.3,6.10⁶ J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Máy biến thế có 500 vòng sơ cấp, 100 vòng thứ cấp, đặt 220 V vào sơ cấp. Điện áp thứ cấp là:',
     N'MCQ', N'A',
     N'44 V',
     N'88 V',
     N'22 V',
     N'220 V',
     N'U₂ = U₁.N₂/N₁ = 220.100/500 = 44 V.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Dòng 4 A qua điện trở 5 Ω trong 180 s. Nhiệt lượng tỏa ra là:',
     N'MCQ', N'B',
     N'3600 J',
     N'14400 J',
     N'28800 J',
     N'14300 J',
     N'Q = I².R.t = 16.5.180 = 14400 J (định luật Jun – Len-xơ).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Dòng điện xoay chiều có tần số 50 Hz. Chu kì của dòng điện là:',
     N'MCQ', N'C',
     N'10 ms',
     N'25 ms',
     N'20 ms',
     N'50 Hz',
     N'T = 1/f = 1/50 ≈ 0.0200 s = 20 ms.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Thiết bị dùng ở mạng 220 V với dòng điện 3 A. Công suất tiêu thụ là:',
     N'MCQ', N'D',
     N'880 W',
     N'440 W',
     N'223 W',
     N'660 W',
     N'P = U.I = 220.3 = 660 W.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Thiết bị 3 kW hoạt động 4 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'A',
     N'12 kWh',
     N'15 kWh',
     N'9 kWh',
     N'7 kWh',
     N'A = P.t = 3.4 = 12 kWh = 12.3,6.10⁶ J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Máy biến thế có 500 vòng sơ cấp, 100 vòng thứ cấp, đặt 220 V vào sơ cấp. Điện áp thứ cấp là:',
     N'MCQ', N'B',
     N'88 V',
     N'44 V',
     N'22 V',
     N'220 V',
     N'U₂ = U₁.N₂/N₁ = 220.100/500 = 44 V.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Dòng 1 A qua điện trở 10 Ω trong 120 s. Nhiệt lượng tỏa ra là:',
     N'MCQ', N'C',
     N'1200 J',
     N'2400 J',
     N'1200 J',
     N'1100 J',
     N'Q = I².R.t = 1.10.120 = 1200 J (định luật Jun – Len-xơ).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Dòng điện xoay chiều có tần số 100 Hz. Chu kì của dòng điện là:',
     N'MCQ', N'D',
     N'5 ms',
     N'11 ms',
     N'100 Hz',
     N'10 ms',
     N'T = 1/f = 1/100 ≈ 0.0100 s = 10 ms.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Thiết bị dùng ở mạng 110 V với dòng điện 2 A. Công suất tiêu thụ là:',
     N'MCQ', N'A',
     N'220 W',
     N'330 W',
     N'110 W',
     N'112 W',
     N'P = U.I = 110.2 = 220 W.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Điện từ' : 20 ESSAY
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ') AND QuestionType='ESSAY' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Giải thích nguyên tắc hoạt động của máy biến thế và tính U₂ khi U₁ = 220 V, N₁ = 500, N₂ = 250.',
     N'ESSAY', NULL,
     N'Máy biến thế dựa trên cảm ứng điện từ: dòng biến thiên ở sơ cấp tạo từ trường biến thiên, sinh dòng ở thứ cấp. U₂ = 220.250/500 = 110 V (hạ áp).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Ấm điện 220 V – 880 W dùng 5 giờ mỗi ngày. Tính điện năng tiêu thụ trong 30 ngày (kWh).',
     N'ESSAY', NULL,
     N'P = 880 W = 0.9 kW. A/ngày = 0.9.5 = 4.4 kWh. 30 ngày: 132.0 kWh.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Máy biến thế 100/1000 vòng, cuộn sơ cấp đặt 220 V. Tính điện áp thứ cấp và cho biết tăng hay hạ áp.',
     N'ESSAY', NULL,
     N'U₂ = U₁.N₂/N₁ = 220.1000/100 = 2200 V. Tăng áp.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Bếp điện có dòng 2 A qua điện trở 9 Ω trong 2 phút. Tính nhiệt lượng tỏa ra.',
     N'ESSAY', NULL,
     N'Đổi t = 120 s. Q = I².R.t = 4.9.120 = 4320 J = 4 kJ.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Giải thích nguyên tắc hoạt động của máy biến thế và tính U₂ khi U₁ = 220 V, N₁ = 500, N₂ = 250.',
     N'ESSAY', NULL,
     N'Máy biến thế dựa trên cảm ứng điện từ: dòng biến thiên ở sơ cấp tạo từ trường biến thiên, sinh dòng ở thứ cấp. U₂ = 220.250/500 = 110 V (hạ áp).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Ấm điện 220 V – 660 W dùng 4 giờ mỗi ngày. Tính điện năng tiêu thụ trong 30 ngày (kWh).',
     N'ESSAY', NULL,
     N'P = 660 W = 0.7 kW. A/ngày = 0.7.4 = 2.6 kWh. 30 ngày: 79.2 kWh.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Máy biến thế 500/100 vòng, cuộn sơ cấp đặt 220 V. Tính điện áp thứ cấp và cho biết tăng hay hạ áp.',
     N'ESSAY', NULL,
     N'U₂ = U₁.N₂/N₁ = 220.100/500 = 44 V. Hạ áp.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Bếp điện có dòng 2 A qua điện trở 13 Ω trong 3 phút. Tính nhiệt lượng tỏa ra.',
     N'ESSAY', NULL,
     N'Đổi t = 180 s. Q = I².R.t = 4.13.180 = 9360 J = 9 kJ.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Giải thích nguyên tắc hoạt động của máy biến thế và tính U₂ khi U₁ = 220 V, N₁ = 500, N₂ = 250.',
     N'ESSAY', NULL,
     N'Máy biến thế dựa trên cảm ứng điện từ: dòng biến thiên ở sơ cấp tạo từ trường biến thiên, sinh dòng ở thứ cấp. U₂ = 220.250/500 = 110 V (hạ áp).',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Ấm điện 220 V – 440 W dùng 3 giờ mỗi ngày. Tính điện năng tiêu thụ trong 30 ngày (kWh).',
     N'ESSAY', NULL,
     N'P = 440 W = 0.4 kW. A/ngày = 0.4.3 = 1.3 kWh. 30 ngày: 39.6 kWh.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Máy biến thế 200/400 vòng, cuộn sơ cấp đặt 220 V. Tính điện áp thứ cấp và cho biết tăng hay hạ áp.',
     N'ESSAY', NULL,
     N'U₂ = U₁.N₂/N₁ = 220.400/200 = 440 V. Tăng áp.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Bếp điện có dòng 2 A qua điện trở 7 Ω trong 1 phút. Tính nhiệt lượng tỏa ra.',
     N'ESSAY', NULL,
     N'Đổi t = 60 s. Q = I².R.t = 4.7.60 = 1680 J = 1 kJ.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Giải thích nguyên tắc hoạt động của máy biến thế và tính U₂ khi U₁ = 220 V, N₁ = 500, N₂ = 250.',
     N'ESSAY', NULL,
     N'Máy biến thế dựa trên cảm ứng điện từ: dòng biến thiên ở sơ cấp tạo từ trường biến thiên, sinh dòng ở thứ cấp. U₂ = 220.250/500 = 110 V (hạ áp).',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Ấm điện 220 V – 1320 W dùng 7 giờ mỗi ngày. Tính điện năng tiêu thụ trong 30 ngày (kWh).',
     N'ESSAY', NULL,
     N'P = 1320 W = 1.3 kW. A/ngày = 1.3.7 = 9.2 kWh. 30 ngày: 277.2 kWh.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Máy biến thế 400/200 vòng, cuộn sơ cấp đặt 220 V. Tính điện áp thứ cấp và cho biết tăng hay hạ áp.',
     N'ESSAY', NULL,
     N'U₂ = U₁.N₂/N₁ = 220.200/400 = 110 V. Hạ áp.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Bếp điện có dòng 2 A qua điện trở 11 Ω trong 2 phút. Tính nhiệt lượng tỏa ra.',
     N'ESSAY', NULL,
     N'Đổi t = 120 s. Q = I².R.t = 4.11.120 = 5280 J = 5 kJ.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Giải thích nguyên tắc hoạt động của máy biến thế và tính U₂ khi U₁ = 220 V, N₁ = 500, N₂ = 250.',
     N'ESSAY', NULL,
     N'Máy biến thế dựa trên cảm ứng điện từ: dòng biến thiên ở sơ cấp tạo từ trường biến thiên, sinh dòng ở thứ cấp. U₂ = 220.250/500 = 110 V (hạ áp).',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Ấm điện 220 V – 1100 W dùng 6 giờ mỗi ngày. Tính điện năng tiêu thụ trong 30 ngày (kWh).',
     N'ESSAY', NULL,
     N'P = 1100 W = 1.1 kW. A/ngày = 1.1.6 = 6.6 kWh. 30 ngày: 198.0 kWh.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Máy biến thế 300/150 vòng, cuộn sơ cấp đặt 220 V. Tính điện áp thứ cấp và cho biết tăng hay hạ áp.',
     N'ESSAY', NULL,
     N'U₂ = U₁.N₂/N₁ = 220.150/300 = 110 V. Hạ áp.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Điện từ'),
     N'Bếp điện có dòng 2 A qua điện trở 5 Ω trong 3 phút. Tính nhiệt lượng tỏa ra.',
     N'ESSAY', NULL,
     N'Đổi t = 180 s. Q = I².R.t = 4.5.180 = 3600 J = 3 kJ.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Năng lượng với cuộc sống' : 20 MCQ
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống') AND QuestionType='MCQ' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, OptionA, OptionB, OptionC, OptionD, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Hộ gia đình dùng thiết bị 1000 W trong 2 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'B',
     N'3.0 kWh',
     N'2 kWh',
     N'1 kWh',
     N'2000 Wh',
     N'A = P.t = 1000.2 = 2000 Wh = 2 kWh.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Hiệu suất của máy cơ luôn:',
     N'MCQ', N'C',
     N'100%',
     N'lớn hơn 100%',
     N'nhỏ hơn 100%',
     N'bằng 0',
     N'Luôn có ma sát nên A_ích < A_toàn phần, H < 100%.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Vệt sáng trên màn hình khi dùng remote hồng ngoại là do:',
     N'MCQ', N'D',
     N'khúc xạ',
     N'tán sắc',
     N'truyền thẳng',
     N'phản xạ',
     N'Tia hồng ngoại phản xạ trên màn hình tạo điểm sáng.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy thực hiện công toàn phần 1000 J với hiệu suất 90%. Công có ích là:',
     N'MCQ', N'A',
     N'900 J',
     N'1000 J',
     N'100 J',
     N'1000 J',
     N'A_ích = H.A_tp = 90%.1000 = 900 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy thực hiện công toàn phần 2000 J với hiệu suất 80%. Công có ích là:',
     N'MCQ', N'B',
     N'2000 J',
     N'1600 J',
     N'400 J',
     N'1700 J',
     N'A_ích = H.A_tp = 80%.2000 = 1600 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Hộ gia đình dùng thiết bị 1000 W trong 3 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'C',
     N'4.0 kWh',
     N'2 kWh',
     N'3 kWh',
     N'3000 Wh',
     N'A = P.t = 1000.3 = 3000 Wh = 3 kWh.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Hiệu suất của máy cơ luôn:',
     N'MCQ', N'D',
     N'100%',
     N'lớn hơn 100%',
     N'bằng 0',
     N'nhỏ hơn 100%',
     N'Luôn có ma sát nên A_ích < A_toàn phần, H < 100%.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Vệt sáng trên màn hình khi dùng remote hồng ngoại là do:',
     N'MCQ', N'A',
     N'phản xạ',
     N'khúc xạ',
     N'tán sắc',
     N'truyền thẳng',
     N'Tia hồng ngoại phản xạ trên màn hình tạo điểm sáng.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy thực hiện công toàn phần 3000 J với hiệu suất 80%. Công có ích là:',
     N'MCQ', N'B',
     N'3000 J',
     N'2400 J',
     N'600 J',
     N'2500 J',
     N'A_ích = H.A_tp = 80%.3000 = 2400 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy thực hiện công toàn phần 1000 J với hiệu suất 75%. Công có ích là:',
     N'MCQ', N'C',
     N'1000 J',
     N'250 J',
     N'750 J',
     N'850 J',
     N'A_ích = H.A_tp = 75%.1000 = 750 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Hộ gia đình dùng thiết bị 1000 W trong 4 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'D',
     N'5.0 kWh',
     N'3 kWh',
     N'4000 Wh',
     N'4 kWh',
     N'A = P.t = 1000.4 = 4000 Wh = 4 kWh.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Hiệu suất của máy cơ luôn:',
     N'MCQ', N'A',
     N'nhỏ hơn 100%',
     N'100%',
     N'lớn hơn 100%',
     N'bằng 0',
     N'Luôn có ma sát nên A_ích < A_toàn phần, H < 100%.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Vệt sáng trên màn hình khi dùng remote hồng ngoại là do:',
     N'MCQ', N'B',
     N'khúc xạ',
     N'phản xạ',
     N'tán sắc',
     N'truyền thẳng',
     N'Tia hồng ngoại phản xạ trên màn hình tạo điểm sáng.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy thực hiện công toàn phần 2000 J với hiệu suất 75%. Công có ích là:',
     N'MCQ', N'C',
     N'2000 J',
     N'500 J',
     N'1500 J',
     N'1600 J',
     N'A_ích = H.A_tp = 75%.2000 = 1500 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy thực hiện công toàn phần 3000 J với hiệu suất 85%. Công có ích là:',
     N'MCQ', N'D',
     N'3000 J',
     N'450 J',
     N'2650 J',
     N'2550 J',
     N'A_ích = H.A_tp = 85%.3000 = 2550 J.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Hộ gia đình dùng thiết bị 1000 W trong 5 giờ. Điện năng tiêu thụ là:',
     N'MCQ', N'A',
     N'5 kWh',
     N'6.0 kWh',
     N'4 kWh',
     N'5000 Wh',
     N'A = P.t = 1000.5 = 5000 Wh = 5 kWh.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Hiệu suất của máy cơ luôn:',
     N'MCQ', N'B',
     N'100%',
     N'nhỏ hơn 100%',
     N'lớn hơn 100%',
     N'bằng 0',
     N'Luôn có ma sát nên A_ích < A_toàn phần, H < 100%.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Vệt sáng trên màn hình khi dùng remote hồng ngoại là do:',
     N'MCQ', N'C',
     N'khúc xạ',
     N'tán sắc',
     N'phản xạ',
     N'truyền thẳng',
     N'Tia hồng ngoại phản xạ trên màn hình tạo điểm sáng.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy thực hiện công toàn phần 1000 J với hiệu suất 85%. Công có ích là:',
     N'MCQ', N'D',
     N'1000 J',
     N'150 J',
     N'950 J',
     N'850 J',
     N'A_ích = H.A_tp = 85%.1000 = 850 J.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy thực hiện công toàn phần 2000 J với hiệu suất 90%. Công có ích là:',
     N'MCQ', N'A',
     N'1800 J',
     N'2000 J',
     N'200 J',
     N'1900 J',
     N'A_ích = H.A_tp = 90%.2000 = 1800 J.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

-- N'Năng lượng với cuộc sống' : 20 ESSAY
IF NOT EXISTS (SELECT 1 FROM dbo.Questions WHERE TopicID = (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống') AND QuestionType='ESSAY' AND Source='SEED40')
BEGIN
    INSERT INTO dbo.Questions (SubjectID, TopicID, Content, QuestionType, CorrectAnswer, Explanation, Difficulty, CreatedBy, Source)
    VALUES
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy nâng thực hiện công toàn phần 2000 J với hiệu suất 80%. Tính công có ích và phân tích năng lượng hao phí.',
     N'ESSAY', NULL,
     N'A_ích = 80%.2000 = 1600 J. Phần hao phí 400 J do ma sát, tiếng ồn, tỏa nhiệt.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Tính tiền điện tháng cho thiết bị 2000 W dùng 4 giờ/ngày, giá 2000 đồng/kWh (30 ngày).',
     N'ESSAY', NULL,
     N'A/ngày = 2000.4 = 8000 Wh = 8.0 kWh. 30 ngày = 240.0 kWh ⇒ 480000 đồng.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'So sánh năng lượng hóa thạch và năng lượng tái tạo (ví dụ, ưu/nhược điểm).',
     N'ESSAY', NULL,
     N'Hóa thạch (than, dầu, khí): mật độ năng lượng cao nhưng gây ô nhiễm, cạn kiệt. Tái tạo (mặt trời, gió, nước): sạch, vô tận nhưng phụ thuộc thời tiết, vốn đầu tư cao.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Giải thích tại sao tia laze được dùng trong đầu đọc mã vạch và phẫu thuật mắt.',
     N'ESSAY', NULL,
     N'Laze đơn sắc, song song, định hướng cao, năng lượng tập trung nên đọc mã chính xác và cắt mổ siêu nhỏ, ít tổn thương mô xung quanh.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy nâng thực hiện công toàn phần 2000 J với hiệu suất 80%. Tính công có ích và phân tích năng lượng hao phí.',
     N'ESSAY', NULL,
     N'A_ích = 80%.2000 = 1600 J. Phần hao phí 400 J do ma sát, tiếng ồn, tỏa nhiệt.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Tính tiền điện tháng cho thiết bị 2000 W dùng 2 giờ/ngày, giá 2000 đồng/kWh (30 ngày).',
     N'ESSAY', NULL,
     N'A/ngày = 2000.2 = 4000 Wh = 4.0 kWh. 30 ngày = 120.0 kWh ⇒ 240000 đồng.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'So sánh năng lượng hóa thạch và năng lượng tái tạo (ví dụ, ưu/nhược điểm).',
     N'ESSAY', NULL,
     N'Hóa thạch (than, dầu, khí): mật độ năng lượng cao nhưng gây ô nhiễm, cạn kiệt. Tái tạo (mặt trời, gió, nước): sạch, vô tận nhưng phụ thuộc thời tiết, vốn đầu tư cao.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Giải thích tại sao tia laze được dùng trong đầu đọc mã vạch và phẫu thuật mắt.',
     N'ESSAY', NULL,
     N'Laze đơn sắc, song song, định hướng cao, năng lượng tập trung nên đọc mã chính xác và cắt mổ siêu nhỏ, ít tổn thương mô xung quanh.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy nâng thực hiện công toàn phần 2000 J với hiệu suất 80%. Tính công có ích và phân tích năng lượng hao phí.',
     N'ESSAY', NULL,
     N'A_ích = 80%.2000 = 1600 J. Phần hao phí 400 J do ma sát, tiếng ồn, tỏa nhiệt.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Tính tiền điện tháng cho thiết bị 2000 W dùng 3 giờ/ngày, giá 2000 đồng/kWh (30 ngày).',
     N'ESSAY', NULL,
     N'A/ngày = 2000.3 = 6000 Wh = 6.0 kWh. 30 ngày = 180.0 kWh ⇒ 360000 đồng.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'So sánh năng lượng hóa thạch và năng lượng tái tạo (ví dụ, ưu/nhược điểm).',
     N'ESSAY', NULL,
     N'Hóa thạch (than, dầu, khí): mật độ năng lượng cao nhưng gây ô nhiễm, cạn kiệt. Tái tạo (mặt trời, gió, nước): sạch, vô tận nhưng phụ thuộc thời tiết, vốn đầu tư cao.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Giải thích tại sao tia laze được dùng trong đầu đọc mã vạch và phẫu thuật mắt.',
     N'ESSAY', NULL,
     N'Laze đơn sắc, song song, định hướng cao, năng lượng tập trung nên đọc mã chính xác và cắt mổ siêu nhỏ, ít tổn thương mô xung quanh.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy nâng thực hiện công toàn phần 2000 J với hiệu suất 80%. Tính công có ích và phân tích năng lượng hao phí.',
     N'ESSAY', NULL,
     N'A_ích = 80%.2000 = 1600 J. Phần hao phí 400 J do ma sát, tiếng ồn, tỏa nhiệt.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Tính tiền điện tháng cho thiết bị 2000 W dùng 4 giờ/ngày, giá 2000 đồng/kWh (30 ngày).',
     N'ESSAY', NULL,
     N'A/ngày = 2000.4 = 8000 Wh = 8.0 kWh. 30 ngày = 240.0 kWh ⇒ 480000 đồng.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'So sánh năng lượng hóa thạch và năng lượng tái tạo (ví dụ, ưu/nhược điểm).',
     N'ESSAY', NULL,
     N'Hóa thạch (than, dầu, khí): mật độ năng lượng cao nhưng gây ô nhiễm, cạn kiệt. Tái tạo (mặt trời, gió, nước): sạch, vô tận nhưng phụ thuộc thời tiết, vốn đầu tư cao.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Giải thích tại sao tia laze được dùng trong đầu đọc mã vạch và phẫu thuật mắt.',
     N'ESSAY', NULL,
     N'Laze đơn sắc, song song, định hướng cao, năng lượng tập trung nên đọc mã chính xác và cắt mổ siêu nhỏ, ít tổn thương mô xung quanh.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Máy nâng thực hiện công toàn phần 2000 J với hiệu suất 80%. Tính công có ích và phân tích năng lượng hao phí.',
     N'ESSAY', NULL,
     N'A_ích = 80%.2000 = 1600 J. Phần hao phí 400 J do ma sát, tiếng ồn, tỏa nhiệt.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Tính tiền điện tháng cho thiết bị 2000 W dùng 2 giờ/ngày, giá 2000 đồng/kWh (30 ngày).',
     N'ESSAY', NULL,
     N'A/ngày = 2000.2 = 4000 Wh = 4.0 kWh. 30 ngày = 120.0 kWh ⇒ 240000 đồng.',
     N'EASY', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'So sánh năng lượng hóa thạch và năng lượng tái tạo (ví dụ, ưu/nhược điểm).',
     N'ESSAY', NULL,
     N'Hóa thạch (than, dầu, khí): mật độ năng lượng cao nhưng gây ô nhiễm, cạn kiệt. Tái tạo (mặt trời, gió, nước): sạch, vô tận nhưng phụ thuộc thời tiết, vốn đầu tư cao.',
     N'MEDIUM', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40'),
    ((SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9'), (SELECT TopicID FROM dbo.Topics WHERE Name = N'Năng lượng với cuộc sống'),
     N'Giải thích tại sao tia laze được dùng trong đầu đọc mã vạch và phẫu thuật mắt.',
     N'ESSAY', NULL,
     N'Laze đơn sắc, song song, định hướng cao, năng lượng tập trung nên đọc mã chính xác và cắt mổ siêu nhỏ, ít tổn thương mô xung quanh.',
     N'HARD', (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien'), N'SEED40');
END
GO

PRINT N'DA NAP 20 MCQ + 20 ESSAY CO DAU MOI CHU DE';
GO


-- =============================================================================
--  PHẦN 3: BÀI GIẢNG (text + video YouTube) Lý 9
--  (nguồn: 03_seed_lessons_ly9.sql)
-- =============================================================================
-- ============================================================
--  GIA SƯ LÝ - Bổ sung bài giảng Vật Lý 9 (theo GDPT 2018)
--  Môn Khoa học tự nhiên 9 - phần Vật lí:
--    Chủ đề 1. Năng lượng cơ học
--    Chủ đề 2. Ánh sáng
--    Chủ đề 3. Điện
--    Chủ đề 4. Điện từ
--    Chủ đề 5. Năng lượng với cuộc sống
--  Mỗi bài gồm: 1 bài đọc TEXT (nội dung đầy đủ) + link video
--  Chạy SAU 01_schema.sql và 02_seed_data.sql
--  Chạy lại nhiều lần vẫn an toàn (kiểm tra trùng theo Title)
-- ============================================================
USE GiaSuLy9;
GO

DECLARE @ly9 INT = (SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9');
DECLARE @gv  INT = (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien');

-- ============================================================
--  1. BỔ SUNG CHỦ ĐỀ THEO CHƯƠNG TRÌNH MỚI (nếu chưa có)
-- ============================================================
IF @ly9 IS NOT NULL
BEGIN
    IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Năng lượng cơ học')
        INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex)
        VALUES (@ly9, N'Năng lượng cơ học',
                N'Cơ năng, động năng, thế năng; công và công suất. (KHTN 9 - Chủ đề 1)', 6);

    IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Ánh sáng')
        INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex)
        VALUES (@ly9, N'Ánh sáng',
                N'Khúc xạ, tán sắc, phản xạ toàn phần, thấu kính và kính lúp. (KHTN 9 - Chủ đề 2)', 7);

    IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Điện')
        INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex)
        VALUES (@ly9, N'Điện',
                N'Điện trở, định luật Ohm, đoạn mạch nối tiếp - song song, năng lượng và công suất điện. (KHTN 9 - Chủ đề 3)', 8);

    IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Điện từ')
        INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex)
        VALUES (@ly9, N'Điện từ',
                N'Cảm ứng điện từ, dòng điện xoay chiều, máy phát điện và máy biến thế. (KHTN 9 - Chủ đề 4)', 9);

    IF NOT EXISTS (SELECT 1 FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Năng lượng với cuộc sống')
        INSERT INTO dbo.Topics (SubjectID, Name, Description, OrderIndex)
        VALUES (@ly9, N'Năng lượng với cuộc sống',
                N'Năng lượng Trái Đất, năng lượng hóa thạch và năng lượng tái tạo. (KHTN 9 - Chủ đề 5)', 10);
END
GO

DECLARE @ly9  INT = (SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9');
DECLARE @gv   INT = (SELECT UserID FROM dbo.Users WHERE Username = N'giaovien');
DECLARE @cohoc INT = (SELECT TopicID FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Năng lượng cơ học');
DECLARE @as    INT = (SELECT TopicID FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Ánh sáng');
DECLARE @dien  INT = (SELECT TopicID FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Điện');
DECLARE @dt    INT = (SELECT TopicID FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Điện từ');
DECLARE @nlcs  INT = (SELECT TopicID FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Năng lượng với cuộc sống');

-- ============================================================
--  2. CHỦ ĐỀ 1: NĂNG LƯỢNG CƠ HỌC
-- ============================================================

-- Bài 2: Cơ năng (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 2: Cơ năng')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @cohoc, N'Bài 2: Cơ năng',
        N'Động năng, thế năng và sự bảo toàn cơ năng.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. ĐỘNG NĂNG
- Mọi vật chuyển động đều có động năng. Động năng phụ thuộc vào khối lượng và tốc độ của vật: vật càng nặng, chạy càng nhanh thì động năng càng lớn.
- Ví dụ: ô tô đang chạy, quả bóng đang lăn, dòng nước chảy đều có động năng.

2. THẾ NĂNG
- Thế năng trọng trường: vật ở càng cao so với mặt đất thì thế năng càng lớn. Ví dụ: quả bóng đặt trên kệ cao, nước trên đập thủy điện.
- Thế năng đàn hồi: lò xo bị nén hoặc kéo dãn có khả năng sinh công. Ví dụ: dây cung đã giương, lò xo đồ chơi bị nén.

3. CƠ NĂNG
- Cơ năng = động năng + thế năng. Đơn vị là jun (J).
- Khi vật rơi tự do: thế năng giảm dần, động năng tăng dần, tổng cơ năng không đổi (nếu bỏ qua ma sát với không khí).

4. ĐỊNH LUẬT BẢO TOÀN CƠ NĂNG
- Trong quá trình chuyển động, nếu không có ma sát thì cơ năng được bảo toàn: động năng và thế năng chuyển hóa lẫn nhau nhưng tổng của chúng không đổi.
- Ví dụ: con lắc đồng hồ đung đưa - ở vị trí cao nhất thế năng lớn nhất, ở vị trí thấp nhất động năng lớn nhất.

5. VÍ DỤ TÍNH TOÁN
Một vật nặng 2 kg rơi từ độ cao 5 m. Lấy g = 10 m/s2.
- Thế năng ban đầu: Wt = m.g.h = 2.10.5 = 100 J. Đây cũng là cơ năng của vật.
- Ngay trước khi chạm đất, toàn bộ thế năng đã thành động năng: Wd = 100 J.
- Tốc độ khi chạm đất: Wd = m.v2/2 nên v = can(2.100/2) = 10 m/s.

GHI NHỚ: phân biệt rõ khi nào dùng động năng, khi nào dùng thế năng, và luôn kiểm tra điều kiện ''không ma sát'' trước khi áp dụng bảo toàn cơ năng.',
        40, @gv);

-- Bài 3: Công và công suất (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 3: Công và công suất')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @cohoc, N'Bài 3: Công và công suất',
        N'Công thức tính công A = F.s và công suất P = A/t.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. CÔNG CƠ HỌC
- Khi lực tác dụng làm vật chuyển dời theo phương của lực, ta nói lực đã sinh công.
- Công thức: A = F.s, trong đó F là lực tác dụng (N), s là quãng đường vật đi được theo phương của lực (m).
- Đơn vị công là jun (J): 1 J = 1 N.1 m.
- Ví dụ: kéo bao xi măng 500 N lên cao 1,5 m thì công thực hiện là A = 500.1,5 = 750 J.

2. CÔNG SUẤT
- Công suất cho biết ai làm việc khỏe hơn trong cùng một thời gian: P = A/t.
- Đơn vị là oát (W): 1 W = 1 J/1 s. Các bội số: 1 kW = 1000 W, 1 MW = 1 000 000 W, 1 mã lực (HP) ~ 736 W.
- Ví dụ: máy nâng 1200 N lên cao 2 m trong 10 s thì A = 2400 J, P = 240 W. Người kéo tay cùng khối lượng đó mất 60 s thì P = 40 W - máy khỏe gấp 6 lần.

3. MỞ RỘNG
- Công của trọng lực khi vật đi lên: A = -P.h (âm vì trọng lực ngược chiều chuyển động).
- Hiệu suất: H = A_co_ich / A_toan_phan.100%. Không máy cơ nào đạt 100% vì luôn có ma sát.
- Liên hệ với giao thông: xe tải nặng cần động cơ công suất lớn để leo dốc nhanh.

4. BÀI TẬP VẬN DỤNG
Một người dùng ròng rọc kéo vật 120 N lên cao 1,2 m trong 12 s. Tính công và công suất.
- A = F.s = 120.1,2 = 144 J.
- P = A/t = 144/12 = 12 W.

GHI NHỚ: đổi đúng đơn vị trước khi thay số (km/h sang m/s chia 3,6; phút sang giây nhân 60).',
        45, @gv);

-- Video Chủ đề 1 (WEBSITE)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Chủ đề 1: Năng lượng cơ học')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @cohoc, N'[Video] Chủ đề 1: Năng lượng cơ học',
        N'Tổng hợp video bài giảng cơ năng, công và công suất trên YouTube.',
        N'WEBSITE',
        N'https://www.youtube.com/results?search_query=khtn+9+c%C6%A1+n%C4%83ng+c%C3%B4ng+c%C3%B4ng+su%E1%BA%A5t+b%C3%A0i+gi%E1%BA%A3ng',
        NULL,
        N'Nhấn ''Mở nguồn'' để xem danh sách video bài giảng Chủ đề 1 trên YouTube (cơ năng, công và công suất, bài tập vận dụng). Nên xem theo thứ tự: lý thuyết trước, bài tập mẫu sau, rồi tự làm lại không nhìn đáp án.',
        30, @gv);

-- ============================================================
--  3. CHỦ ĐỀ 2: ÁNH SÁNG
-- ============================================================

-- Bài 4: Khúc xạ ánh sáng (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 4: Khúc xạ ánh sáng')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @as, N'Bài 4: Khúc xạ ánh sáng',
        N'Hiện tượng khúc xạ và định luật khúc xạ ánh sáng.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. HIỆN TƯỢNG KHÚC XẠ
- Khúc xạ là hiện tượng tia sáng bị đổi phương đột ngột khi đi qua mặt phân cách giữa hai môi trường trong suốt khác nhau.
- Ví dụ: chiếc thìa trong cốc nước nhìn như bị gãy; đáy bể bơi nhìn nông hơn thực tế; bầu trời sao nhấp nháy.

2. CÁC KHÁI NIỆM
- Tia tới, tia khúc xạ, pháp tuyến tại điểm tới, góc tới (i) và góc khúc xạ (r).
- Khi ánh sáng truyền từ không khí vào nước: tia khúc xạ bị lệch về gần pháp tuyến hơn (r < i).
- Khi truyền ngược lại từ nước ra không khí: tia khúc xạ lệch ra xa pháp tuyến (r > i).

3. ĐỊNH LUẬT KHÚC XẠ
- Tia khúc xạ nằm trong mặt phẳng tới, ở bên kia pháp tuyến so với tia tới.
- Tỉ số sin i / sin r = hằng số, phụ thuộc vào cặp môi trường (chiết suất). Ký hiệu chiết suất là n.

4. VÍ DỤ
- Chiếu tia sáng từ không khí vào tấm thủy tinh với góc tới 60 độ, tia khúc xạ hợp với pháp tuyến khoảng 35 độ - tia sáng bị bẻ gãy về phía pháp tuyến.
- Ứng dụng: thấu kính, lăng kính, sợi quang, bể cá cảnh.

5. PHÂN BIỆT
- Phản xạ: tia sáng bật ngược lại môi trường cũ (gương).
- Khúc xạ: tia sáng đi tiếp sang môi trường mới nhưng đổi hướng.
- Tán sắc: chùm sáng trắng tách thành nhiều màu (cầu vồng).

GHI NHỚ: vẽ hình luôn dựng pháp tuyến trước, rồi mới xác định tia khúc xạ lệch về phía nào.',
        45, @gv);

-- Bài 5: Tán sắc ánh sáng - Màu sắc của vật (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 5: Tán sắc ánh sáng - Màu sắc của vật')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @as, N'Bài 5: Tán sắc ánh sáng - Màu sắc của vật',
        N'Lăng kính tách ánh sáng trắng và cách vật có màu sắc.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. TÁN SẮC ÁNH SÁNG
- Chiếu chùm sáng trắng qua lăng kính, phía sau lăng kính thu được dải màu như cầu vồng: đỏ, cam, vàng, lục, lam, chàm, tím. Đó là hiện tượng tán sắc.
- Ánh sáng trắng là hỗn hợp của nhiều ánh sáng màu. Lăng kính làm các tia màu lệch khác nhau nên chúng tách ra.
- Ví dụ tự nhiên: cầu vồng sau mưa (các giọt nước đóng vai trò lăng kính tí hon).

2. ÁNH SÁNG MÀU
- Có thể tạo ánh sáng màu bằng tấm lọc màu: tấm lọc đỏ chỉ cho ánh sáng đỏ đi qua, chặn các màu khác.
- Trộn hai ánh sáng màu với nhau được màu mới; trộn đủ ba màu cơ bản (đỏ, lục, lam) với tỉ lệ thích hợp được ánh sáng trắng.

3. MÀU SẮC CỦA VẬT
- Ta thấy vật màu đỏ vì nó phản xạ (tán xạ) ánh sáng đỏ và hấp thụ các màu còn lại.
- Vật màu trắng tán xạ mọi màu; vật màu đen hấp thụ gần như mọi màu nên ta thấy tối.
- Cùng một chiếc áo, dưới ánh sáng ban ngày và dưới đèn sân khấu có thể thấy màu khác nhau vì ánh sáng chiếu tới khác nhau.

4. ỨNG DỤNG
- Đèn LED đổi màu, màn hình tivi - điện thoại (điểm ảnh RGB), in ấn (mực CMYK), tín hiệu giao thông.

GHI NHỚ: màu ta nhìn thấy phụ thuộc cả vào vật VÀ ánh sáng chiếu tới nó.',
        40, @gv);

-- Bài 6: Phản xạ toàn phần (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 6: Phản xạ toàn phần')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @as, N'Bài 6: Phản xạ toàn phần',
        N'Điều kiện xảy ra phản xạ toàn phần và ứng dụng sợi quang.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. HIỆN TƯỢNG
- Khi ánh sáng truyền từ môi trường chiết suất lớn sang môi trường chiết suất nhỏ (ví dụ từ nước ra không khí), góc khúc xạ lớn hơn góc tới.
- Tăng dần góc tới, đến một giá trị gọi là góc giới hạn thì tia khúc xạ đi là là mặt phân cách. Tăng tiếp, không còn tia khúc xạ - toàn bộ ánh sáng bị phản xạ ngược lại. Đó là phản xạ toàn phần.

2. ĐIỀU KIỆN (cả hai phải đồng thời đúng)
- Ánh sáng truyền từ môi trường chiết quang hơn sang môi trường chiết quang kém (n1 > n2).
- Góc tới lớn hơn hoặc bằng góc giới hạn.

3. ỨNG DỤNG
- Sợi quang: ánh sáng truyền trong lõi sợi bị phản xạ toàn phần liên tục nên đi xa hàng chục km mà hao hụt rất ít. Dùng trong cáp internet, nội soi y tế, đèn trang trí.
- Lăng kính phản xạ toàn phần trong ống nhòm, máy ảnh thay cho gương (gọn và sáng hơn).
- Kim cương lấp lánh vì ánh sáng bị phản xạ toàn phần nhiều lần bên trong trước khi thoát ra.

4. PHÂN BIỆT VỚI PHẢN XẠ THÔNG THƯỜNG
- Phản xạ thường (gương): luôn xảy ra một phần, kèm theo khúc xạ.
- Phản xạ toàn phần: 100% ánh sáng bị bật ngược lại, không có tia khúc xạ.

GHI NHỚ: phản xạ toàn phần chỉ xảy ra khi đi từ ''đặc'' sang ''loãng'' về mặt quang học.',
        40, @gv);

-- Bài 7: Thấu kính - Kính lúp (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 7: Thấu kính - Kính lúp')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @as, N'Bài 7: Thấu kính - Kính lúp',
        N'Thấu kính hội tụ, phân kì, công thức thấu kính và kính lúp.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. THẤU KÍNH HỘI TỤ
- Phần rìa mỏng hơn phần giữa. Ký hiệu có mũi tên hướng ra ngoài.
- Chùm tia tới song song cho chùm tia ló hội tụ tại tiêu điểm F. Tiêu cự f > 0.
- Ảnh của vật thật: vật ngoài tiêu cự cho ảnh thật ngược chiều (máy ảnh, máy chiếu); vật trong tiêu cự cho ảnh ảo cùng chiều lớn hơn vật (kính lúp).

2. THẤU KÍNH PHÂN KÌ
- Phần rìa dày hơn phần giữa. Chùm tia tới song song cho chùm tia ló phân kì (kéo dài gặp nhau tại tiêu điểm ảo). Tiêu cự f < 0.
- Vật thật luôn cho ảnh ảo cùng chiều nhỏ hơn vật. Ứng dụng: kính cận, ống nhòm (thị kính).

3. CÔNG THỨC THẤU KÍNH
- 1/f = 1/d + 1/d'', trong đó d là khoảng cách vật - thấu kính, d'' là khoảng cách ảnh - thấu kính.
- Quy ước dấu: f > 0 với hội tụ, f < 0 với phân kì; d'' > 0 là ảnh thật, d'' < 0 là ảnh ảo.
- Ví dụ: thấu kính hội tụ f = 20 cm, vật đặt cách 30 cm. 1/d'' = 1/20 - 1/30 = 1/60 nên d'' = 60 cm: ảnh thật cách thấu kính 60 cm.

4. KÍNH LÚP
- Là thấu kính hội tụ có tiêu cự ngắn (f < 10 cm thường gặp).
- Đặt vật trong tiêu cự để được ảnh ảo lớn hơn vật, mắt đặt sau kính quan sát.
- Số bội giác G = 25/f (f tính bằng cm, 25 cm là khoảng nhìn rõ ngắn nhất). Kính 5x có f = 5 cm.

GHI NHỚ: làm bài tập thấu kính luôn vẽ 2 trong 3 tia đặc biệt (qua quang tâm đi thẳng; song song trục qua tiêu điểm; qua tiêu điểm ra song song trục).',
        50, @gv);

-- Video Chủ đề 2 (WEBSITE)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Chủ đề 2: Ánh sáng')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @as, N'[Video] Chủ đề 2: Ánh sáng',
        N'Video khúc xạ, tán sắc, thấu kính và kính lúp.',
        N'WEBSITE',
        N'https://www.youtube.com/results?search_query=khtn+9+%C3%A1nh+s%C3%A1ng+kh%C3%BAc+x%E1%BA%A1+th%E1%BA%A5u+k%C3%ADnh+b%C3%A0i+gi%E1%BA%A3ng',
        NULL,
        N'Nhấn ''Mở nguồn'' để xem video bài giảng Chủ đề 2. Gợi ý: vừa xem vừa vẽ lại đường truyền tia sáng vào vở, tự dừng video và đoán hướng tia trước khi xem đáp án.',
        30, @gv);

-- ============================================================
--  4. CHỦ ĐỀ 3: ĐIỆN
-- ============================================================

-- Bài 8: Điện trở - Định luật Ohm (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 8: Điện trở - Định luật Ohm')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @dien, N'Bài 8: Điện trở - Định luật Ohm',
        N'Khái niệm điện trở và định luật Ohm I = U/R.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. ĐIỆN TRỞ
- Điện trở cho biết mức độ cản trở dòng điện của dây dẫn. Ký hiệu R, đơn vị ôm (ôm viết tắt là Ω). Các bội số: 1 kΩ = 1000 Ω, 1 MΩ = 1 000 000 Ω.
- Điện trở của dây dẫn tỉ lệ thuận với chiều dài, tỉ lệ nghịch với tiết diện và phụ thuộc vật liệu: R = ro.l/S.
- Ý nghĩa thực tế: dây tóc bóng đèn có điện trở lớn nên nóng sáng; dây tải điện dùng đồng/nhôm để điện trở nhỏ, đỡ hao phí.

2. ĐỊNH LUẬT OHM
- Cường độ dòng điện qua dây dẫn tỉ lệ thuận với hiệu điện thế đặt vào hai đầu dây và tỉ lệ nghịch với điện trở: I = U/R.
- Từ đó suy ra U = I.R và R = U/I.
- Đồ thị I theo U là đường thẳng qua gốc tọa độ; độ dốc càng lớn thì điện trở càng nhỏ.

3. ĐO ĐẠC
- Đo hiệu điện thế bằng vôn kế mắc SONG SONG với đoạn mạch cần đo.
- Đo cường độ bằng ampe kế mắc NỐI TIẾP trong mạch.
- Đo trực tiếp R bằng ôm kế (đồng hồ vạn năng ở thang đo Ω).

4. VÍ DỤ
- Bóng đèn 220 V - 100 W sáng bình thường: R = U2/P = 2202/100 = 484 Ω; I = P/U = 100/220 ≈ 0,45 A.
- Đặt U = 12 V vào điện trở 4 Ω thì I = 12/4 = 3 A.

GHI NHỚ: R của vật dẫn không đổi khi U, I thay đổi (bỏ qua ảnh hưởng nhiệt độ) - đừng nhầm R tỉ lệ thuận với U.',
        45, @gv);

-- Bài 9: Đoạn mạch nối tiếp (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 9: Đoạn mạch nối tiếp')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @dien, N'Bài 9: Đoạn mạch nối tiếp',
        N'Đặc điểm dòng điện, hiệu điện thế và điện trở tương đương mạch nối tiếp.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. CÁCH NHẬN BIẾT
- Các thiết bị xếp thành một hàng duy nhất, dòng điện chỉ có một đường đi. Tắt một đèn thì cả mạch tắt (đèn trang trí cũ, công tắc và bóng đèn trong nhà).

2. ĐẶC ĐIỂM (ghi nhớ 3 dòng)
- Dòng điện như nhau tại mọi điểm: I = I1 = I2 = ... = In.
- Hiệu điện thế toàn mạch bằng tổng các hiệu điện thế thành phần: U = U1 + U2 + ... + Un.
- Điện trở tương đương bằng tổng các điện trở: Rtđ = R1 + R2 + ... + Rn.

3. VÍ DỤ
- R1 = 2 Ω, R2 = 4 Ω, R3 = 6 Ω nối tiếp vào nguồn 12 V.
- Rtđ = 2 + 4 + 6 = 12 Ω; I = 12/12 = 1 A qua mọi điện trở.
- U1 = 2 V, U2 = 4 V, U3 = 6 V. Kiểm tra: 2 + 4 + 6 = 12 V đúng bằng nguồn.

4. ỨNG DỤNG VÀ LƯU Ý
- Cầu chì, công tắc, aptomat mắc nối tiếp để bảo vệ và điều khiển toàn mạch.
- Nhược điểm: một chỗ hỏng là cả mạch mất điện; hiệu điện thế chia nhỏ nên các đèn sáng yếu hơn khi mắc nhiều đèn nối tiếp.

GHI NHỚ: ''nối tiếp thì I bằng nhau, U cộng lại, R cộng lại''.',
        40, @gv);

-- Bài 10: Đoạn mạch song song (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 10: Đoạn mạch song song')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @dien, N'Bài 10: Đoạn mạch song song',
        N'Đặc điểm dòng điện, hiệu điện thế và điện trở tương đương mạch song song.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. CÁCH NHẬN BIẾT
- Các thiết bị rẽ thành nhiều nhánh giữa cùng hai điểm, dòng điện chia ra nhiều đường. Tắt một đèn các đèn khác vẫn sáng (hệ thống điện trong nhà, đèn xe).

2. ĐẶC ĐIỂM (ghi nhớ 3 dòng)
- Hiệu điện thế như nhau trên mọi nhánh: U = U1 = U2 = ... = Un.
- Dòng điện mạch chính bằng tổng dòng các nhánh: I = I1 + I2 + ... + In.
- Nghịch đảo điện trở tương đương bằng tổng nghịch đảo: 1/Rtđ = 1/R1 + 1/R2 + ... + 1/Rn. Với 2 điện trở: Rtđ = R1.R2/(R1+R2).

3. VÍ DỤ
- R1 = 2 Ω, R2 = 4 Ω, R3 = 6 Ω song song vào nguồn 12 V.
- 1/Rtđ = 1/2 + 1/4 + 1/6 = 11/12 nên Rtđ ≈ 1,09 Ω (NHỎ HƠN mọi điện trở thành phần).
- I1 = 6 A, I2 = 3 A, I3 = 2 A; I mạch chính = 11 A.

4. ỨNG DỤNG VÀ LƯU Ý
- Mạng điện gia đình mắc song song để mỗi thiết bị đều được 220 V và hoạt động độc lập.
- Càng mắc thêm nhánh song song, Rtđ càng giảm, dòng mạch chính càng tăng - đó là lý do cắm quá nhiều thiết bị dễ quá tải, chập cháy.

GHI NHỚ: ''song song thì U bằng nhau, I cộng lại, nghịch đảo R cộng lại'' - ngược hoàn toàn với nối tiếp.',
        40, @gv);

-- Bài 11: Năng lượng điện - Công suất điện (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 11: Năng lượng điện - Công suất điện')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @dien, N'Bài 11: Năng lượng điện - Công suất điện',
        N'Điện năng tiêu thụ A = P.t và công suất P = U.I.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. NĂNG LƯỢNG ĐIỆN
- Dòng điện mang năng lượng vì nó có thể sinh công và tỏa nhiệt: đèn sáng, quạt quay, bếp nóng.
- Điện năng tiêu thụ: A = P.t. Đơn vị jun (J); trong đời sống dùng kilôoat giờ (kWh, ''số điện''): 1 kWh = 3 600 000 J.
- Tiền điện = số kWh × đơn giá. Ví dụ: dùng 100 kWh với giá 2000 đ/kWh thì trả 200 000 đ.

2. CÔNG SUẤT ĐIỆN
- P = U.I = I2.R = U2/R. Đơn vị oát (W).
- Số oát ghi trên thiết bị là công suất định mức khi dùng đúng hiệu điện thế định mức. Dùng sai hiệu điện thế: thấp hơn thì yếu, cao hơn thì cháy.
- Ví dụ: ấm 220 V - 1000 W dùng ở 220 V thì I = 1000/220 ≈ 4,55 A; đun 10 phút tốn A = 1 kW × (1/6) h ≈ 0,167 kWh.

3. ĐỊNH LUẬT JOULE - LENZ (nhiệt lượng tỏa ra)
- Q = I2.R.t. Đây là cơ sở của bếp điện, bàn là, cầu chì; nhưng cũng là hao phí trên đường dây tải điện.
- Để giảm hao phí tỏa nhiệt khi tải điện đi xa, người ta tăng hiệu điện thế (dùng máy biến thế) vì hao phí tỉ lệ nghịch với bình phương hiệu điện thế.

4. TIẾT KIỆM ĐIỆN
- Tắt thiết bị khi không dùng, dùng đèn LED thay sợi đốt, tận dụng ánh sáng tự nhiên, để điều hòa 26-27 độ.

GHI NHỚ: đọc kỹ ''số oát'' trên nhãn để tính đúng dòng điện và chọn dây dẫn, aptomat phù hợp.',
        45, @gv);

-- Video Chủ đề 3 (WEBSITE)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Chủ đề 3: Điện')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @dien, N'[Video] Chủ đề 3: Điện',
        N'Video định luật Ohm, mạch nối tiếp - song song, công suất điện.',
        N'WEBSITE',
        N'https://www.youtube.com/results?search_query=khtn+9+%C4%91%E1%BB%8Bnh+lu%E1%BA%ADt+ohm+m%E1%BA%A1ch+n%E1%BB%91i+ti%E1%BA%BFp+song+song+b%C3%A0i+gi%E1%BA%A3ng',
        NULL,
        N'Nhấn ''Mở nguồn'' để xem video Chủ đề 3. Mẹo học: tự vẽ lại sơ đồ mạch và tính I, U, R từng nhánh trước khi xem lời giải trong video.',
        30, @gv);

-- ============================================================
--  5. CHỦ ĐỀ 4: ĐIỆN TỪ
-- ============================================================

-- Bài 12: Cảm ứng điện từ (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 12: Cảm ứng điện từ')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @dt, N'Bài 12: Cảm ứng điện từ',
        N'Điều kiện xuất hiện dòng điện cảm ứng và ứng dụng.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. HIỆN TƯỢNG CẢM ỨNG ĐIỆN TỪ
- Khi số đường sức từ xuyên qua cuộn dây biến thiên, trong cuộn dây xuất hiện dòng điện - gọi là dòng điện cảm ứng.
- Cách tạo ra: đưa nam châm lại gần / ra xa cuộn dây; đóng - ngắt mạch nam châm điện đặt gần cuộn dây; quay cuộn dây trong từ trường.

2. ĐIỀU KIỆN XUẤT HIỆN DÒNG ĐIỆN CẢM ỨNG
- Phải có sự BIẾN THIÊN (thay đổi) của từ thông, đứng yên thì không có dòng điện.
- Dòng điện cảm ứng đổi chiều khi cực nam châm đổi chiều chuyển động (lại gần đổi thành ra xa hoặc ngược lại).

3. ĐỊNH LUẬT LENZ (xác định chiều)
- Dòng điện cảm ứng có chiều sao cho từ trường do nó sinh ra chống lại nguyên nhân sinh ra nó. Nói đơn giản: nam châm tiến lại thì cuộn dây ''đẩy ra'', nam châm rút ra thì cuộn dây ''níu lại''.

4. ỨNG DỤNG
- Máy phát điện (dynamo xe đạp, nhà máy thủy - nhiệt - điện gió), micro, đàn guitar điện, bếp từ (dòng Foucault làm nóng nồi), sạc không dây, phanh điện từ trên tàu cao tốc.

5. PHÂN BIỆT
- Tác dụng từ của dòng điện (điện sinh ra từ): chuông điện, nam châm điện.
- Cảm ứng điện từ (từ sinh ra điện): máy phát điện. Hai hiện tượng ngược nhau.

GHI NHỚ: từ khóa của cả chủ đề là ''biến thiên'' - không biến thiên thì không có dòng cảm ứng.',
        45, @gv);

-- Bài 13: Dòng điện xoay chiều (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 13: Dòng điện xoay chiều')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @dt, N'Bài 13: Dòng điện xoay chiều',
        N'Máy phát điện xoay chiều, máy biến thế và truyền tải điện.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. DÒNG ĐIỆN XOAY CHIỀU
- Là dòng điện luân phiên đổi chiều liên tục. Mạng điện Việt Nam: hiệu điện thế 220 V, tần số 50 Hz (đổi chiều 100 lần mỗi giây).
- Tạo ra bằng máy phát điện xoay chiều: cuộn dây quay trong từ trường (hoặc nam châm quay quanh cuộn dây) nhờ cảm ứng điện từ.

2. MÁY PHÁT ĐIỆN XOAY CHIỀU
- Bộ phận chính: nam châm + cuộn dây, một trong hai quay được (rôto), phần còn lại đứng yên (stato).
- Làm quay rôto bằng tuabin nước, hơi nước, sức gió... - đó là nguyên lý của mọi nhà máy điện.

3. MÁY BIẾN THẾ
- Gồm hai cuộn dây quấn chung một lõi sắt. Hoạt động nhờ cảm ứng điện từ với dòng xoay chiều.
- Công thức: U1/U2 = n1/n2 (hiệu điện thế tỉ lệ với số vòng dây).
- Muốn tăng thế: cuộn thứ cấp nhiều vòng hơn (dùng khi tải điện đi xa). Muốn hạ thế: cuộn thứ cấp ít vòng hơn (sạc điện thoại, adapter).
- Ví dụ: U1 = 220 V, n1 = 440 vòng, n2 = 22 vòng thì U2 = 220×22/440 = 11 V.
- Lưu ý: máy biến thế KHÔNG dùng được với dòng một chiều (pin, ắc quy) vì từ trường không biến thiên.

4. TRUYỀN TẢI ĐIỆN NĂNG ĐI XA
- Hao phí tỏa nhiệt: Php = R.P2/U2. Muốn giảm hao phí phải TĂNG hiệu điện thế (vì Php tỉ lệ nghịch với U bình phương).
- Thực tế: nhà máy phát ra ~10-25 kV, tăng lên 110-500 kV để tải đi xa, rồi hạ dần xuống 220 V cho gia đình.

GHI NHỚ: máy phát ''tạo ra'' điện xoay chiều, máy biến thế ''đổi mức'' điện áp của nó.',
        50, @gv);

-- Video Chủ đề 4 (WEBSITE)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Chủ đề 4: Điện từ')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @dt, N'[Video] Chủ đề 4: Điện từ',
        N'Video cảm ứng điện từ, dòng xoay chiều và máy biến thế.',
        N'WEBSITE',
        N'https://www.youtube.com/results?search_query=khtn+9+c%E1%BA%A3m+%E1%BB%A9ng+%C4%91i%E1%BB%87n+t%E1%BB%AB+d%C3%B2ng+%C4%91i%E1%BB%87n+xoay+chi%E1%BB%81u+b%C3%A0i+gi%E1%BA%A3ng',
        NULL,
        N'Nhấn ''Mở nguồn'' để xem video Chủ đề 4. Nên xem thí nghiệm nam châm - cuộn dây trước để ''thấy'' dòng cảm ứng, rồi mới học công thức máy biến thế.',
        30, @gv);

-- ============================================================
--  6. CHỦ ĐỀ 5: NĂNG LƯỢNG VỚI CUỘC SỐNG
-- ============================================================

-- Bài 14: Năng lượng Trái Đất - Năng lượng hóa thạch (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 14: Năng lượng Trái Đất - Năng lượng hóa thạch')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @nlcs, N'Bài 14: Năng lượng Trái Đất - Năng lượng hóa thạch',
        N'Các nguồn năng lượng của Trái Đất và năng lượng hóa thạch.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. NGUỒN NĂNG LƯỢNG CỦA TRÁI ĐẤT
- Mặt Trời: nguồn gốc của gần như mọi năng lượng trên Trái Đất (quang năng nuôi cây, nhiệt làm bốc hơi nước tạo mưa, gió...).
- Trái Đất: năng lượng địa nhiệt (mạch magma), năng lượng thủy triều (hấp dẫn Mặt Trăng), năng lượng hạt nhân trong lòng đất.
- Con người: khai thác than, dầu, khí (hóa thạch); gió, mặt trời, nước, địa nhiệt (tái tạo); uranium (hạt nhân).

2. NĂNG LƯỢNG HÓA THẠCH
- Hình thành từ xác sinh vật bị vùi lấp hàng trăm triệu năm: than đá, dầu mỏ, khí thiên nhiên.
- Ưu điểm: trữ lượng tập trung, dễ vận chuyển, công nghệ khai thác - sử dụng đã hoàn thiện, giá thành rẻ.
- Nhược điểm lớn: KHÔNG tái tạo (dùng hết là hết); đốt thải CO2 gây hiệu ứng nhà kính, biến đổi khí hậu; khai thác gây ô nhiễm đất, nước, sự cố tràn dầu.

3. SỬ DỤNG HIỆU QUẢ VÀ TIẾT KIỆM
- Ưu tiên phương tiện công cộng, xe tiết kiệm nhiên liệu; tắt máy khi dừng lâu.
- Cách nhiệt nhà cửa để giảm điều hòa; dùng thiết bị dán nhãn tiết kiệm năng lượng.
- Thu hồi nhiệt thải trong công nghiệp; phân loại rác để tái chế, giảm năng lượng sản xuất mới.

GHI NHỚ: hóa thạch = ''tài khoản tiết kiệm'' của Trái Đất - rút mãi không gửi thì hết, lại còn gây ô nhiễm.',
        40, @gv);

-- Bài 15: Năng lượng tái tạo (TEXT)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 15: Năng lượng tái tạo')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @nlcs, N'Bài 15: Năng lượng tái tạo',
        N'Năng lượng mặt trời, gió, nước, địa nhiệt và sinh khối.',
        N'TEXT', NULL,
        N'https://vietjack.com/khoa-hoc-tu-nhien-9/index.jsp',
        N'1. KHÁI NIỆM
- Năng lượng tái tạo là năng lượng từ các nguồn liên tục được bổ sung trong thời gian ngắn: mặt trời, gió, nước chảy, địa nhiệt, sinh khối.
- Ngược lại: than, dầu, khí là năng lượng KHÔNG tái tạo.

2. TỪNG LOẠI
- Mặt trời: pin quang điện biến quang năng thành điện năng (mái nhà, trang trại điện mặt trời ở Ninh Thuận, Bình Thuận); bình nước nóng năng lượng mặt trời.
- Gió: tuabin gió biến động năng gió thành điện năng (Bạc Liêu, Bình Thuận). Sạch nhưng phụ thuộc gió, tốn diện tích, ồn.
- Nước: thủy điện dùng thế năng nước trên cao (Hòa Bình, Sơn La). Ổn định nhưng ngập rừng, ảnh hưởng dân cư hạ lưu.
- Địa nhiệt: hơi nóng lòng đất chạy tuabin (ít ở Việt Nam, mạnh ở Iceland).
- Sinh khối: đốt rơm rạ, bã mía, biogas từ chăn nuôi để đun nấu, phát điện - vừa có năng lượng vừa xử lý rác thải nông nghiệp.

3. SO SÁNH VỚI HÓA THẠCH
- Tái tạo: không cạn kiệt, ít khí thải, nhưng công suất phụ thuộc thiên nhiên và chi phí đầu tư ban đầu cao.
- Hóa thạch: ổn định, rẻ trước mắt, nhưng cạn dần và gây biến đổi khí hậu.
- Xu hướng: chuyển dịch năng lượng - tăng tỉ trọng tái tạo, dùng tiết kiệm, phát triển lưới điện thông minh và pin lưu trữ.

4. LIÊN HỆ VIỆT NAM
- Tiềm năng mặt trời và gió ven biển rất lớn; chính phủ khuyến khích điện mặt trời mái nhà.
- Mỗi học sinh có thể góp phần: tắt đèn khi ra khỏi phòng, dùng bình nước nóng năng lượng mặt trời, phân loại rác hữu cơ ủ biogas ở nông thôn.

GHI NHỚ: ''tái tạo'' nghĩa là xài hôm nay, ngày mai thiên nhiên lại ''nạp'' đầy.',
        40, @gv);

-- Video Chủ đề 5 (WEBSITE)
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Chủ đề 5: Năng lượng với cuộc sống')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @nlcs, N'[Video] Chủ đề 5: Năng lượng với cuộc sống',
        N'Video năng lượng hóa thạch và năng lượng tái tạo.',
        N'WEBSITE',
        N'https://www.youtube.com/results?search_query=khtn+9+n%C4%83ng+l%C6%B0%E1%BB%A3ng+t%C3%A1i+t%E1%BA%A1o+n%C4%83ng+l%C6%B0%E1%BB%A3ng+h%C3%B3a+th%E1%BA%A1ch+b%C3%A0i+gi%E1%BA%A3ng',
        NULL,
        N'Nhấn ''Mở nguồn'' để xem video Chủ đề 5. Gợi ý thảo luận nhóm: địa phương em phù hợp nhất với loại năng lượng tái tạo nào và vì sao?',
        30, @gv);

PRINT N'=========================================';
PRINT N'  ĐÃ NẠP BÀI GIẢNG VẬT LÝ 9 (GDPT 2018)';
PRINT N'  5 chủ đề - 15 bài đọc TEXT + 5 video';
PRINT N'=========================================';
GO


-- =============================================================================
--  PHẦN 4: GIÁO VIÊN (3 thầy cô kèm video bài giảng)
--  (nguồn: 04_seed_teachers_ly9.sql)
-- =============================================================================
-- ============================================================
--  GIA SƯ LÝ 9 - Tài khoản giáo viên + hồ sơ + bài giảng video
--  Chạy SAU 01_schema.sql, 02_seed_data.sql, 03_seed_lessons_ly9.sql
--  Chạy lại nhiều lần vẫn an toàn (kiểm tra trùng theo Username / Title)
--  Lưu ý: mỗi batch (ngăn bởi GO) tự khai báo biến để chạy được trên
--  sqlcmd, SSMS và helper database\run-sql.ps1.
-- ============================================================
USE GiaSuLy9;
GO

-- ============================================================
--  1. TẠO 3 TÀI KHOẢN GIÁO VIÊN (mật khẩu: giaovien123)
--     Salt cố định + SHA256(salt + password) => đăng nhập được ngay
-- ============================================================
IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE Username = N'phamvantung')
BEGIN
    DECLARE @s1 NVARCHAR(64) = N'GSL9TVTUNG01';
    INSERT INTO dbo.Users (Username, PasswordHash, Salt, FullName, Email, Phone, Role, ClassName, AvatarUrl, IsActive, CreatedAt)
    VALUES (N'phamvantung', N'914bdbb93615b6ea2db4aa737741b1f075bd8567d7a7b70f2940310a7a408c78', @s1,
            N'Thầy Phạm Văn Tùng', N'phamvantung@giasuly9.vn', N'0901001001', N'TEACHER', N'Vật lý 9',
            N'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=300&auto=format&fit=crop', 1, GETDATE());
    PRINT N'Đã tạo GV Phạm Văn Tùng';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE Username = N'nguyenthanhnam')
BEGIN
    DECLARE @s2 NVARCHAR(64) = N'GSL9TVNAM002';
    INSERT INTO dbo.Users (Username, PasswordHash, Salt, FullName, Email, Phone, Role, ClassName, AvatarUrl, IsActive, CreatedAt)
    VALUES (N'nguyenthanhnam', N'3662f67a80899f621a0697bb1ac56ab7572a9180e933929fe9650d651510f29b', @s2,
            N'Thầy Nguyễn Thành Nam', N'nguyenthanhnam@giasuly9.vn', N'0901001002', N'TEACHER', N'Vật lý 9',
            N'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=300&auto=format&fit=crop', 1, GETDATE());
    PRINT N'Đã tạo GV Nguyễn Thành Nam';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Users WHERE Username = N'duongthuha')
BEGIN
    DECLARE @s3 NVARCHAR(64) = N'GSL9TVHA003';
    INSERT INTO dbo.Users (Username, PasswordHash, Salt, FullName, Email, Phone, Role, ClassName, AvatarUrl, IsActive, CreatedAt)
    VALUES (N'duongthuha', N'f7e588639993abc3441b57ff6c132cc74172c226c82d767a647ca37da4040f5f', @s3,
            N'Cô Dương Thu Hà', N'duongthuha@giasuly9.vn', N'0901001003', N'TEACHER', N'Vật lý 9',
            N'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=300&auto=format&fit=crop', 1, GETDATE());
    PRINT N'Đã tạo GV Dương Thu Hà';
END
GO

-- ============================================================
--  2. HỒ SƠ GIÁO VIÊN
-- ============================================================
DECLARE @tung INT = (SELECT UserID FROM dbo.Users WHERE Username = N'phamvantung');

IF @tung IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.TeacherProfiles WHERE UserID = @tung)
BEGIN
    INSERT INTO dbo.TeacherProfiles (UserID, FullName, Degree, Title, School, Specialty, Bio, AvatarUrl, Color, YearsExp, StudentCount, VideoCount, IsActive)
    VALUES (@tung, N'Thầy Phạm Văn Tùng', N'Thạc sĩ Vật lý', N'Giáo viên Vật lý 9 - Chuyên đề cơ năng & năng lượng',
            N'Trường THCS Quang Trung, TP.HCM',
            N'Cơ năng, công và công suất, bảo toàn năng lượng',
            N'Thầy Tùng có 12 năm giảng dạy Vật lý trung học, từng hỗ trợ hơn 2.000 học sinh lớp 9 lấy điểm tốt ở kỳ thi tốt nghiệp. Phương pháp của thầy là "hiểu bản chất trước, ghi nhớ công thức sau", luôn chỉ ra lý do vật lý xảy ra chứ không chỉ đưa công thức.',
            N'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=300&auto=format&fit=crop',
            N'#1d4ed8', 12, 2100, 0, 1);
    PRINT N'Đã tạo hồ sơ GV Phạm Văn Tùng';
END
GO

DECLARE @nam INT = (SELECT UserID FROM dbo.Users WHERE Username = N'nguyenthanhnam');

IF @nam IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.TeacherProfiles WHERE UserID = @nam)
BEGIN
    INSERT INTO dbo.TeacherProfiles (UserID, FullName, Degree, Title, School, Specialty, Bio, AvatarUrl, Color, YearsExp, StudentCount, VideoCount, IsActive)
    VALUES (@nam, N'Thầy Nguyễn Thành Nam', N'Thạc sĩ kỹ thuật',
            N'Giáo viên Vật lý 9 - Chuyên đề điện học & điện từ',
            N'Trường THPT Lê Hồng Phong, TP.HCM',
            N'Điện trở, mạch nối tiếp - song song, cảm ứng điện từ, máy biến thế',
            N'Thầy Nam là giảng viên trẻ nhưng giàu kinh nghiệm thực tế về điện học. Thầy nổi tiếng với các video thí nghiệm tự làm, giúp học sinh thấy rõ dòng điện chạy đi đâu và vì sao. Lớp học của thầy luôn có sơ đồ mạch vẽ tay để học sinh tự dựng lại.',
            N'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=300&auto=format&fit=crop',
            N'#0f766e', 9, 1650, 0, 1);
    PRINT N'Đã tạo hồ sơ GV Nguyễn Thành Nam';
END
GO

DECLARE @ha INT = (SELECT UserID FROM dbo.Users WHERE Username = N'duongthuha');

IF @ha IS NOT NULL AND NOT EXISTS (SELECT 1 FROM dbo.TeacherProfiles WHERE UserID = @ha)
BEGIN
    INSERT INTO dbo.TeacherProfiles (UserID, FullName, Degree, Title, School, Specialty, Bio, AvatarUrl, Color, YearsExp, StudentCount, VideoCount, IsActive)
    VALUES (@ha, N'Cô Dương Thu Hà', N'Cử nhân Vật lý',
            N'Giáo viên Vật lý 9 - Chuyên đề quang học & năng lượng',
            N'Trường THCS Lê Văn Sĩ, TP.HCM',
            N'Khúc xạ, tán sắc, thấu kính, kính lúp, năng lượng tái tạo',
            N'Cô Hà yêu thích cách giải thửa bằng hình vẽ. Mỗi bài của cô đều có phần "tự vẽ lại đường truyền tia sáng" để học sinh không học vẹt. Cô cũng là người soạn bộ bài tập vận dụng theo phân loại độ khó cho học sinh lớp 9.',
            N'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=300&auto=format&fit=crop',
            N'#b45309', 7, 1300, 0, 1);
    PRINT N'Đã tạo hồ sơ GV Dương Thu Hà';
END
GO

-- ============================================================
--  3. BÀI GIẢNG VIDEO GÁN CHO TỪNG GIÁO VIÊN
-- ============================================================
DECLARE @ly9   INT = (SELECT SubjectID FROM dbo.Subjects WHERE Name = N'Vật lý 9');
DECLARE @tung  INT = (SELECT UserID FROM dbo.Users WHERE Username = N'phamvantung');
DECLARE @nam   INT = (SELECT UserID FROM dbo.Users WHERE Username = N'nguyenthanhnam');
DECLARE @ha    INT = (SELECT UserID FROM dbo.Users WHERE Username = N'duongthuha');
DECLARE @cohoc INT = (SELECT TopicID FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Năng lượng cơ học');
DECLARE @as    INT = (SELECT TopicID FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Ánh sáng');
DECLARE @dien  INT = (SELECT TopicID FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Điện');
DECLARE @dt    INT = (SELECT TopicID FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Điện từ');
DECLARE @nlcs  INT = (SELECT TopicID FROM dbo.Topics WHERE SubjectID = @ly9 AND Name = N'Năng lượng với cuộc sống');

-- ============ THẦY PHẠM VĂN TÙNG — Cơ năng, công & công suất ============

IF @tung IS NOT NULL AND @cohoc IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Cơ năng - Động năng và thế năng (Thầy Tùng)')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @cohoc, N'[Video] Cơ năng - Động năng và thế năng (Thầy Tùng)',
        N'Thầy Phạm Văn Tùng giải bài 2: cơ năng, động năng, thế năng theo GDPT 2018.',
        N'VIDEO_YOUTUBE',
        N'https://www.youtube.com/embed/atTVDrEccXM',
        N'https://www.youtube.com/watch?v=atTVDrEccXM',
        N'Video bài giảng chuyên đề Chủ đề 1 (Năng lượng cơ học) - Bài 2 Cơ năng.

NỘI DUNG VIDEO:
1. Mọi vật chuyển động đều có động năng, phụ thuộc vào khối lượng và tốc độ.
2. Thế năng trọng trường và thế năng đàn hồi.
3. Cơ năng = động năng + thế năng, đơn vị jun (J).
4. Định luật bảo toàn cơ năng trong chuyển động vật rơi tự do.
5. Ví dụ tính toán: vật 2 kg rơi từ 5 m, g = 10 m/s2.

MẸO HỌC: Khi xem video, hãy dừng ở mỗi phần và tự tính lại ví dụ trước khi xem đáp án của thầy.',
        37, @tung);

IF @tung IS NOT NULL AND @cohoc IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Công và công suất - A = F.s, P = A/t (Thầy Tùng)')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @cohoc, N'[Video] Công và công suất - A = F.s, P = A/t (Thầy Tùng)',
        N'Bài giảng công cơ học và công suất của thầy Phạm Văn Tùng.',
        N'VIDEO_YOUTUBE',
        N'https://www.youtube.com/embed/GK83XaGbLi0',
        N'https://www.youtube.com/watch?v=GK83XaGbLi0',
        N'Video bài giảng chuyên đề Chủ đề 1 (Năng lượng cơ học) - Bài 3 Công và công suất.

NỘI DUNG VIDEO:
1. Công cơ học: A = F.s, điều kiện để lực sinh công.
2. Đơn vị joule và các bội số (kJ, MJ, kWh).
3. Công suất: P = A/t, đơn vị oát (W), 1 kW = 1000 W, 1 HP ≈ 736 W.
4. So sánh công suất để biết ai làm việc khỏe hơn.
5. Bài tập vận dụng có sẵn trong video.

MẸO HỌC: Vẽ lại sơ đồ lực và quãng đường trước khi thay số, luôn đổi đủ đơn vị SI.',
        30, @tung);

IF @tung IS NOT NULL AND @cohoc IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Bảo toàn cơ năng - Bài tập vận dụng (Thầy Tùng)')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @cohoc, N'[Video] Bảo toàn cơ năng - Bài tập vận dụng (Thầy Tùng)',
        N'Thầy Tùng hướng dẫn giải bài toán bảo toàn cơ năng và cơ năng của vật rơi tự do.',
        N'VIDEO_YOUTUBE',
        N'https://www.youtube.com/embed/gEOi-unIUGc',
        N'https://www.youtube.com/watch?v=gEOi-unIUGc',
        N'Video bài giảng chuyên đề Chủ đề 1 (Năng lượng cơ học) - Bài 3 Cơ năng, trang 18-20.

NỘI DUNG VIDEO:
1. Cơ năng của vật chuyển động và vật đứng yên.
2. Động năng, thế năng trọng trường và thế năng đàn hồi.
3. Cơ năng = động năng + thế năng, đơn vị jun (J).
4. Định luật bảo toàn cơ năng trong chuyển động vật rơi tự do.
5. Bài tập vận dụng định luật bảo toàn cơ năng.

MẸO HỌC: Khi xem video, hãy dừng ở mỗi phần và tự tính lại ví dụ trước khi xem đáp án của thầy.',
        30, @tung);

-- ============ THẦY NGUYỄN THÀNH NAM — Điện học & điện từ ============

IF @nam IS NOT NULL AND @dien IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Định luật Ohm và điện trở (Thầy Nam)')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @dien, N'[Video] Định luật Ohm và điện trở (Thầy Nam)',
        N'Thầy Nguyễn Thành Nam thực hiện thí nghiệm đo điện trở và giảng định luật Ohm.',
        N'VIDEO_YOUTUBE',
        N'https://www.youtube.com/embed/tTp8pZSWgzU',
        N'https://www.youtube.com/watch?v=tTp8pZSWgzU',
        N'Video bài giảng chuyên đề Chủ đề 3 (Điện) - Bài 8 Điện trở, định luật Ohm.

NỘI DUNG VIDEO:
1. Thí nghiệm khảo sát sự phụ thuộc của cường độ dòng điện I vào hiệu điện thế U.
2. Bảng số liệu thực hành, vẽ đồ thị I theo U.
3. Kết luận: cường độ dòng điện tỉ lệ thuận với hiệu điện thế, tỉ lệ nghịch với điện trở.
4. Công thức: I = U/R, suy ra U = I.R và R = U/I.
5. Cách dùng vôn kế, ampe kê, ôm kê.

MẸO HỌC: Tự lập bảng số liệu trong vở rồi vẽ đồ thị trước khi xem phần kết luận của thầy.',
        42, @nam);

IF @nam IS NOT NULL AND @dien IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Đoạn mạch nối tiếp và song song (Thầy Nam)')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @dien, N'[Video] Đoạn mạch nối tiếp và song song (Thầy Nam)',
        N'Thầy Nam vẽ sơ đồ mạch điện và rút ra công thức điện trở tương đương từng loại mạch.',
        N'VIDEO_YOUTUBE',
        N'https://www.youtube.com/embed/SIZhgE2ONtY',
        N'https://www.youtube.com/watch?v=SIZhgE2ONtY',
        N'Video bài giảng chuyên đề Chủ đề 3 (Điện) - Bài 9, Bài 10: đoạn mạch nối tiếp và song song.

NỘI DUNG VIDEO:
1. Cách nhận biết mạch nối tiếp (một đường điện) và mạch song song (nhiều nhánh).
2. Mạch nối tiếp: I = I1 = I2 = ... = In, U = U1 + U2 + ... + Un, Rtđ = R1 + R2 + ... + Rn.
3. Mạch song song: U = U1 = U2 = ... = Un, I = I1 + I2 + ... + In, 1/Rtđ = 1/R1 + 1/R2 + ... + 1/Rn.
4. Bài tập tính Rtđ và cường độ dòng điện từng nhánh.

MẸO HỌC: "Nối tiếp thì I bằng nhau, U cộng lại, R cộng lại - song song thì ngược lại".',
        38, @nam);

IF @nam IS NOT NULL AND @dt IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Cảm ứng điện từ và máy biến thế (Thầy Nam)')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @dt, N'[Video] Cảm ứng điện từ và máy biến thế (Thầy Nam)',
        N'Thầy Nam giải thích điều kiện xuất hiện dòng điện cảm ứng và nguyên lý máy biến thế.',
        N'VIDEO_YOUTUBE',
        N'https://www.youtube.com/embed/ZiK7EEvCUIk',
        N'https://www.youtube.com/watch?v=ZiK7EEvCUIk',
        N'Video bài giảng chuyên đề Chủ đề 4 (Điện từ) - Bài 12, Bài 13.

NỘI DUNG VIDEO:
1. Hiện tượng cảm ứng điện từ và điều kiện "biến thiên từ thông".
2. Định luật Lenz xác định chiều dòng điện cảm ứng.
3. Máy phát điện xoay chiều: rôto - stato.
4. Máy biến thế: cấu tạo, nguyên lý cảm ứng, công thức U1/U2 = n1/n2.
5. Truyền tải điện xa và hao phí tỏa nhiệt Php = R.P2/U2.

MẸO HỌC: Thầy Nam luôn nhấn mạnh từ khóa "biến thiên" - đứng yên thì không có dòng cảm ứng.',
        40, @nam);

-- ============ CÔ DƯƠNG THU HÀ — Quang học & năng lượng ============

IF @ha IS NOT NULL AND @as IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Phản xạ toàn phần và sợi quang (Cô Hà)')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @as, N'[Video] Phản xạ toàn phần và sợi quang (Cô Hà)',
        N'Cô Dương Thu Hà giảng điều kiện phản xạ toàn phần qua hình vẽ từng bước.',
        N'VIDEO_YOUTUBE',
        N'https://www.youtube.com/embed/jXbW1Ungx5s',
        N'https://www.youtube.com/watch?v=jXbW1Ungx5s',
        N'Video bài giảng chuyên đề Chủ đề 2 (Ánh sáng) - Bài 6 Phản xạ toàn phần.

NỘI DUNG VIDEO:
1. Hiện tượng: tăng dần góc tới đến góc giới hạn, tia khúc xạ nằm sát mặt phân cách.
2. Điều kiện phản xạ toàn phần (cả hai phải đồng thời đúng).
3. Công thức sin igioại hạn = n2/n1.
4. Ứng dụng: sợi quang truyền thông tin, ống nhòm, máy ảnh.
5. Phân biệt phản xạ thường với phản xạ toàn phần.

MẸO HỌC: Vẽ lại đường truyền tia sáng trong nước và không khí, đánh dấu góc giới hạn.',
        32, @ha);

IF @ha IS NOT NULL AND @as IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Thấu kính và kính lúp (Cô Hà)')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @as, N'[Video] Thấu kính và kính lúp (Cô Hà)',
        N'Cô Hà hướng dẫn dựng ảnh qua thấu kính bằng các tia sáng đặc biệt.',
        N'VIDEO_YOUTUBE',
        N'https://www.youtube.com/embed/cCVOwVIuGUk',
        N'https://www.youtube.com/watch?v=cCVOwVIuGUk',
        N'Video bài giảng chuyên đề Chủ đề 2 (Ánh sáng) - Bài 7 Thấu kính, Kính lúp.

NỘI DUNG VIDEO:
1. Thấu kính hội tụ và thấu kính phân kì, cách phân biệt.
2. Ba tia sáng đặc biệt để dựng ảnh.
3. Công thức thấu kính: 1/f = 1/d + 1/d'', quy ước dấu.
4. Kính lúp: thấu kính hội tụ tiêu cự ngắn, số bội giác G = 25/f.

MẸO HỌC: Luôn dựng 2 trong 3 tia đặc biệt trước khi tính toán - đây là cách nhanh nhất để kiểm tra đáp án.',
        35, @ha);

IF @ha IS NOT NULL AND @as IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Kính lúp - bài toán số bội giác (Cô Hà)')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @as, N'[Video] Kính lúp - bài toán số bội giác (Cô Hà)',
        N'Bài giảng trọn bộ Bài 50 Kính lúp có đầy đủ âm thanh của cô Dương Thu Hà.',
        N'VIDEO_YOUTUBE',
        N'https://www.youtube.com/embed/yX1CNngqiE4',
        N'https://www.youtube.com/watch?v=yX1CNngqiE4',
        N'Video chuyên sâu bài 50 - Kính lúp: số bội giác, cách quan sát vật nhỏ và các tình huống thực tế.

NỘI DUNG VIDEO:
1. Kính lúp là thấu kính hội tụ tiêu cự ngắn, dùng để quan sát vật nhỏ.
2. Số bội giác G = 25/f (f tính bằng cm).
3. Vật đặt trong khoảng tiêu cự để thu được ảnh ảo lớn hơn vật.
4. Các ứng dụng thực tế: thợ kim hoàn soi vàng, đọc chữ viết nhỏ, kiểm tra linh kiện điện tử.

MẸO HỌC: Tính ngược f = 25/G khi biết số bội giác - rất hay ra trong đề thi.',
        28, @ha);

IF @ha IS NOT NULL AND @nlcs IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Năng lượng tái tạo và hóa thạch (Cô Hà)')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @nlcs, N'[Video] Năng lượng tái tạo và hóa thạch (Cô Hà)',
        N'Cô Hà so sánh ưu - nhược điểm của năng lượng tái tạo và năng lượng hóa thạch.',
        N'VIDEO_YOUTUBE',
        N'https://www.youtube.com/embed/EFjki2w08hw',
        N'https://www.youtube.com/watch?v=EFjki2w08hw',
        N'Video bài giảng chuyên đề Chủ đề 5 (Năng lượng với cuộc sống) - Bài 14, Bài 15.

NỘI DUNG VIDEO:
1. Nguồn năng lượng của Trái Đất: Mặt Trời, địa nhiệm, thủy triều, năng lượng hạt nhân.
2. Năng lượng hóa thạch: hình thành, ưu điểm, nhược điểm, ô nhiễm.
3. Năng lượng tái tạo: mặt trời, gió, nước, địa nhiệm, sinh khối.
4. So sánh giữa tái tạo và không tái tạo.
5. Liên hệ thực tế tại Việt Nam: Ninh Thuận - Bình Thuận, Bạc Liêu, Hòa Bình.

MẸO HỌC: Làm bảng so sánh 2 cột trong vở - đây là dạng bài hay ra trong đề thi tự luận.',
        33, @ha);

IF @ha IS NOT NULL AND @as IS NOT NULL
AND NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Bản chất ánh sáng và màu sắc vật (Cô Hà)')
INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, DocumentUrl, Content, DurationMinutes, CreatedBy)
VALUES (@ly9, @as, N'[Video] Bản chất ánh sáng và màu sắc vật (Cô Hà)',
        N'Cô Hà giải thích hiện tượng tán sắc và cơ chế tạo màu sắc của vật thể.',
        N'VIDEO_YOUTUBE',
        N'https://www.youtube.com/embed/bwQm0XKIhKY',
        N'https://www.youtube.com/watch?v=bwQm0XKIhKY',
        N'Video bài giảng chuyên đề Chủ đề 2 (Ánh sáng) - Bài 5 Tán sắc ánh sáng, Màu sắc của vật.

NỘI DUNG VIDEO:
1. Ánh sáng trắng là hỗn hợp nhiều ánh sáng màu, lăng kính tách thành dải màu.
2. Ánh sáng đơn sắc không bị tán sắc.
3. Vật màu đỏ vì tán xạ ánh sáng đỏ và hấp thụ các màu còn lại.
4. Vật trắng tán xạ mọi màu, vật đen hấp thụ gần như mọi màu.
5. Ứng dụng: màn hình RGB, in ấn CMYK, tín hiệu giao thông.

MẸO HỌC: Nhớ câu "màu ta nhìn thấy phụ thuộc cả vào vật VÀ ánh sáng chiếu tới nó".',
        26, @ha);
GO

-- ============================================================
--  4. CẬP NHẬT SỐ LƯỢNG VIDEO CHO HỒ SƠ GIÁO VIÊN
-- ============================================================
UPDATE tp
SET tp.VideoCount = (
    SELECT COUNT(*) FROM dbo.Lessons l
    WHERE l.CreatedBy = tp.UserID AND l.IsActive = 1
)
FROM dbo.TeacherProfiles tp;
GO

PRINT N'=========================================';
PRINT N'  ĐÃ NẠP GIÁO VIÊN + VIDEO GIA SƯ LÝ 9';
PRINT N'  3 giáo viên, 9 bài giảng video';
PRINT N'  Tài khoản: phamvantung / nguyenthanhnam / duongthuha';
PRINT N'  Mật khẩu:  giaovien123';
PRINT N'=========================================';
GO


-- =============================================================================
--  PHẦN 5: SỬA LIÊN KẾT VIDEO CỦA GIÁO VIÊN
--  (nguồn: 05_fix_teacher_video_links.sql)
-- =============================================================================
-- ============================================================
--  GIA SƯ LÝ 9 - Cập nhật link video bài giảng cho 3 giáo viên
--  Thay các URL tìm kiếm YouTube bằng link video thật (embed được).
--  Chạy an toàn nhiều lần.
-- ============================================================
USE GiaSuLy9;
GO

UPDATE dbo.Lessons SET VideoUrl = N'https://www.youtube.com/embed/gEOi-unIUGc',
                       DocumentUrl = N'https://www.youtube.com/watch?v=gEOi-unIUGc'
WHERE Title = N'[Video] Bảo toàn cơ năng - Bài tập vận dụng (Thầy Tùng)';

UPDATE dbo.Lessons SET VideoUrl = N'https://www.youtube.com/embed/SIZhgE2ONtY',
                       DocumentUrl = N'https://www.youtube.com/watch?v=SIZhgE2ONtY'
WHERE Title = N'[Video] Đoạn mạch nối tiếp và song song (Thầy Nam)';

UPDATE dbo.Lessons SET VideoUrl = N'https://www.youtube.com/embed/ZiK7EEvCUIk',
                       DocumentUrl = N'https://www.youtube.com/watch?v=ZiK7EEvCUIk'
WHERE Title = N'[Video] Cảm ứng điện từ và máy biến thế (Thầy Nam)';

UPDATE dbo.Lessons SET VideoUrl = N'https://www.youtube.com/embed/bwQm0XKIhKY',
                       DocumentUrl = N'https://www.youtube.com/watch?v=bwQm0XKIhKY'
WHERE Title = N'[Video] Bản chất ánh sáng và màu sắc vật (Cô Hà)';

UPDATE tp
SET tp.VideoCount = (
    SELECT COUNT(*) FROM dbo.Lessons l
    WHERE l.CreatedBy = tp.UserID AND l.IsActive = 1
)
FROM dbo.TeacherProfiles tp;

PRINT N'Đã cập nhật link video cho giáo viên Gia Sư Lý 9';
GO

-- =============================================================================
--  PHẦN 6: BÀI HỌC (TEXT + VIDEO) CHO MỌI CHỦ ĐỀ
--  Mỗi chủ đề đều có bài giảng Text và bài giảng Video (YouTube thật).
-- =============================================================================
-- =============================================================================
--  PHẦN 1: CƠ NĂNG VÀ NĂNG LƯỢNG (TopicID = 1)
-- =============================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 1: Công cơ học')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 1, N'Bài 1: Công cơ học',
            N'Khái niệm công cơ học, công thức A = F.s, đơn vị J, các trường hợp công không phát sinh.',
            'TEXT', NULL,
            N'1. KHÁI NIỆM CÔNG CƠ HỌC
- Khi một lực tác dụng lên vật và vật chuyển động theo phương của lực, thì lực đó đã sinh ra công (công cơ học).
- Công cơ học phụ thuộc vào 3 yếu tố: lực tác dụng F, đường độ của lực s, góc giữa lực và đường chuyển động.
- Khi lực không có tác dụng (vật đứng yên) hoặc lực vuông góc với đường chuyển động thì công bằng 0.

2. CÔNG THỨC TÍNH CÔNG
- A = F.s
- Trong đó: A là công (J), F là lực tác dụng (N), s là quãng đường chuyển động (m).
- Khi lực không vuông góc với phương chuyển động: A = F.s.cos(alpha) với alpha là góc giữa lực và đường chuyển động.

3. ĐƠN VỊ VÀ CÁC TRƯỜNG HỢP ĐẶC BIỆT
- Đơn vị công là jun (J). 1 J = 1 N.m = 1 W.s.
- Công của lực F trên quãng đường s bằng 0 khi: lực bằng 0, vật đứng yên, lực vuông góc với quãng đường.
- Khi vật chuyển động đều trên mặt phẳng ngang, lực kéo cân bằng với lực ma sát nên công của lực kéo bằng công chống ma sát.

4. VÍ DỤ TÍNH TOÁN
Một người kéo đều một vật có khối lượng 20 kg trên mặt đường ngang bằng lực 100 N trong quãng đường 50 m.
- Lực kéo song song với quãng đường nên góc alpha = 0, công: A = F.s = 100.50 = 5000 J.
- Lực ma sát có độ lớn bằng 100 N, công ma sát: A = -100.50 = -5000 J.
- Công tổng cộng bằng 0 vì vật chuyển động đều, động năng không đổi.

GHI NHỚ: trước khi tính công, luôn xác định lực nào sinh công và lực đó có cùng hướng với chuyển động hay không.',
            40, 2, 1);
    PRINT 'Đã thêm: Cơ năng và năng lượng - Bài 1: Công cơ học';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 2: Công suất')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 1, N'Bài 2: Công suất',
            N'Định nghĩa công suất, công thức P = A/t = F.v, đơn vị W và kW, ý nghĩa vật lý.',
            'TEXT', NULL,
            N'1. ĐỊNH NGHĨA CÔNG SUẤT
- Công suất là đại lượng cho biết công của lực tác dụng trong một đơn vị thời gian.
- P = A/t, trong đó P là công suất (W), A là công (J), t là thời gian thực hiện công (s).

2. CÔNG THỨC TÍNH CÔNG SUẤT
- P = F.v (áp dụng khi lực song song với vận tốc và không thay đổi).
- 1 W = 1 J/s = 1 kg.m2/s3. 1 kW = 1000 W. 1 MW = 1000 kW.
- Công suất cũng được gọi là tốc độ tiêu tán năng lượng hay tốc độ biến đổi năng lượng.

3. Ý NGHĨA VẬT LÝ
- Máy có công suất lớn thì thực hiện công nhanh hơn, hoặc thực hiện công bằng trong thời gian ngắn hơn.
- Hai máy cùng thực hiện một công bằng nhau, máy có công suất lớn hơn sẽ thực hiện công trong thời gian ít hơn.
- Trên động cơ điện, công suất cơ nhỏ hơn công suất điện vì một phần năng lượng điện bị hao phí (nhiệt, ma sát).

4. VÍ DỤ TÍNH TOÁN
Một máy cắt cỏ có công suất 1,5 kW, hoạt động trong 20 phút.
- Đổi đơn vị: P = 1500 W, t = 20.60 = 1200 s.
- Công thực hiện: A = P.t = 1500.1200 = 1 800 000 J = 1,8 MJ.
- Lượng điện tiêu thụ (nếu hiệu suất 100%): W = 0,5 kWh.

GHI NHỚ: công suất không phụ thuộc vào thời gian thực hiện công, chỉ phụ thuộc vào tốc độ thực hiện công.',
            40, 2, 1);
    PRINT 'Đã thêm: Cơ năng và năng lượng - Bài 2: Công suất';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Cơ năng và năng lượng')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 1, N'[Video] Cơ năng và năng lượng',
            N'Bài giảng video: Công và công suất trong chương trình Vật lý 9.',
            'VIDEO_YOUTUBE', N'https://www.youtube.com/embed/GK83XaGbLi0',
            N'Video bài giảng Công và công suất - Khoa học tự nhiên 9 (OLM.VN).

Nội dung video gồm:
- Phần 1: Công cơ học - khái niệm, công thức A = F.s, các trường hợp không sinh công.
- Phần 2: Công suất - định nghĩa, công thức P = A/t = F.v, ý nghĩa vật lý.
- Ví dụ bài toán tính công và công suất cho đèn điện, động cơ, máy bơm nước.

GHI NHỚ: xem xong video hãy làm phần bài tập trong chủ đề "Cơ năng và năng lượng" để kiểm tra hiểu bài.',
            10, 2, 1);
    PRINT 'Đã thêm: Cơ năng và năng lượng - Video';
END
GO

-- =============================================================================
--  PHẦN 2: ĐIỆN VÀ MẠCH ĐIỆN (TopicID = 2)
-- =============================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 3: Điện trở - Định luật Ohm')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 2, N'Bài 3: Điện trở - Định luật Ohm',
            N'Khái niệm điện trở, định luật Ohm I = U/R, đơn vị ôm, cách đo bằng ampe kế và vôn kế.',
            'TEXT', NULL,
            N'1. ĐIỆN TRỞ CỦA DÂY DẪN
- Mọi dây dẫn đều có điện trở. Điện trở luôn chỉ có giá trị dương và không đổi theo vị trí.
- Ký hiệu: R, đơn vị ôm (Ω). 1 Ω = 1 A/V = 1 V/A.
- Hai điện trở có cùng điện trở khi cùng vật liệu, cùng tiết diện S và cùng chiều dài l.
- Công thức: R = rho.l/S, trong đó rho là điện trở suất của vật liệu (Ω.m).
- Điện trở phụ thuộc vào bản chất vật liệu, chiều dài và tiết diện dây dẫn, không phụ thuộc nhiệt độ (với kim loại).

2. ĐỊNH LUẬT OHM
- Với cùng một dây dẫn, cường độ dòng điện I tỉ lệ thuận với hiệu điện thế U ở hai đầu dây dẫn.
- Công thức: I = U/R hoặc U = I.R
- Ý nghĩa: với cùng một dây dẫn, cường độ dòng điện tăng thì hiệu điện thế cũng tăng tương ứng.

3. CÁCH ĐO CƯỜNG ĐỘ DÒNG ĐIỆN VÀ HIỆU ĐIỆN THẾ
- Cường độ dòng điện đo bằng ampe kế, mắc nối tiếp với dây dẫn, dòng điện đi qua ampe kế là dòng điện cần đo.
- Hiệu điện thế đo bằng vôn kế, mắc song song với đoạn dây dẫn cần đo hiệu điện thế.

4. VÍ DỤ TÍNH TOÁN
Một dây dẫn có điện trở 12 Ω được nối vào nguồn có hiệu điện thế 6 V.
- Cường độ dòng điện: I = U/R = 6/12 = 0,5 A.
- Nếu đặt cùng dây đó vào mạch có hiệu điện thế 9 V thì I = 9/12 = 0,75 A.

GHI NHỚ: ampe kế mắc nối tiếp, vôn kế mắc song song. Luôn kiểm tra đơn vị trước khi tính.',
            45, 2, 1);
    PRINT 'Đã thêm: Điện và mạch điện - Bài 3: Điện trở - Định luật Ohm';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 4: Đoạn mạch nối tiếp')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 2, N'Bài 4: Đoạn mạch nối tiếp',
            N'Đặc điểm của đoạn mạch nối tiếp: cùng dòng, tổng hiệu điện thế, tổng điện trở, cùng cường độ dòng điện.',
            'TEXT', NULL,
            N'1. KHÁI NIỆM
- Đoạn mạch nối tiếp là đoạn mạch trong đó các thiết bị điện nối tiếp nhau, nối tiếp điểm nối của thiết bị trước với điểm nối của thiết bị sau.

2. ĐẶC ĐIỂM CỦA ĐOẠN MẠCH NỐI TIẾP
- Dòng điện tại mọi điểm trong mạch đều bằng nhau: I1 = I2 = I.
- Hiệu điện thế giữa hai đầu đoạn mạch bằng tổng hiệu điện thế trên từng phần tử: U = U1 + U2 + ...
- Tổng điện trở của đoạn mạch nối tiếp bằng tổng các điện trở: R = R1 + R2 + ...
- Cường độ dòng điện qua mỗi phần tử nhỏ hơn cường độ dòng điện qua đoạn mạch chính.

3. VÍ DỤ TÍNH TOÁN
Trong mạch nối tiếp có hai bóng đèn có điện trở R1 = 3 Ω và R2 = 6 Ω, mạch được nối vào nguồn 9 V.
- Tổng điện trở: R = 3 + 6 = 9 Ω.
- Cường độ dòng điện qua mạch: I = U/R = 9/9 = 1 A.
- Hiệu điện thế trên bóng đèn 1: U1 = I.R1 = 1.3 = 3 V.
- Hiệu điện thế trên bóng đèn 2: U2 = I.R2 = 1.6 = 6 V.
- Kiểm tra: U1 + U2 = 3 + 6 = 9 V đúng bằng hiệu điện thế nguồn.

4. ỨNG DỤNG
- Dây đèn trang trí nối tiếp: nếu một bóng hỏng thì cả chuỗi tắt.
- Bóng đèn trang trí nối song song: một bóng hỏng các bóng khác vẫn sáng.

GHI NHỚ: nối tiếp - cùng dòng, cộng điện trở, cộng hiệu điện thế.',
            40, 2, 1);
    PRINT 'Đã thêm: Điện và mạch điện - Bài 4: Đoạn mạch nối tiếp';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 5: Đoạn mạch song song')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 2, N'Bài 5: Đoạn mạch song song',
            N'Đặc điểm đoạn mạch song song: cùng hiệu điện thế, tổng cường độ dòng điện, điện trở tương đương.',
            'TEXT', NULL,
            N'1. KHÁI NIỆM
- Đoạn mạch song song là đoạn mạch trong đó các nhánh mạch có chung hai điểm nối, được nối song song với nhau.

2. ĐẶC ĐIỂM CỦA ĐOẠN MẠCH SONG SONG
- Hiệu điện thế giữa hai đầu mỗi nhánh bằng nhau: U1 = U2 = U.
- Cường độ dòng điện qua mạch chính bằng tổng các cường độ dòng điện qua từng nhánh: I = I1 + I2 + ...
- Điện trở tương đương của đoạn mạch song song nhỏ hơn điện trở của mỗi nhánh.
- Công thức với hai điện trở: 1/R = 1/R1 + 1/R2, suy ra R = (R1.R2)/(R1 + R2).

3. VÍ DỤ TÍNH TOÁN
Hai bóng đèn có điện trở 6 Ω và 3 Ω mắc song song, nối vào nguồn 6 V.
- Hiệu điện thế trên mỗi bóng đều bằng 6 V.
- Dòng qua đèn 6 Ω: I1 = 6/6 = 1 A. Dòng qua đèn 3 Ω: I2 = 6/3 = 2 A.
- Dòng qua mạch chính: I = 1 + 2 = 3 A.
- Điện trở tương đương: R = U/I = 6/3 = 2 Ω (nhỏ hơn cả 3 Ω lẫn 6 Ω).

GHI NHỚ: song song - cùng hiệu điện thế, cộng dòng điện, điện trở tương đương nhỏ hơn từng nhánh.',
            40, 2, 1);
    PRINT 'Đã thêm: Điện và mạch điện - Bài 5: Đoạn mạch song song';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Điện và mạch điện')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 2, N'[Video] Điện và mạch điện',
            N'Bài giảng video: Điện trở và Định luật Ohm trong chương trình Vật lý 9.',
            'VIDEO_YOUTUBE', N'https://www.youtube.com/embed/emlWHSSXv4o',
            N'Video bài giảng Điện trở - Định luật Ohm - Khoa học tự nhiên lớp 9 (Kết nối tri thức).

Nội dung video gồm:
- (1) Điện trở - khái niệm, công thức R = rho.l/S, ảnh hưởng của kích thước và bản chất dây dẫn.
- (2) Sự phụ thuộc của cường độ dòng điện vào hiệu điện thế.
- (3) Định luật Ohm - I = U/R.
- (4) Điện trở của dây dẫn phụ thuộc vào kích thước và bản chất của dây dẫn.

GHI NHỚ: xem xong video hãy làm phần bài tập trong chủ đề "Điện và mạch điện" để kiểm tra hiểu bài.',
            18, 2, 1);
    PRINT 'Đã thêm: Điện và mạch điện - Video';
END
GO

-- =============================================================================
--  PHẦN 3: ĐIỆN NĂNG, CÔNG SUẤT VÀ ĐIỆN ÁP XOAY CHIỀU (TopicID = 3)
-- =============================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 6: Năng lượng của dòng điện - Công suất điện')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 3, N'Bài 6: Năng lượng của dòng điện - Công suất điện',
            N'Công của dòng điện A = U.I.t, công suất điện P = U.I, đơn vị W và kWh, bảng công suất thiết bị.',
            'TEXT', NULL,
            N'1. CÔNG CỦA DÒNG ĐIỆN
- Công của dòng điện A = U.I.t, trong đó U là hiệu điện thế (V), I là cường độ dòng điện (A), t là thời gian (s).
- Công A tính bằng J, còn năng lượng điện thường tính bằng kWh: 1 kWh = 3 600 000 J = 3,6 MJ.
- Công thức liên hệ: A = P.t với P là công suất.

2. CÔNG SUẤT ĐIỆN
- Công suất điện P = U.I, đơn vị W (oát). 1 kW = 1000 W.
- Công suất điện cho biết tốc độ tiêu tán điện năng của thiết bị điện.
- Trên nhãn hiệu của thiết bị điện ghi công suất và hiệu điện thế, từ đó tính được dòng điện: I = P/U.

3. CÁCH TÍNH ĐIỆN NĂNG SỬ DỤNG
- Điện năng tiêu thụ: A = P.t (A tính bằng Wh hoặc kWh khi P tính bằng kW).
- Ví dụ: bóng đèn 100 W dùng 5 giờ/ngày, 30 ngày/tháng: A = 0,1 kW . 5 h . 30 = 15 kWh.

4. VÍ DỤ TÍNH TOÁN
Một máy sấy tóc có công suất 1200 W, dùng ở hiệu điện thế 220 V trong 10 phút.
- Cường độ dòng điện: I = P/U = 1200/220 ≈ 5,45 A.
- Điện năng tiêu thụ: A = 1,2 kW . (10/60) h = 0,2 kWh = 200 Wh.

GHI NHỚ: P = U.I và A = P.t là hai công thức cần nhớ nhất trong chủ đề này.',
            45, 2, 1);
    PRINT 'Đã thêm: Điện năng, công suất - Bài 6';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 7: Máy điện và hiệu suất của máy')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 3, N'Bài 7: Máy điện và hiệu suất của máy',
            N'Cấu tạo máy điện, hiệu suất của máy, công có ích và công hao phí, công thức tính hiệu suất.',
            'TEXT', NULL,
            N'1. MÁY ĐIỆN
- Máy điện gồm hai phần: máy phát điện (biến cơ năng thành điện năng) và máy biến điện năng thành cơ năng (động cơ điện).
- Máy phát điện: rôto (cuộn dây) quay trong từ trường của nam châm hoặc cuộn dây, tạo ra suất điện động.
- Động cơ điện: dòng điện chạy qua cuộn dây tạo lực từ trường, làm cuộn dây quay.

2. HIỆU SUẤT CỦA MÁY
- Hiệu suất H = (công có ích / công toàn phần) . 100%, luôn nhỏ hơn 100%.
- Với máy điện: H = (A có ích / A tiêu tụ) . 100% = (U2.I2 / U1.I1) . 100%.
- Công toàn phần = công có ích + công hao phí (hao phí do ma sát, nhiệt, từ tính...).

3. VÍ DỤ TÍNH TOÁN
Một động cơ điện có hiệu suất 80%, tiêu thụ 2000 W điện năng.
- Công có ích (cơ năng): A hữu ích = 0,8 . 2000 = 1600 W.
- Công hao phí: 2000 - 1600 = 400 W.
- Trong 1 giờ, động cơ tiêu thụ 2 kWh điện và tạo ra 1,6 kWh cơ năng.

GHI NHỚ: hiệu suất luôn nhỏ hơn 100%, không bao giờ có máy nào hiệu suất bằng 100% trong thực tế.',
            40, 2, 1);
    PRINT 'Đã thêm: Điện năng, công suất - Bài 7';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Điện năng, công suất và điện áp xoay chiều')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 3, N'[Video] Điện năng, công suất và điện áp xoay chiều',
            N'Bài giảng video: Năng lượng của dòng điện và công suất điện trong chương trình Vật lý 9.',
            'VIDEO_YOUTUBE', N'https://www.youtube.com/embed/EKgkdR56f-c',
            N'Video bài giảng Năng lượng điện - Công suất điện (KHTN 9 - Vật Lí).

Nội dung video gồm:
- Năng lượng của dòng điện: công A = U.I.t, đơn vị kWh.
- Công suất điện: P = U.I, cách đọc nhãn hiệu thiết bị.
- Bảng công suất và cường độ dòng điện của một số thiết bị điện gia dụng.
- Bài tập tính điện năng tiêu thụ.

GHI NHỚ: xem xong video hãy làm phần bài tập trong chủ đề "Điện năng, công suất và điện áp xoay chiều".',
            40, 2, 1);
    PRINT 'Đã thêm: Điện năng, công suất - Video';
END
GO

-- =============================================================================
--  PHẦN 4: KHÚC XẠ ÁNH SÁNG (TopicID = 4)
-- =============================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 8: Hiện tượng khúc xạ ánh sáng')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 4, N'Bài 8: Hiện tượng khúc xạ ánh sáng',
            N'Hiện tượng khúc xạ ánh sáng, góc tới, góc khúc xạ, định luật khúc xạ, chiết suất của môi trường.',
            'TEXT', NULL,
            N'1. HIỆN TƯỢNG KHÚC XẠ ÁNH SÁNG
- Hiện tượng khúc xạ ánh sáng là hiện tượng thay đổi góc truyền (hoặc góc đi) của tia sáng khi đi từ môi trường này sang môi trường khác.
- Ví dụ: cắm que vào nước thấy que bị "gãy"; hiện tượng lặn mặt trống.
- Tia sáng gọi là tia khúc xạ khi đã đổi hướng.

2. GÓC TỚI VÀ GÓC KHÚC XẠ
- Góc tới (i) là góc giữa tia sáng tới và mặt phẳng phân cách (vuông góc với mặt phẳng chứa tia sáng tới).
- Góc khúc xạ (r) là góc giữa tia khúc xạ và mặt phẳng phân cách.
- Khi tia sáng truyền từ không khí sang nước: i > r. Khi truyền từ nước sang không khí: i < r.

3. ĐỊNH LUẬT KHÚC XẠ ÁNH SÁNG
- Tỉ số sin góc tới và sin góc khúc xạ không đổi khi tia sáng chiếu qua các môi trường trong suốt khác nhau với cùng một cặp môi trường: sin i / sin r = const.
- Hằng số này gọi là chiết suất của môi trường với môi trường ngoài: n = sin i / sin r.

4. CHIẾT SUẤT CỦA MÔI TRƯỜNG
- n = 1 với không khí, n ≈ 1,33 với nước, n ≈ 1,5 với thủy tinh.
- Khi n2 > n1 (chiếu từ môi trường kém khúc xạ sang môi trường khúc xạ mạnh) thì tia khúc xạ bị lệch về phía đường pháp tuyến.
- Khi n2 < n1 thì tia khúc xạ bị lệch xa đường pháp tuyến.

5. VÍ DỤ TÍNH TOÁN
Cho tia sáng chiếu từ không khí vào nước, góc tới i = 30°, n = 1,33.
- sin r = sin 30° / 1,33 = 0,5/1,33 ≈ 0,376.
- r ≈ 22,1°.

GHI NHỚ: góc tới và góc khúc xạ đều đo với mặt phẳng phân cách, không đo với mặt phẳng chứa tia sáng.',
            45, 2, 1);
    PRINT 'Đã thêm: Khúc xạ ánh sáng - Bài 8';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 9: Phản xạ toàn phần - Thấu kính')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 4, N'Bài 9: Phản xạ toàn phần - Thấu kính',
            N'Hiện tượng phản xạ toàn phần, thấu kính hội tụ và phân kì, cách dựng ảnh qua thấu kính.',
            'TEXT', NULL,
            N'1. HIỆN TƯỢNG PHẢN XẠ TOÀN PHẦN
- Khi tia sáng truyền từ môi trường khúc xạ mạnh (n1) sang môi trường khúc xạ yếu (n2) mà góc tới lớn hơn góc giới hạn, tia sáng không truyền sang môi trường n2 mà bị phản xạ toàn phần tại mặt phân cách.
- Góc giới hạn: sin i_gh = n2/n1. Với nước sang không khí, i_gh ≈ 48,6°.
- Hiện tượng này được ứng dụng trong đường truyền quang sợi.

2. THẤU KÍNH HỘI TỤ
- Mặt cầu lõm, tiêu cự F > 0. Tia sáng song song với trục chính đi qua tiêu điểm F.
- Vật trước thấu kính cho ảnh thật (khi nằm ngoài 2F), ảnh ảo (khi nằm trong F), ảnh lớn và ảnh nhỏ tùy vị trí.

3. THẤU KÍNH PHÂN KÌ
- Mặt cầu lõi, tiêu cự F < 0. Tia sáng song song với trục chính đi qua tiêu điểm F về phía đối diện với tiêu điểm chính.
- Vật trước thấu kính luôn cho ảnh ảo, nhỏ hơn vật, nằm cùng phía với vật.

4. VÍ DỤ
Kính lúp là một thấu kính hội tụ có tiêu cự nhỏ, đặt trước mắt trong khoảng cách nhỏ hơn tiêu cự, tạo ảnh ảo phóng đại giúp quan sát vật nhỏ.

GHI NHỚ: thấu kính hội tụ có mặt cầu lõm, thấu kính phân kì có mặt cầu lõi.',
            45, 2, 1);
    PRINT 'Đã thêm: Khúc xạ ánh sáng - Bài 9';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Khúc xạ ánh sáng')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 4, N'[Video] Khúc xạ ánh sáng',
            N'Bài giảng video: Khúc xạ ánh sáng trong chương trình Vật lý 9.',
            'VIDEO_YOUTUBE', N'https://www.youtube.com/embed/bxVuj5vlEjw',
            N'Video bài giảng Khúc xạ ánh sáng - Khoa học tự nhiên lớp 9 (Kết nối tri thức).

Nội dung video gồm:
- (1) Hiện tượng khúc xạ ánh sáng - mô tả thí nghiệm, góc tới, góc khúc xạ.
- (2) Định luật khúc xạ ánh sáng - công thức sin i / sin r = hằng số.
- (3) Chiết suất của môi trường - bảng chiết suất, các trường hợp lệch tia sáng.

GHI NHỚ: xem xong video hãy làm phần bài tập trong chủ đề "Khúc xạ ánh sáng" để kiểm tra hiểu bài.',
            17, 2, 1);
    PRINT 'Đã thêm: Khúc xạ ánh sáng - Video';
END
GO

-- =============================================================================
--  PHẦN 5: TIA VÀ HIỆN TƯỢNG PHÁT SÁNG (TopicID = 5)
-- =============================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'Bài 10: Hiện tượng phát sáng')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 5, N'Bài 10: Hiện tượng phát sáng',
            N'Nguồn sáng, vật phát sáng, các hiện tượng phát sáng, ánh sáng tự phát và ánh sáng phản chiếu.',
            'TEXT', NULL,
            N'1. NGUỒN SÁNG VÀ VẬT PHÁT SÁNG
- Nguồn sáng là vật phát ra ánh sáng. Có hai loại: nguồn sáng tự phát (mặt trời, bóng đèn, ngọn lửa) và nguồn sáng phản chiếu (gương, tấm trắng, mặt nước).
- Vật phát sáng là vật tự phát ra ánh sáng khi chiếu sáng vào nó. Ví dụ: mặt trời, ngọn đèn, đèn pin.

2. CÁC HIỆN TƯỢNG PHÁT SÁNG
- Vật phát sáng: có năng lượng, tự làm sáng.
- Vật phản xạ sáng: không có năng lượng, chỉ phản xạ ánh sáng chiếu vào nó.
- Ánh sáng truyền trong môi trường trong suốt, bị hấp thụ hoặc phản xạ ở bề mặt.

3. ÁNH SÁNG TỰ PHÁT VÀ ÁNH SÁNG PHẢN CHIẾU
- Ánh sáng tự phát do vật có năng lượng phát ra (mặt trời, bóng đèn, đèn LED).
- Ánh sáng phản xạ do vật không có năng lượng phản xạ ánh sáng chiếu vào nó (mặt gương, mặt nước, tờ giấy trắng).
- Nhận biết: nguồn sáng tự phát có thể phát sáng trong bóng tối, còn vật phản xạ sáng chỉ sáng khi có ánh sáng chiếu vào.

4. MÁY CƠ VÀ HIỆU SUẤT (LIÊN HỆ)
- Máy cơ nhận công A1 (công toàn phần) và tạo ra công có ích A2.
- Hiệu suất H = (A2/A1).100%, luôn nhỏ hơn 100%.
- Phần công hao phí: A hao phí = A1 - A2, dạng nhiệt, âm thanh, ma sát.

5. VÍ DỤ TÍNH TOÁN
Máy thực hiện công toàn phần 3000 J với hiệu suất 75%.
- Công có ích: A2 = 0,75 . 3000 = 2250 J.
- Công hao phí: 3000 - 2250 = 750 J.

GHI NHỚ: hiệu suất không bao giờ vượt quá 100%. Kiểm tra kỹ đơn vị (J, kJ) trước khi tính.',
            40, 2, 1);
    PRINT 'Đã thêm: Tia và hiện tượng phát sáng - Bài 10';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Lessons WHERE Title = N'[Video] Tia và hiện tượng phát sáng')
BEGIN
    INSERT INTO dbo.Lessons (SubjectID, TopicID, Title, Description, LessonType, VideoUrl, Content, DurationMinutes, CreatedBy, IsActive)
    VALUES (1, 5, N'[Video] Tia và hiện tượng phát sáng',
            N'Bài giảng video: Hiện tượng khúc xạ ánh sáng - hiện tượng phát sáng trong chương trình Vật lý 9.',
            'VIDEO_YOUTUBE', N'https://www.youtube.com/embed/8nJ7NKXfzIs',
            N'Video bài giảng hiện tượng phát sáng và khúc xạ ánh sáng (Natural Science 9).

Nội dung video gồm:
- Hiện tượng phát sáng: nguồn sáng tự phát và nguồn sáng phản chiếu.
- Ánh sáng truyền trong môi trường, hiện tượng khúc xạ ánh sáng.
- Áp dụng định luật khúc xạ vào bài tập tính góc khúc xạ.

GHI NHỚ: xem xong video hãy làm phần bài tập trong chủ đề "Tia và hiện tượng phát sáng" để kiểm tra hiểu bài.',
            23, 2, 1);
    PRINT 'Đã thêm: Tia và hiện tượng phát sáng - Video';
END
GO

-- =============================================================================
--  PHẦN 8: ẢNH MINH HOẠ CHO CHỦ ĐỀ
--  (gộp từ 05_seed_topic_images.sql)
--  Tham số ?v= để trình duyệt không dùng bản cache cũ.
-- =============================================================================
UPDATE dbo.Topics SET ImageUrl = '/assets/img/topics/topic-01-co-nang.svg?v=3' WHERE TopicID = 1;
UPDATE dbo.Topics SET ImageUrl = '/assets/img/topics/topic-02-dien-mach-dien.svg?v=3' WHERE TopicID = 2;
UPDATE dbo.Topics SET ImageUrl = '/assets/img/topics/topic-03-cong-suat-xoay-chieu.svg?v=3' WHERE TopicID = 3;
UPDATE dbo.Topics SET ImageUrl = '/assets/img/topics/topic-04-khuc-xa-anh-sang.svg?v=3' WHERE TopicID = 4;
UPDATE dbo.Topics SET ImageUrl = '/assets/img/topics/topic-05-tia-phat-sang.svg?v=3' WHERE TopicID = 5;
UPDATE dbo.Topics SET ImageUrl = '/assets/img/topics/topic-06-nang-luong-co-hoc.svg?v=3' WHERE TopicID = 6;
UPDATE dbo.Topics SET ImageUrl = '/assets/img/topics/topic-07-anh-sang.svg?v=3' WHERE TopicID = 7;
UPDATE dbo.Topics SET ImageUrl = '/assets/img/topics/topic-08-dien.svg?v=3' WHERE TopicID = 8;
UPDATE dbo.Topics SET ImageUrl = '/assets/img/topics/topic-09-dien-tu.svg?v=3' WHERE TopicID = 9;
UPDATE dbo.Topics SET ImageUrl = '/assets/img/topics/topic-10-nang-luong-cuoc-song.svg?v=3' WHERE TopicID = 10;
GO

-- =============================================================================
--  PHẦN 9: KIỂM TRA DỮ LIỆU
--  (gộp từ check-data.sql)
--  Xem nhanh mỗi chủ đề có bao nhiêu câu trắc nghiệm (MCQ), câu tự luận (ESSAY)
--  và bao nhiêu bài giảng đang active.
-- =============================================================================
SELECT t.TopicID,
       t.Name,
       (SELECT COUNT(*) FROM dbo.Questions q
         WHERE q.TopicID = t.TopicID AND q.QuestionType = 'MCQ' AND q.IsActive = 1)  AS MCQ,
       (SELECT COUNT(*) FROM dbo.Questions q
         WHERE q.TopicID = t.TopicID AND q.QuestionType = 'ESSAY' AND q.IsActive = 1) AS ESSAY,
       (SELECT COUNT(*) FROM dbo.Lessons l
         WHERE l.TopicID = t.TopicID AND l.IsActive = 1)                               AS Lessons
FROM dbo.Topics t
ORDER BY t.TopicID;
GO

